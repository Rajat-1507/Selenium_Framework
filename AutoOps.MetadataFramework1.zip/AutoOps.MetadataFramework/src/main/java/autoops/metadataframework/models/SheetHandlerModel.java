package autoops.metadataframework.models;

public class SheetHandlerModel {
public String testcasetorun; 
public String allsheets; 
public int rows; 
}
