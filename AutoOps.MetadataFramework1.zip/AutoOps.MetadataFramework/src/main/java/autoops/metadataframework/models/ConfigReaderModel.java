package autoops.metadataframework.models;

import java.util.List;

public class ConfigReaderModel {

	public String username;
	public String Evidence_path; 
	private String password; 
	public List<TestMetadata> tests;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEvidence_path() {
		return Evidence_path;
	}
	public void setEvidence_path(String evidence_path) {
		Evidence_path = evidence_path;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void addTest(TestMetadata test) {
		tests.add(test);
	}
	
}
