package autoops.metadataframework.models;

public class TestMetadata {
public String test_data;
public String test_id;
public String expected_result; 
public String actual_result; 
public String run_mode; 
public String evidence; 
public String xpath; 
public String navigation_xpath; 
public String status;

public TestMetadata(String test_id, String test_data,String expected_result, String run_mode, String xpath, String navigation_xpath, String actual_result, String evidence, String status) 
{
	this.test_id =test_id;
	this.test_data=test_data;
	this.run_mode=run_mode;
	this.expected_result=expected_result;
	this.xpath=xpath;
	this.navigation_xpath=navigation_xpath;
	this.actual_result=actual_result;
	this.evidence=evidence;
	this.status=status;

     }
}
