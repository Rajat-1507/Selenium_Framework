 package autoops.metadataframework.intializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import autoops.metadataframework.models.TestMetadata;

public class SheetHandler {
	
	public List<Map<String, String>> getTestcasesToRun() {
		
	ConfigReader configreader = new ConfigReader();
//	configreader.readSheet();
	
	//Method-Readsheet-Take SheetName arraylist & It will read sheet one by one.
	//1st I will call getAllSheet Method
	// For loop 
	
	List<String> allSheets = configreader.getAllSheet();
	List<TestMetadata> testcasestorun = new  ArrayList<TestMetadata>();
			
	for(int i=0;i<allSheets.size();i++) {
		configreader.readSheet(allSheets.get(i));
		
		for(int j=0;i<configreader.config.tests.size();j++) {
			TestMetadata row = configreader.config.tests.get(j);
			if(row.run_mode.equalsIgnoreCase("yes")) {
				testcasestorun.add(row);
				
			}
		}
	}
	
	return testcasestorun;
	}
}
