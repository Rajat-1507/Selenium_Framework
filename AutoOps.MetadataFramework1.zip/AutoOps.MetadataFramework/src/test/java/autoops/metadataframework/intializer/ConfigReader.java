package autoops.metadataframework.intializer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import autoops.metadataframework.models.ConfigReaderModel;
import autoops.metadataframework.models.TestMetadata;
import autoops.metadataframework.utils.Xls_Reader;

public class ConfigReader {
		
	static Xls_Reader reader =new Xls_Reader("Test_Scenarios//MetaData_Framework.xlsx");
	String config_sheetname="Config";
	String value_column = "Path_Value";
	int start_row= 2;
	public ConfigReaderModel config;
	
	//Method1-ReadSheet- It will read all the parameter present in Config sheet.
	
	public ConfigReader() {
		this.config = new ConfigReaderModel();
	}
	
	public void readConfigSheet() {
		
		config.setUsername(reader.getCellData(config_sheetname, value_column , 6));
		config.setPassword(reader.getCellData(config_sheetname, value_column , 7));
		config.setEvidence_path(reader.getCellData(config_sheetname, value_column , 4));
       	
//		return config;		
		
	}
		
	//Method2-GetSheetList/GetAllSheet- Return SheetList(array)-[RG, KV]
	
	 public ArrayList<String> getAllSheet()
	    {
	       
	        String sheet_name = reader.getCellData(config_sheetname, value_column, 5);
			ArrayList<String> GetSheetList = new ArrayList<String>(Arrays.asList(sheet_name.split(",")));
	        System.out.println(GetSheetList);
	        
	        return GetSheetList;
	    }
	 
	 public void readSheet(String sheet_name) {
//		 List<TestMetadata> arr = new ArrayList<TestMetadata>();
		 int n = reader.getRowCount(sheet_name); 
		 for(int i=2;i<=n;i++) {
			 String run_mode = reader.getCellData(sheet_name, "Run_Mode", i);
			 String test_id = reader.getCellData(sheet_name, "TEST_ID", i);
			 String test_data = reader.getCellData(sheet_name, "TEST_DATA", i);
			 String expected_result = reader.getCellData(sheet_name, "EXPECTED_RESULT", i);
			 String actual_result = reader.getCellData(sheet_name, "ACTUAL_RESULT", i);
			 String xpath = reader.getCellData(sheet_name, "XPATH", i);
			 String navigation_xpath = reader.getCellData(sheet_name, "NAVIGATION_XPATH", i);
			 String status = reader.getCellData(sheet_name, "STATUS", i);
			 String evidence = reader.getCellData(sheet_name, "EVIDENCE", i);
			 
			 if(run_mode.equalsIgnoreCase("yes")) {
				 TestMetadata row = new TestMetadata(test_id,test_data, expected_result,run_mode,xpath,navigation_xpath,actual_result,evidence,status);
				 config.addTest(row); 
			 }
			 
//			 arr.add(row);
		 }
		 
//		 return arr;
	 }
	 
}
