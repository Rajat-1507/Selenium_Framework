package autoops.metadataframework.intializer;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import autoops.metadataframework.utils.Xls_Reader;

public class TestRunner extends BaseTest{
	
	static Xls_Reader reader =new Xls_Reader("Test_Scenarios//MetaData_Framework.xlsx");
	String sheetname="Config";

	@Test 
	  public  void TestAzureServices() throws Exception{
		
		String sheet_name = reader.getCellData(sheetname, "Path_Value", 5);
		List<String> SheetList = new ArrayList<String>(Arrays.asList(sheet_name.split(",")));
        System.out.println(SheetList);
		
	
	/*			 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(ssp.testintegration.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(ssp.testintegration.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
			    
		 SoftAssert softAssert = new SoftAssert();	
		 
		 String applicationGatewayResourceGroupNameElement = driver.findElement(By.xpath(ssp.testintegration.config.Constants.APPGATEWAY_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement applicationGatewayResourceGroupName = driver.findElement(By.xpath(ssp.testintegration.config.Constants.APPGATEWAY_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				if(applicationGatewayResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, applicationGatewayResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId  + "#" + test_result + ".png");
				 softAssert.assertEquals(applicationGatewayResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",applicationGatewayResourceGroupName ); 
				 ssp.testintegration.utils.Screenshot.takeSnapShot(driver,filePath  + testId  + "#" + test_result + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",applicationGatewayResourceGroupName ); 
				 softAssert.assertAll();  */
				 
	 }
	 
}
