package autoops.metadataframework.intializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import autoops.metadataframework.models.TestMetadata;

public class TestcaseHandler extends BaseTest{

	//Method-GetTestCases/TestcasesToRun-It will call sheethandler &  It will read particular sheet from array & Get all the Testcases for particular sheet which Run_mode = Yes.
	//Method-TestCasesExecutor
	
	@Test
	public void TestcaseExecutor() {
		
		ConfigReader configReader = new ConfigReader();
		configReader.readConfigSheet();
		
		List<String> allSheets = configReader.getAllSheet();
				
		for(int i=0;i<allSheets.size();i++) {
			configReader.readSheet(allSheets.get(i));
			
			for(int j=0;i<configReader.config.tests.size();j++) {
				TestMetadata test = configReader.config.tests.get(j);
				// Execute test
			}
		}
		
	}
	  
}
