package autoops.metadataframework.intializer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import io.github.bonigarcia.wdm.WebDriverManager;
import autoops.metadata.configs.Config;
import autoops.metadataframework.utils.Xls_Reader;


public class BaseTest {
	
	 DateTimeFormatter formatter
     = DateTimeFormatter.ofPattern(
         "dd-MM-yyyy_HH_mm");
 // Creating an object of LocalDateTime class
 // and getting local date and time using now()
 // method
 LocalDateTime now = LocalDateTime.now();
 // Formatting LocalDateTime to string
 String dateTimeString = now.format(formatter);
 String directory = "extentReport_" + dateTimeString + "/" ;
	
	public static WebDriver driver;
	public ExtentReports extent= new ExtentReports();
    public ExtentSparkReporter spark = new ExtentSparkReporter("ExtentReport.html");
	
	//providing path of excels sheet using casting & specifying sheetname in string.
	static Xls_Reader reader =new Xls_Reader("Test_Scenarios//MetaData_Framework.xlsx");
	String sheetname="Config";
	
	
//It will run before every class, using this function we will login onto Azure portal.
@BeforeClass
public void startFMV() throws Throwable {
	
	ConfigReader configreader = new ConfigReader();
	configreader.readConfigSheet();
	      	    
    ChromeOptions option = new ChromeOptions();
    option.addArguments("--remote-allow-origins=*");
 
	 // Launching chrome browser using webdriver manager.
	 WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver(option);
	    	 			 
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
		 
		 driver.get(Config.getProperty("url"));
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
		 
	
	 // It will fill the username using sendkeys method & click on next button.
	 driver.findElement(By.id("i0116")).sendKeys(configreader.config.getUsername());
	 Thread.sleep(4000);
	 driver.findElement(By.id("idSIButton9")).click();
	 Thread.sleep(4000);
	
	// It will fill the password using sendkeys method & click on next button.
	 driver.findElement(By.id("i0118")).sendKeys(configreader.config.getPassword());
	 Thread.sleep(4000);
	 driver.findElement(By.id("idSIButton9")).click();
	 Thread.sleep(5000);
	
	 // Click on yes pop up.
	 driver.findElement(By.id("idSIButton9")).click();
	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	 Thread.sleep(2000); 
	 				 			  
    
	  			      					    
}
	        	        
    // It will run After every class run & close the browser.
    @AfterClass
    public void stopFMV() {
	
	   driver.close();
       driver.quit();
       extent.flush();
 
}
	
	public String getScreenshot(String testCaseName,WebDriver driver) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);		
		File file = new File(System.getProperty("user.dir") + "//ExtentReport//"  + testCaseName + ".png");
		FileUtils.copyFile(source, file);		
		return System.getProperty("user.dir") + "//ExtentReport//"  +  testCaseName + ".png";		
		
	}
	
	
	public WebDriver initializeDriver() throws IOException

	{
		// properties class

		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")
				+ "//src//main//java//rahulshettyacademy//resources//GlobalData.properties");
		prop.load(fis);

		String browserName = System.getProperty("browser")!=null ? System.getProperty("browser") :prop.getProperty("browser");
		//prop.getProperty("browser");

		if (browserName.contains("chrome")) {
			ChromeOptions options = new ChromeOptions();
			WebDriverManager.chromedriver().setup();
			if(browserName.contains("headless")){
				options.addArguments("headless");
			}
			driver = new ChromeDriver(options);
			driver.manage().window().setSize(new Dimension(1440,900));//full screen

		} else if (browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver",
					"/Users/rahulshetty//documents//geckodriver");
			driver = new FirefoxDriver();
			// Firefox
		} else if (browserName.equalsIgnoreCase("edge")) {
			// Edge
			System.setProperty("webdriver.edge.driver", "edge.exe");
			driver = new EdgeDriver();
		}

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		return driver;

	}

		
	
	
}
