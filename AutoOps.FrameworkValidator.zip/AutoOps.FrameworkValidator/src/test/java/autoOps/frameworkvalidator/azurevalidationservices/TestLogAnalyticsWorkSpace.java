package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestLogAnalyticsWorkSpace extends Setup {
	
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Log_Analytics";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestLogAnalyticsWorkspaceResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    //Thread.sleep(5000);	
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
			    SoftAssert softAssert = new SoftAssert();	    
		 String logAnalyticsWorkspaceResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOG_ANALYTICS_RESOURCE_GROUP_NAME)).getText(); 
		 WebElement logAnalyticsWorkspaceResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOG_ANALYTICS_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2);
		
				 if(logAnalyticsWorkspaceResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, logAnalyticsWorkspaceResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logAnalyticsWorkspaceResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logAnalyticsWorkspaceResourceGroupName ); 
				 softAssert.assertEquals(logAnalyticsWorkspaceResourceGroupNameElement, expectedResult);
				 softAssert.assertAll();
				 
	 }
	 
	 @Test (priority=2)
	  public  void TestLogAnalyticsWorkspaceLocation() throws Exception{
		 SoftAssert softAssert1 = new SoftAssert();
		 String logAnalyticsWorkspaceLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOG_ANALYTICS_LOCATION)).getText().strip(); 
		 WebElement logAnalyticsWorkspaceLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOG_ANALYTICS_LOCATION));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3);
		
				 if(logAnalyticsWorkspaceLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, logAnalyticsWorkspaceLocationElement);
				 softAssert1.assertEquals(logAnalyticsWorkspaceLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logAnalyticsWorkspaceLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logAnalyticsWorkspaceLocation ); 
				 softAssert1.assertAll();
				 
	 }

	 
@Test (priority=3)
	  public  void TestLogAnalyticsWorkspaceName() throws Exception{
		  SoftAssert softAssert2 = new SoftAssert();
		  String LogAnalyticsWorkspaceElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOG_ANALYTICS_WORKSPACE)).getText().strip(); 
		  WebElement LogAnalyticsWorkspace = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOG_ANALYTICS_WORKSPACE));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4);
		
				 if(LogAnalyticsWorkspaceElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, LogAnalyticsWorkspaceElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert2.assertEquals(LogAnalyticsWorkspaceElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",LogAnalyticsWorkspace ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",LogAnalyticsWorkspace ); 
				 softAssert2.assertAll();
				 
				  
	 }

	
	 
	 @Test (priority=4)
	  public  void TestLogAnalyticsWorkspaceSku() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		 
		 String logAnalyticsWorkspaceSkuElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOG_ANALYTICS_SKU)).getText().strip(); 
		 WebElement logAnalyticsWorkspaceSku = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOG_ANALYTICS_SKU));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5);
		
				 if(logAnalyticsWorkspaceSkuElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, logAnalyticsWorkspaceSkuElement);
				 softAssert3.assertEquals(logAnalyticsWorkspaceSkuElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logAnalyticsWorkspaceSku ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logAnalyticsWorkspaceSku ); 
				 softAssert3.assertAll();
		 
	 }
	 
	 
	 
	 

}
