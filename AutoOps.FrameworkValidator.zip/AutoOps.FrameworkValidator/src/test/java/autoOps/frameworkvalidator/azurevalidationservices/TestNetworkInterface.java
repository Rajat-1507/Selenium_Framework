package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestNetworkInterface extends Setup {
	
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Network_Interface";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestNetworkInterfaceResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK1)).click();
			    Thread.sleep(5000);	
			   
		 SoftAssert softAssert = new SoftAssert();	
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_IFRAME)));
		 Thread.sleep(2000);
		 
		 String networkInterfaceResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement networkInterfaceResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(networkInterfaceResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, networkInterfaceResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(networkInterfaceResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",networkInterfaceResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",networkInterfaceResourceGroupName ); 
				 driver.switchTo().defaultContent();
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestNetworkInterfaceLocation() throws Exception{
	
	      SoftAssert softAssert1 = new SoftAssert();
	      driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_IFRAME)));
			 Thread.sleep(2000);
			 
		  String networkInterfaceLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_LOCATION)).getText().strip(); 
		  WebElement networkInterfaceLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_LOCATION));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(networkInterfaceLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, networkInterfaceLocationElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(networkInterfaceLocationElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",networkInterfaceLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",networkInterfaceLocation ); 
				 driver.switchTo().defaultContent();
				 softAssert1.assertAll();
				 				  
	 }

	 @Test (priority=3)
	  public  void TestNetworkInterfaceName() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 String networkInterfaceNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_NAME)).getText().strip(); 
		 WebElement networkInterfaceName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_NAME));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(networkInterfaceNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, networkInterfaceNameElement);
				 softAssert2.assertEquals(networkInterfaceNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",networkInterfaceName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",networkInterfaceName ); 
				 softAssert2.assertAll();
				 
	 }

	 
	 @Test (priority=4)
	  public  void TestNetworkInterfaceVmIpConfigName() throws Exception{
		 
		 SoftAssert softAssert3 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_IP_CONFIGURATION_CLICK)).click();
		 Thread.sleep(4000);
		 String networkInterfaceVmIpConfigNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_IP_CONFIGURATION_NAME)).getText().strip(); 
		 WebElement networkInterfaceVmIpConfigName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_IP_CONFIGURATION_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(networkInterfaceVmIpConfigNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, networkInterfaceVmIpConfigNameElement);
				 softAssert3.assertEquals(networkInterfaceVmIpConfigNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",networkInterfaceVmIpConfigName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",networkInterfaceVmIpConfigName ); 
				 softAssert3.assertAll();
		 
	 }
	 
	 @Test (priority=5)
	  public  void TestNetworkInterfacePrivateIpAddressAllocation() throws Exception{
		 
		 SoftAssert softAssert4 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_IP_CONFIGURATION_NAME)).click();
		 Thread.sleep(4000);
		 String networkInterfacePrivateIpAddressAllocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_PRIVATE_IP_ADDRESS_ALLOCATION)).getText().strip(); 
		 WebElement networkInterfacePrivateIpAddressAllocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.NETWORK_INTERFACE_PRIVATE_IP_ADDRESS_ALLOCATION));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(networkInterfacePrivateIpAddressAllocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, networkInterfacePrivateIpAddressAllocationElement);
				 softAssert4.assertEquals(networkInterfacePrivateIpAddressAllocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",networkInterfacePrivateIpAddressAllocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",networkInterfacePrivateIpAddressAllocation ); 
				 softAssert4.assertAll();
				 
			
	 }  
	
}
