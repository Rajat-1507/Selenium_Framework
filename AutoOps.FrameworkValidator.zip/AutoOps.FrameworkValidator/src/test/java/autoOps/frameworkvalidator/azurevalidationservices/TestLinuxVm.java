package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestLinuxVm  extends Setup{

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="VM_Linux";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestVirtualMachineResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    //Thread.sleep(5000);	
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
		 SoftAssert softAssert = new SoftAssert();	    
		 String virtualMachineResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement virtualMachineResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(virtualMachineResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, virtualMachineResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(virtualMachineResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualMachineResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualMachineResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestVirtualMachineName() throws Exception{
	      SoftAssert softAssert1 = new SoftAssert();
		  String virtualMachineNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_NAME)).getText().strip(); 
		  WebElement virtualMachineName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(virtualMachineNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, virtualMachineNameElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert1.assertEquals(virtualMachineNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualMachineName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualMachineName ); 
				 softAssert1.assertAll();
				 
				  
	 }

	 @Test (priority=3)
	  public  void TestVirtualMachineLocation() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 String virtualMachineLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_LOCATION)).getText().strip(); 
		 WebElement virtualMachineLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_LOCATION));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(virtualMachineLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, virtualMachineLocationElement);
				 softAssert2.assertEquals(virtualMachineLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualMachineLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualMachineLocation ); 
				 softAssert2.assertAll();
				 Thread.sleep(2000);
				 
	 }
	 
	 @Test (priority=4)
	  public  void TestVirtualMachineSize() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		
		 
		 String virtualMachineSizeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_SIZE)).getText().strip(); 
		 WebElement virtualMachineSizeSku = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_SIZE));	
		 
		// Scrolling down 
				 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",virtualMachineSizeSku );
			      Thread.sleep(3000);
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(virtualMachineSizeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, virtualMachineSizeElement);
				 softAssert3.assertEquals(virtualMachineSizeElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualMachineSizeSku ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualMachineSizeSku ); 
				 softAssert3.assertAll();
		 
	 }
	 
	 @Test (priority=12)
	  public  void TestVirtualMachineCaching() throws Exception{
	     SoftAssert softAssert4 = new SoftAssert();
		 
		 String virtualMachineCachingElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_CACHING)).getText().strip(); 
		 WebElement virtualMachineCaching = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_CACHING));	
		 
		// Scrolling down 
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",virtualMachineCaching );
		Thread.sleep(3000);
		
		 String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(virtualMachineCachingElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, virtualMachineCachingElement);
				 softAssert4.assertEquals(virtualMachineCachingElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualMachineCaching ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualMachineCaching ); 
				 softAssert4.assertAll();
				 
			
	 }  
	 
	 @Test (priority=5)
	  public  void TestVirtualMachineOSDiskName() throws Exception{
		 SoftAssert softAssert5 = new SoftAssert();
	   
		 String virtualMachineDiskOSNamelement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_OS_DISK_NAME)).getText().strip(); 
		 WebElement virtualMachineOSDiskName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_OS_DISK_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(virtualMachineDiskOSNamelement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, virtualMachineDiskOSNamelement);
				 softAssert5.assertEquals(virtualMachineDiskOSNamelement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualMachineOSDiskName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualMachineOSDiskName ); 
				 softAssert5.assertAll(); 
				 
				
	 }
	 
	 @Test (priority=11)
	  public  void TestVirtualMachineDiskType() throws Exception{
		 SoftAssert softAssert11 = new SoftAssert();
		 List<WebElement>  Alerts =  driver.findElements(By.linkText("Disks"));
	     for (WebElement e : Alerts) {
	     
	         e.click();
	         Thread.sleep(2000);
	         
	     } 
	  
		 String VirtualMachineDiskTypeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_DISK_TYPE)).getText().strip(); 
		 WebElement VirtualMachineDiskType = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_DISK_TYPE));
		 
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(VirtualMachineDiskTypeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, VirtualMachineDiskTypeElement);
				 softAssert11.assertEquals(VirtualMachineDiskTypeElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",VirtualMachineDiskType ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",VirtualMachineDiskType ); 
				 softAssert11.assertAll(); 
				 
		
		 
	 }
	 
	 @Test (priority=6)
	  public  void TestVirtualMachineOS() throws Exception{
		 SoftAssert softAssert6 = new SoftAssert();
		 String VirtualMachineOSElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_OS_XPATH)).getText().strip(); 
		 WebElement VirtualMachineOS = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_OS_XPATH))	;
		 
		// Scrolling down 
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",VirtualMachineOS );
	      Thread.sleep(3000);
	      
		  String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(VirtualMachineOSElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, VirtualMachineOSElement);
				 softAssert6.assertEquals(VirtualMachineOSElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",VirtualMachineOS ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",VirtualMachineOS ); 
				 softAssert6.assertAll();
				 
			
		 
	 } 
	 @Test (priority=7)
	  public  void TestVirtualMachineStoragePublisher() throws Exception{
		 SoftAssert softAssert7 = new SoftAssert();
		 String vmStoragePublisherElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_STORAGE_PUBLISHER)).getText(); 
		 WebElement vmStoragePublisher = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_STORAGE_PUBLISHER));
		  String testId = reader.getCellData(sheetname, "TEST ID", 10);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",10).strip();
		
				 if(vmStoragePublisherElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 10, vmStoragePublisherElement);
				 softAssert7.assertEquals(vmStoragePublisherElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 10, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",vmStoragePublisher ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",vmStoragePublisher ); 
				 softAssert7.assertAll();
				 
			
		 
	 } 
	 @Test (priority=8)
	  public  void TestVirtualMachineStorageOffer() throws Exception{
		 SoftAssert softAssert8 = new SoftAssert();
		 String virtualMachineStorageOfferElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_STORAGE_OFFER)).getText().strip(); 
		 WebElement virtualMachineStorageOffer= driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_STORAGE_OFFER));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 11);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT", 11).strip();
		
				 if(virtualMachineStorageOfferElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 11, virtualMachineStorageOfferElement);
				 softAssert8.assertEquals(virtualMachineStorageOfferElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 11, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualMachineStorageOffer ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualMachineStorageOffer ); 
				 softAssert8.assertAll();
				 
				
		 
	 } 
	 
	 @Test (priority=9)
	  public  void TestVirtualMachineStorageSku() throws Exception{
		 SoftAssert softAssert9 = new SoftAssert();
	  	 
		 String virtualMachineStorageSkuElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_STORAGE_PLAN)).getText().strip(); 
		 WebElement virtualMachineStorageSku= driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_STORAGE_PLAN));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 12);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT", 12).strip();
		
				 if(virtualMachineStorageSkuElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 12, virtualMachineStorageSkuElement);
				 softAssert9.assertEquals(virtualMachineStorageSkuElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 12, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualMachineStorageSku);
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualMachineStorageSku ); 
				 softAssert9.assertAll();
				 
				
		 
	 } 
	 
	 @Test (priority=11)
	  public  void TestVirtualMachineComputerName() throws Exception{
		 SoftAssert softAssert10 = new SoftAssert();
		 String virtualMachineComputerNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_COMPUTER_NAME)).getText().strip(); 
		 WebElement virtualMachineComputerName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VM_COMPUTER_NAME));
			
		// Scrolling down 
				 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",virtualMachineComputerName );
			      Thread.sleep(3000);
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 13);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT", 13).strip();
		
				 if(virtualMachineComputerNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 13, virtualMachineComputerNameElement);
				 softAssert10.assertEquals(virtualMachineComputerNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 13, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualMachineComputerName);
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualMachineComputerName ); 
				 softAssert10.assertAll();
				 Thread.sleep(2000);
				 
				
		 
	 } 
	 
}
