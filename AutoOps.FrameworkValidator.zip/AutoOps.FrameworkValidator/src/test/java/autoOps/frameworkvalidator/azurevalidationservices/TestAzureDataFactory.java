package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestAzureDataFactory extends Setup {

	  Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="ADF";
	  String status;
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	  
	 
	 @Test (priority=1)
	  public  void TestADFResourceGroupName() throws Exception{
	          
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();	
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
			    
			    SoftAssert softAssert = new SoftAssert(); 
			    
		 String aDFResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		 WebElement aDFResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_RESOURCE_GROUP_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(aDFResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, aDFResourceGroupNameElement);
				 softAssert.assertEquals(aDFResourceGroupNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",aDFResourceGroupName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",aDFResourceGroupName ); 
				 
				  softAssert.assertAll();
				  
				
	 }
	 
	 @Test (priority=2)
	  public  void TestADFLocation() throws Exception{
		 	
		 SoftAssert softAssert1 = new SoftAssert();    
		 String aDFLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_LOCATION_XPATH)).getText().strip(); 
		 WebElement aDFLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_LOCATION_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(aDFLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, aDFLocationElement);
				 softAssert1.assertEquals(aDFLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",aDFLocation ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",aDFLocation ); 
				  softAssert1.assertAll();		  
				
	 }
	 
	 @Test (priority=3)
	  public  void TestADFName() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();	    
		 String aDFNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_NAME_XPATH)).getText().strip(); 
		 WebElement aDFName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(aDFNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, aDFNameElement);
				 softAssert2.assertEquals(aDFNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",aDFName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",aDFName ); 
				  softAssert2.assertAll();		  
				
	 }
	 
	 @Test (priority=4)
	  public  void TestADFOrganizatioName() throws Exception{
			
		 SoftAssert softAssert3 = new SoftAssert();	    
		 String aDFOrganizatioNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_SUBSCRIPTION)).getText().strip(); 
		 WebElement aDFOrganizatioName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_SUBSCRIPTION));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(aDFOrganizatioNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, aDFOrganizatioNameElement);
				 softAssert3.assertEquals(aDFOrganizatioNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",aDFOrganizatioName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",aDFOrganizatioName ); 
				
				  softAssert3.assertAll();		  
				
	 }
	 
	 
	  @Test (priority=5)
	  public  void TestADFMetricAlertName() throws Exception{
		  
		  SoftAssert softAssert4 = new SoftAssert();
		  driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ALERT_SIDEBAR_CLICK)).click();
		   Thread.sleep(4000);
		   driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_MANAGE_ALERT_RULES_CLICK_XPATH)).click();
		   Thread.sleep(4000);
			
	     
		 String aDFMetricAlertNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_NAME_XPATH)).getText().strip(); 
		 WebElement aDFMetricAlertName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(aDFMetricAlertNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, aDFMetricAlertNameElement);
				 softAssert4.assertEquals(aDFMetricAlertNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",aDFMetricAlertName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",aDFMetricAlertName ); 
				  softAssert4.assertAll();		  
				
	 }
	 
	 @Test (priority=6)
	  public  void TestADFMetricAlertDescription() throws Exception{
		 
		 SoftAssert softAssert5 = new SoftAssert();
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_NAME_XPATH)).click();
		 Thread.sleep(3000);
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_ALERT_IFRAME)));
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_PROPERTIES_XPATH)).click();
		 Thread.sleep(5000);
		 driver.switchTo().defaultContent();
			    
		 String aDFMetricAlertDescriptionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_DESCRIPTION_XPATH)).getText().strip(); 
		 WebElement aDFMetricAlertDescription = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_DESCRIPTION_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		 
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",aDFMetricAlertDescription);
		 Thread.sleep(3000);
		 
		 
		
				 if(aDFMetricAlertDescriptionElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, aDFMetricAlertDescriptionElement);
				 softAssert5.assertEquals(aDFMetricAlertDescriptionElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",aDFMetricAlertDescription ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",aDFMetricAlertDescription ); 
				  softAssert5.assertAll();		  
				
	 }
	 
	 @Test (priority=7)
	  public  void TestADFFrequency() throws Exception{
		 
		 SoftAssert softAssert6 = new SoftAssert();
		
		 
		 String aDFFrequencyElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_FREQUENCY_XPATH)).getText().strip(); 
		 WebElement aDFFrequency = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_FREQUENCY_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(aDFFrequencyElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, aDFFrequencyElement);
				 softAssert6.assertEquals(aDFFrequencyElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",aDFFrequency ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",aDFFrequency ); 
				  softAssert6.assertAll();		  
				
	 }
	 
	 @Test (priority=8)
	  public  void TestADFWindowSize() throws Exception{
		 SoftAssert softAssert7 = new SoftAssert(); 
		 
		 String aDFWindowSizeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_WINDOW_SIZE_XPATH)).getText().strip(); 
		 WebElement aDFWindowSize = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_WINDOW_SIZE_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(aDFWindowSizeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, aDFWindowSizeElement);
				 softAssert7.assertEquals(aDFWindowSizeElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",aDFWindowSize ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",aDFWindowSize ); 
				  softAssert7.assertAll();		  
				
	 }
/*	 
	 @Test (priority=9)
	  public  void TestADFThreshold() throws Exception{
		 
		 SoftAssert softAssert8 = new SoftAssert();	   
		 
		 String aDFThresholdElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_THRESHOLD_XPATH)).getText().strip(); 
		 WebElement aDFThreshold = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_THRESHOLD_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 10);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",10).strip();
		
				 if(aDFThresholdElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 10, aDFThresholdElement);
				 softAssert8.assertEquals(aDFThresholdElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 10, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",aDFThreshold ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath + testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",aDFThreshold ); 
				  softAssert8.assertAll();		  
				
	 } */
	 
	 @Test (priority=10)
	  public  void TestADFScheduleTrigger() throws Exception{
		 
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(6000));
			
		 SoftAssert softAssert9= new SoftAssert();
		    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_BREADCRUM_CLICK)).click();
	        Thread.sleep(3000);
	        driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_OVERVIEW_CLICK)).click();
	        Thread.sleep(4000);
	        
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
	        
		// click on lunch Workspace   
	        driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_LUNCH_STUDIO)).click();
	        Thread.sleep(20000);
	        
	        Set<String> windowhandles = driver.getWindowHandles();
	        Iterator<String> iterator =windowhandles.iterator();
	        String parentwindow = iterator.next();
	        String childwindow = iterator.next();
	        
	        driver.switchTo().window(childwindow);
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_MANAGE_CLICK))).click();
	        Thread.sleep(2000);
	        
	        driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_TRIGGER_CLICK)).click();
	        Thread.sleep(2000);
	       	        
			    
		 String ADFScheduleTriggerElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_SCHEDULE_TRIGGER_NAME)).getText().strip(); 
		 WebElement ADFScheduleTrigger = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_SCHEDULE_TRIGGER_NAME));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 13);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",13).strip();
		
				 if(ADFScheduleTriggerElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 13, ADFScheduleTriggerElement);
				 softAssert9.assertEquals(ADFScheduleTriggerElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 13, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",ADFScheduleTrigger ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath + testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",ADFScheduleTrigger ); 
				  driver.close();
				  driver.switchTo().window(parentwindow);
				  softAssert9.assertAll();		  
				
	 } 
}
