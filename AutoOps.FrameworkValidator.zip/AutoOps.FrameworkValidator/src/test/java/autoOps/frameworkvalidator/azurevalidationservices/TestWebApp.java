package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestWebApp extends Setup {

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Web-App";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestWebAppResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(1000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(2000);
			    
			    driver.findElement(By.xpath("/html/body/div[1]/div[4]/main/div[3]/div[2]/section[2]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[2]/div[2]/div[2]/div/div[3]/div/div/div[2]/div/div[2]/div[1]/div/div/div[1]/div[2]/div/a")).click();	
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
			 
			    SoftAssert softAssert = new SoftAssert();
		 String webAppResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.WEB_APP_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement webAppResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.WEB_APP_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(webAppResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, webAppResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(webAppResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",webAppResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",webAppResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
	 @Test (priority=2)
	  public  void TestWebAppLocation() throws Exception{	 
		 SoftAssert softAssert1 = new SoftAssert();    
		 String webAppLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.WEB_APP_LOCATION)).getText().strip(); 
		 WebElement webAppLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.WEB_APP_LOCATION));
		 String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(webAppLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, webAppLocationElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(webAppLocationElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",webAppLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",webAppLocation ); 
				 softAssert1.assertAll();
				 
	 }
	 
	 @Test (priority=3)
	  public  void TestWebAppName() throws Exception{
	
		 SoftAssert softAssert2 = new SoftAssert();		 
			    
		 String webAppNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.WEB_APP_NAME)).getText().strip(); 
		 WebElement webAppName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.WEB_APP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(webAppNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, webAppNameElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert2.assertEquals(webAppNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",webAppName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",webAppName ); 
				 softAssert2.assertAll();
				 
	 }
}
