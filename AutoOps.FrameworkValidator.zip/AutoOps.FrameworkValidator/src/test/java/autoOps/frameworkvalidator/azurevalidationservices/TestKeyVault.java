package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.Test;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;


public class TestKeyVault extends Setup{
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="KV";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;

	    
	 
	 @Test (priority=1)
	  public  void TestKeyVaultResourceGroupName() throws Exception{
		 		
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 System.out.println(test_result);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    Thread.sleep(10000);	
			  
			    SoftAssert softAssert = new SoftAssert();	   
			    
		 String keyVaultResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		 WebElement keyVaultResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_RESOURCE_GROUP_NAME_XPATH));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);
		// System.out.println(testId);
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2);
		// System.out.println(expectedResult);
		
				 if(keyVaultResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, keyVaultResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(keyVaultResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
 @Test (priority=2)
	  public  void TestKeyVaultName() throws Exception{
	 SoftAssert softAssert1 = new SoftAssert();
		  String keyVaultNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_NAME_XPATH)).getText().strip(); 
		  WebElement keyVaultName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_NAME_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(keyVaultNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, keyVaultNameElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(keyVaultNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultName ); 
				 softAssert1.assertAll();
				 
				  
	 }
 
	 @Test (priority=3)
	  public  void TestKeyVaultLocation() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 String keyVaultLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_LOCATION_XPATH)).getText().strip(); 
		 WebElement keyVaultLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_LOCATION_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(keyVaultLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, keyVaultLocationElement);
				 softAssert2.assertEquals(keyVaultLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultLocation ); 
				 softAssert2.assertAll();
				 
	 }

	 
	 @Test (priority=4)
	  public  void TestKeyVaultSku() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		 String keyVaultSkuElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_SKU_XPATH)).getText().strip(); 
		 WebElement keyVaultSku = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_SKU_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(keyVaultSkuElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, keyVaultSkuElement);
				 softAssert3.assertEquals(keyVaultSkuElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultSku ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultSku ); 
				 softAssert3.assertAll();
		 
	 }
	 
	 @Test (priority=5)
	  public  void TestKeyVaultPurgeProtection() throws Exception{
		 SoftAssert softAssert4 = new SoftAssert();
		 String keyVaultPurgeProtectionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_PRUGE_PROTECTION_XPATH)).getText().strip(); 
		 WebElement keyVaultPurgeProtection = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_PRUGE_PROTECTION_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(keyVaultPurgeProtectionElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, keyVaultPurgeProtectionElement);
				 softAssert4.assertEquals(keyVaultPurgeProtectionElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultPurgeProtection ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultPurgeProtection ); 
				 softAssert4.assertAll();
				 
			
	 }
	 

	 @Test (priority=6)
	  public  void TestKeyVaultRetentionDays() throws Exception{
		 SoftAssert softAssert5 = new SoftAssert();
	  	 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_PRUGE_PROTECTION_XPATH)).click();
	  	 Thread.sleep(4000);
	  	 
	  	Actions at = new Actions(driver);
	      at.sendKeys(Keys.PAGE_DOWN).build().perform();
	      Thread.sleep(2000);
	  
		 String keyVaultRetentionDaysElement = autoOps.frameworkvalidator.config.Constants.KEYVAULT_RETENTION_DAYS_XPATH; 
		 WebElement keyVaultRetentionDays = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_RETENTION_DAYS));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(keyVaultRetentionDaysElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				 
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, keyVaultRetentionDaysElement);
				 softAssert5.assertEquals(keyVaultRetentionDaysElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultRetentionDays ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultRetentionDays ); 
				 softAssert5.assertAll(); 
				 
		
		 
	 }
	 
	 @Test (priority=7)
	  public  void TestKeyVaultDeployment() throws Exception{
		 SoftAssert softAssert6 = new SoftAssert();
	  	 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_ACCESS_CONFIG_CLICK)).click();
	  	 Thread.sleep(4000);
	  		  
		 String keyVaultDeploymentElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_DEPLOYMENT)).getText().strip();  
		 WebElement keyVaultDeployment = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_DEPLOYMENT));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(keyVaultDeploymentElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				 
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, keyVaultDeploymentElement);
				 softAssert6.assertEquals(keyVaultDeploymentElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultDeployment ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultDeployment ); 
				 softAssert6.assertAll(); 
				 
		
		 
	 }
	 
	 @Test (priority=8)
	  public  void TestKeyVaultDeploymentTemplete() throws Exception{
		 
		 SoftAssert softAssert7 = new SoftAssert();
	  		  	  
		 String keyVaultDeploymentTempleteElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_DEPLOYMENT_TEMPLETE)).getText().strip();
		 WebElement keyVaultDeploymentTemplete = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_DEPLOYMENT_TEMPLETE));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(keyVaultDeploymentTempleteElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				 
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, keyVaultDeploymentTempleteElement);
				 softAssert7.assertEquals(keyVaultDeploymentTempleteElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultDeploymentTemplete ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultDeploymentTemplete ); 
				 softAssert7.assertAll(); 
				 		
		 
	 }
	 
	 
	 @Test (priority=9)
	  public  void TestKeyVaultAccessPoliciesName() throws Exception{
		 
		 SoftAssert softAssert8= new SoftAssert();
	  	
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_ACCESS_POLICIES_CLICK)).click();
	  	 Thread.sleep(4000);
	  	 
		 String keyVaultAccessPoliciesNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_ACCESS_POLICIES_NAME)).getText().strip();
		 WebElement keyVaultAccessPoliciesNameTemplete = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_ACCESS_POLICIES_NAME));
			
		// Scrolling down 
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",keyVaultAccessPoliciesNameTemplete );
	      Thread.sleep(3000);
		  String testId = reader.getCellData(sheetname, "TEST ID", 10);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",10).strip();
		
				 if(keyVaultAccessPoliciesNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
					
				 }
				 
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 10, keyVaultAccessPoliciesNameElement);
				 softAssert8.assertEquals(keyVaultAccessPoliciesNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 10, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultAccessPoliciesNameTemplete ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultAccessPoliciesNameTemplete ); 
				 softAssert8.assertAll(); 		
		 
	 }
	 
	 
	 @Test (priority=11)
	  public  void TestKeyVaultConnectivityMethod() throws Exception{
		 
		 SoftAssert softAssert10= new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_NETWORKING_CLICK)).click();
	  	 Thread.sleep(4000);
	  		  	  
		 String keyVaultConnectivityMethodElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_CONNECTIVITY_METHOD)).getText().strip(); 
		 WebElement keyVaultConnectivityMethod = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_CONNECTIVITY_METHOD));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 11);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",11).strip();
		
				 if(keyVaultConnectivityMethodElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
					
				 }
				 
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 11, keyVaultConnectivityMethodElement);
				 softAssert10.assertEquals(keyVaultConnectivityMethodElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 11, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",keyVaultConnectivityMethod ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",keyVaultConnectivityMethod ); 
				 softAssert10.assertAll(); 
				 Thread.sleep(2000);
		 
	 }  
	 
}
