package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;
public class TestSqlServer extends Setup{

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="SQL-SERVER";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestSqlServerResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();	
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
			    
		 SoftAssert softAssert = new SoftAssert();	 
		
		 String sqlServerResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		 WebElement sqlServerResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_RESOURCE_GROUP_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(sqlServerResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				   
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, sqlServerResourceGroupNameElement);
				 softAssert.assertEquals(sqlServerResourceGroupNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sqlServerResourceGroupName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sqlServerResourceGroupName ); 
				  softAssert.assertAll();
				  
				
	 }
	 
@Test (priority=2)
	  public  void TestSqlServerLocation() throws Exception{
	
	      SoftAssert softAssert1 = new SoftAssert();
	      ExtentTest test = extent.createTest("SQL_Server_Name");
		  String sqlServerLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_LOCATION_XPATH)).getText().strip(); 
		  WebElement sqlServerLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_LOCATION_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(sqlServerLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				  
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, sqlServerLocationElement);
				 softAssert1.assertEquals(sqlServerLocationElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				  JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sqlServerLocation ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", sqlServerLocation);
				  reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				  softAssert1.assertAll();
				 
			
	 }

	 @Test (priority=3)
	  public  void TestSqlServerName() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 ExtentTest test = extent.createTest("SQL_Server_Name");
		 String sqlServerNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_NAME_XPATH)).getText().strip(); 
		 WebElement sqlServerName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_NAME_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(sqlServerNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				 
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					 
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, sqlServerNameElement);
				 softAssert2.assertEquals(sqlServerNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sqlServerName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sqlServerName );
				  reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				  softAssert2.assertAll();
				 
			
	 }
	 
	 @Test (priority=4)
	  public  void TestAdministratorLogin() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		 
		 String sqlServerAdministratorLoginElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_ADMIN_LOGIN_XPATH)).getText().strip(); 
		 WebElement sqlServerAdministratorLogin = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_ADMIN_LOGIN_XPATH));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(sqlServerAdministratorLoginElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				   
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, sqlServerAdministratorLoginElement);
				 softAssert3.assertEquals(sqlServerAdministratorLoginElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sqlServerAdministratorLogin ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sqlServerAdministratorLogin );
				  reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				  softAssert3.assertAll();
				 
				
	 }
	
	 
	 @Test (priority=5)
	  public  void TestSqlServerDatabaseName() throws Exception{
		 
		 SoftAssert softAssert4 = new SoftAssert();
		
			
		 String sqlServerDatabaseNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_DATABASE_NAME_XPATH)).getText().strip(); 
		 WebElement sqlServerDatabaseName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_DATABASE_NAME_XPATH));
		
		 Actions at = new Actions(driver);
		 at.sendKeys(Keys.PAGE_DOWN).build().perform();
		 Thread.sleep(2000);
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(sqlServerDatabaseNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				  
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					 
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, sqlServerDatabaseNameElement);
				 softAssert4.assertEquals(sqlServerDatabaseNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 Thread.sleep(2000);
				 
				 // Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", sqlServerDatabaseName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", sqlServerDatabaseName);
				  reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				  softAssert4.assertAll();
				 
		
	 }
	 
	 
}
