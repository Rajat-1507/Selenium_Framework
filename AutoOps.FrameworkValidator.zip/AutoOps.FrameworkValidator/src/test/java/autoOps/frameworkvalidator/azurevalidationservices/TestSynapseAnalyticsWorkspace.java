package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestSynapseAnalyticsWorkspace extends Setup{
	
	 Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="SynapseAnalytics";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	  
	  public  void clickfunction(String Xpath) throws Exception {
			
		  driver.findElement(By.xpath(Xpath)).click();
		  Thread.sleep(4000);
       }
	 
	 
	 @Test (priority=1)
	  public  void TestSynapseAnalyticsResourceGroupName() throws Exception{
		 		 Thread.sleep(3000);
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();	
			    Thread.sleep(8000);
			 
			    
		 SoftAssert softAssert = new SoftAssert();	    
		 String synapseAnalyticsResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		 WebElement synapseAnalyticsResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_RESOURCE_GROUP_NAME_XPATH));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(synapseAnalyticsResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, synapseAnalyticsResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(synapseAnalyticsResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapseAnalyticsResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapseAnalyticsResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestSynapseAnalyticsName() throws Exception{
	
	      SoftAssert softAssert1 = new SoftAssert();
	      
		  String synapseAnalyticsNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_WORKSPACE_NAME_XPATH)).getText().strip(); 		 
		  WebElement synapseAnalyticsName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_WORKSPACE_NAME_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		  
		  
		  
				 if(synapseAnalyticsNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, synapseAnalyticsNameElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(synapseAnalyticsNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapseAnalyticsName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapseAnalyticsName ); 
				 softAssert1.assertAll();
				 
				  
	 } 

	 @Test (priority=3)
	  public  void TestSynapseAnalyticsLocation() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 String synapseAnalyticsLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_LOCATION_XPATH)).getText().strip(); 
		 WebElement synapseAnalyticsLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_LOCATION_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(synapseAnalyticsLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, synapseAnalyticsLocationElement);
				 softAssert2.assertEquals(synapseAnalyticsLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapseAnalyticsLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapseAnalyticsLocation ); 
				 softAssert2.assertAll();
				 
	 } 
	 
	 
	 @Test (priority=4)
	  public  void TestFileSystemName() throws Exception{
		 
		 SoftAssert softAssert3 = new SoftAssert();
		 String fileSystemNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_FILESYSTEM_NAME)).getText().strip(); 
		 WebElement fileSystemName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_FILESYSTEM_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(fileSystemNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, fileSystemNameElement);
				 softAssert3.assertEquals(fileSystemNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",fileSystemName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",fileSystemName ); 
				 softAssert3.assertAll();
		 
	 }

	 
	 @Test (priority=5)
	  public  void TestSQLAdminUserName() throws Exception{
		 SoftAssert softAssert4 = new SoftAssert();
		 String SynapseAnalyticsSQLAdminUserNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_ADMIN_USERNAME_XPATH)).getText().strip(); 
		 WebElement SynapseAnalyticsSQLAdminUserName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_ADMIN_USERNAME_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(SynapseAnalyticsSQLAdminUserNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, SynapseAnalyticsSQLAdminUserNameElement);
				 softAssert4.assertEquals(SynapseAnalyticsSQLAdminUserNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsSQLAdminUserName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsSQLAdminUserName ); 
				 softAssert4.assertAll();
		 
	 }
	 
	 @Test (priority=7)
	  public  void TestDoubleEncryption() throws Exception{
		 
		 SoftAssert softAssert5 = new SoftAssert();
		 clickfunction(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_ENCRYPTION_CLICK);
		 
		 String doubleEncryptionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_DOUBLE_ENCRYPTION)).getText().strip(); 
		 WebElement doubleEncryption = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_DOUBLE_ENCRYPTION));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(doubleEncryptionElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, doubleEncryptionElement);
				 softAssert5.assertEquals(doubleEncryptionElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",doubleEncryption ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",doubleEncryption ); 
				 softAssert5.assertAll();
		 
	 }
	 
	 
	 @Test (priority=6)
	  public  void TestManagedVirtualNetwork() throws Exception{
		 
		 SoftAssert softAssert6 = new SoftAssert();
		 
		 
		 String ManagedVirtualNetworkElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_MANAGED_VIRTUAL_NETWORK)).getText().strip(); 
		 WebElement ManagedVirtualNetwork = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_MANAGED_VIRTUAL_NETWORK));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(ManagedVirtualNetworkElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, ManagedVirtualNetworkElement);
				 softAssert6.assertEquals(ManagedVirtualNetworkElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",ManagedVirtualNetwork ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",ManagedVirtualNetwork ); 
				 softAssert6.assertAll();
		 
	 }
	 
	 
	 @Test (priority=8)
	  public  void TestPublicNetworkAccess() throws Exception{
		 
		 SoftAssert softAssert7 = new SoftAssert();
		 clickfunction(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_NETWORKING_CLICK);
		 
		 String publicNetworkAccessElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_PUBLIC_NETWORK_ACCESS)).getText().strip(); 
		 WebElement publicNetworkAccess = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_PUBLIC_NETWORK_ACCESS));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(publicNetworkAccessElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, publicNetworkAccessElement);
				 softAssert7.assertEquals(publicNetworkAccessElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicNetworkAccess ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicNetworkAccess ); 
				 softAssert7.assertAll();	 
	 }
	 
	 
	 @Test (priority=9)
	  public  void TestOnDemandEndpoint() throws Exception{
		 
		 SoftAssert softAssert8 = new SoftAssert();
		 
		 clickfunction(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_PRIVATE_ENDPOINT_CONNECTION_CLICK);
		 
		 String onDemandEndpointElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_ON_DEMAND_ENDPOINT)).getText().strip(); 
		 WebElement onDemandEndpoint = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_ON_DEMAND_ENDPOINT));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 10);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",10).strip();
		
				 if(onDemandEndpointElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 10, onDemandEndpointElement);
				 softAssert8.assertEquals(onDemandEndpointElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 10, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",onDemandEndpoint ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",onDemandEndpoint ); 
				 softAssert8.assertAll();	 
	 }
	 
	
	 @Test (priority=10)
	  public  void TestManagedEndpoint() throws Exception{
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(5000));
		 SoftAssert softAssert9 = new SoftAssert();
		 // click on overview
		 clickfunction(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_OVERVIEW_CLICK);
		 
		// click on lunch Workspace   
	        driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_LUNCH_STUDIO)).click();
	        Thread.sleep(20000);
	        
	        Set<String> windowhandles = driver.getWindowHandles();
	        Iterator<String> iterator =windowhandles.iterator();
	        String parentwindow = iterator.next();
	        String childwindow = iterator.next();
	        
	        driver.switchTo().window(childwindow);
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_MANAGE_CLICK))).click();
	        
	        clickfunction(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_MANAGE_ENDPOINT_CLICK);
	        
		 String managedEndpointElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_MANAGED_ENDPOINT)).getText().strip(); 
		 WebElement managedEndpoint = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_MANAGED_ENDPOINT));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 11);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",11).strip();
		
				 if(managedEndpointElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 11, managedEndpointElement);
				 softAssert9.assertEquals(managedEndpointElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 11, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",managedEndpoint ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",managedEndpoint ); 
				 Thread.sleep(3000);
				 driver.close();
				  driver.switchTo().window(parentwindow);
				 softAssert9.assertAll();	 
				 Thread.sleep(2000);
	 }
	 

}
