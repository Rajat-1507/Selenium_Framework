package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestVirtualNetworkGateway extends Setup {

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Virtual_Network_Gateway";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestVirtualNetworkGatewayResourceGroupName() throws Exception{
	
		 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
		 Thread.sleep(2000);
		 System.out.println(test_result);
	    
	  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
	    Thread.sleep(3000);
	    
	    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
	    Thread.sleep(10000);
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
		 SoftAssert softAssert = new SoftAssert();	    
		 String vNGResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement vngResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(vNGResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, vNGResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(vNGResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",vngResourceGroupName ); 

autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",vngResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestVirtualNetworkGatewayName() throws Exception{
	      SoftAssert softAssert1 = new SoftAssert();
		  String vGNNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_NAME)).getText().strip(); 
		  WebElement vGNName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(vGNNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, vGNNameElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert1.assertEquals(vGNNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",vGNName ); 

autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",vGNName ); 
				 softAssert1.assertAll();
				 
				  
	 }

	 @Test (priority=3)
	  public  void TestVirtualNetworkGatewayLocation() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 String vGNLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_LOCATION)).getText().strip(); 
		 WebElement vNGLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_LOCATION));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(vGNLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, vGNLocationElement);
				 softAssert2.assertEquals(vGNLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",vNGLocation ); 

autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",vNGLocation ); 
				 softAssert2.assertAll();
				 
	 }

	 
	 @Test (priority=4)
	  public  void TestVirtualNetworkGatewaySku() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		 String vNGSkuElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_SKU)).getText().strip(); 
		 WebElement vNGSku = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_SKU));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(vNGSkuElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, vNGSkuElement);
				 softAssert3.assertEquals(vNGSkuElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",vNGSku ); 

autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",vNGSku ); 
				 softAssert3.assertAll();
		 
	 }
	 
	 @Test (priority=5)
	  public  void TestVirtualNetworkGatewayType() throws Exception{
		 SoftAssert softAssert4 = new SoftAssert();
		 String vNGTypeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_TYPE)).getText().strip(); 
		 WebElement vNGType = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_TYPE));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(vNGTypeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, vNGTypeElement);
				 softAssert4.assertEquals(vNGTypeElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",vNGType ); 

autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",vNGType ); 
				 softAssert4.assertAll();
				 
			
	 }  
	 
	 @Test (priority=6)
	  public  void TestVirtualNetworkGatewayVPNType() throws Exception{
		 SoftAssert softAssert5 = new SoftAssert();
		 String vNGVPNTypeelement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_VPN_TYPE)).getText().strip(); 
		 WebElement vNGVPNType = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_VPN_TYPE));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(vNGVPNTypeelement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, vNGVPNTypeelement);
				 softAssert5.assertEquals(vNGVPNTypeelement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",vNGVPNType ); 

autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",vNGVPNType ); 
				 softAssert5.assertAll(); 			 
				
	 }	 
	 
	 @Test (priority=7)
	  public  void TestVirtualNetworkGatewayVNetName() throws Exception{
		 SoftAssert softAssert6 = new SoftAssert();
		 String vNGVNetNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_VIRTUAL_NETWORK_NAME)).getText().strip(); 
		 WebElement vNGVNetName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_VIRTUAL_NETWORK_NAME))	;
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(vNGVNetNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, vNGVNetNameElement);
				 softAssert6.assertEquals(vNGVNetNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",vNGVNetName ); 

autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",vNGVNetName ); 
				 softAssert6.assertAll();
				 
	 }
	 
	 @Test (priority=8)
	  public  void TestVirtualNetworkGatewayActiveMode() throws Exception{
		 SoftAssert softAssert7 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_CONFIGURATION_CLICK)).click();
		 Thread.sleep(2000);
		 String vNGActiveModeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_ACTIVE_MODE)).getText().strip(); 
		 WebElement vNGActiveMode = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNG_ACTIVE_MODE))	;
		  String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(vNGActiveModeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, vNGActiveModeElement);
				 softAssert7.assertEquals(vNGActiveModeElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",vNGActiveMode ); 

autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",vNGActiveMode ); 
				 softAssert7.assertAll();
				 
	 }	
	
}
