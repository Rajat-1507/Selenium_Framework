package autoOps.frameworkvalidator.azurevalidationservices;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestResourceGroup extends Setup {

	  Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="RG";
	  String status;
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;


	 @Test (priority=1)
	  public  void TestResourceGroupName() throws Exception{
		
		int row_count =reader.getRowCount(sheetname);
		System.out.println(row_count);
		  SoftAssert softAssert = new SoftAssert();
		  Thread.sleep(4000);
		  		 
		  String resourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.RESOURCE_GROUP_NAME_XPATH)).getText().strip();
		  System.out.println(resourceGroupNameElement);
		  WebElement resourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.RESOURCE_GROUP_NAME_XPATH));
		  Thread.sleep(4000);
		  String testId = reader.getCellData(sheetname, "TEST ID", 2);	
		  System.out.println(testId);
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2);
		  System.out.println(expectedResult);
		
				 if(resourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				  
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, resourceGroupNameElement);
				 softAssert.assertEquals(resourceGroupNameElement, expectedResult);
				
				 
				// Highlighting element & Taking screenshot
				
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",resourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +  testId + ".png" );
				 Thread.sleep(1000);				 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",resourceGroupName ); 
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertAll();
			  
		
	}

	@Test (priority=2)
	public  void TestResourceGroupLocation() throws Exception{
		
		SoftAssert softAssert1 = new SoftAssert();
		
		String resourceGroupLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.RESOURCE_GROUP_LOCATION_XPATH)).getText(); 
		WebElement resourceGroupLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.RESOURCE_GROUP_LOCATION_XPATH));
		String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT", 3);
		System.out.println(expectedResult);
		String testId = reader.getCellData(sheetname, "TEST ID" , 3);
		
		 
		 if( resourceGroupLocationElement.equalsIgnoreCase(expectedResult)) {
			 String  status= "pass";
			 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
			
		
		 }
		 else {
			String status="fail";
			reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
			
			
		 }
		 
		 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, resourceGroupLocationElement);
		 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
		 softAssert1.assertEquals(resourceGroupLocationElement, expectedResult);
		    
		  //Highlighting element & Taking screenshot	
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",resourceGroupLocation ); 
		 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
		 Thread.sleep(1000);
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",resourceGroupLocation ); 
		 softAssert1.assertAll();
		 
		
		 
	}
	
	@Test (priority=3)
	public  void TestResourceGroupTag() throws Exception{
		SoftAssert softAssert2 = new SoftAssert();
		
		String resourceGroupTagElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.RESOURCE_GROUP_TAGS_XPATH)).getText(); 
		WebElement resourceGroupTag = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.RESOURCE_GROUP_TAGS_XPATH));
		String lines[] = resourceGroupTagElement.split("\\r?\\n");
		System.out.println(lines[0]);
		System.out.println(lines[1]);
		System.out.println(lines[2]);
		String ResourceGroupTagElement1="";
		for (String Tag : lines)
		{    
			ResourceGroupTagElement1= ResourceGroupTagElement1 + Tag + " ";  
				
		       }
		
		String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4);
		String testId = reader.getCellData(sheetname, "TEST ID" , 4);
		 
		 if( ResourceGroupTagElement1.strip().equalsIgnoreCase(expectedResult)) {
		     String  status= "pass";
		     reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
		   
		     
		 }
		 else {
			String status="fail";
			reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
			
		 }
		 
		 	softAssert2.assertEquals(ResourceGroupTagElement1.strip(), expectedResult); 
		 	
		    reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, resourceGroupTagElement);
		    reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
		 
		 
		 
		 //Highlighting element & Taking screenshot 
		  JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
		  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",resourceGroupTag ); 
		  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
		  Thread.sleep(1000);
		  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",resourceGroupTag ); 
		  softAssert2.assertAll();
			 		
	} 
	
	@Test (priority=4)
	public  void TestResourceGroupSubcription() throws Exception{
		
		SoftAssert softAssert3 = new SoftAssert();
		
		String RGSubcriptionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.RESOURCE_GROUP_SUBSCRIPTION)).getText(); 
		WebElement RGSubcription = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.RESOURCE_GROUP_SUBSCRIPTION));
		String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5);
		 
		String testId = reader.getCellData(sheetname, "TEST ID" , 5);
		 
		 if( RGSubcriptionElement.equalsIgnoreCase(expectedResult)) {
			 String  status= "pass";
			 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
			
		
		 }
		 else {
			String status="fail";
			reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
			
			
		 }
		 
		 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, RGSubcriptionElement);
		 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
		 softAssert3.assertEquals(RGSubcriptionElement, expectedResult);
		    
		  //Highlighting element & Taking screenshot	
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",RGSubcription ); 
		 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
		 Thread.sleep(1000);
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",RGSubcription ); 
		 softAssert3.assertAll();	
		 Thread.sleep(2000);
		 
	}   
}
