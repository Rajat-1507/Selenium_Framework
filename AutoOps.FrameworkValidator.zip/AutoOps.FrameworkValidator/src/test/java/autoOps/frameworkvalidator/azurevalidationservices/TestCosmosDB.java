package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestCosmosDB extends Setup{
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="CosmosDB";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestCosmosDBResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    Thread.sleep(5000);	
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
			    SoftAssert softAssert = new SoftAssert();    
		 String cosmosDBResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		 WebElement cosmosDBResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_RESOURCE_GROUP_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(cosmosDBResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, cosmosDBResourceGroupNameElement);
				 softAssert.assertEquals(cosmosDBResourceGroupNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",cosmosDBResourceGroupName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",cosmosDBResourceGroupName ); 
				  softAssert.assertAll();
				  
				
	 }
	 
@Test (priority=2)
	  public  void TestCosmosDBLocation() throws Exception{
		  SoftAssert softAssert1 = new SoftAssert();
		  String cosmosDBLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_FAILOVER_LOCATION_XPATH)).getText().strip(); 
		  WebElement cosmosDBLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_FAILOVER_LOCATION_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(cosmosDBLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, cosmosDBLocationElement);
				 softAssert1.assertEquals(cosmosDBLocationElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",cosmosDBLocation ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", cosmosDBLocation);
				  reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				  softAssert1.assertAll();
				 
			
	 }

	 @Test (priority=3)
	  public  void TestCosmosDBName() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 String cosmosDBNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_NAME_XPATH)).getText().strip(); 
		 WebElement cosmosDBName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_NAME_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(cosmosDBNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, cosmosDBNameElement);
				 softAssert2.assertEquals(cosmosDBNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",cosmosDBName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",cosmosDBName );
				  reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				  softAssert2.assertAll();
				 
			
	 }
	 
    /* @Test (priority=4)
	  public  void TestCosmosDBOfferType() throws Exception{
	  SoftAssert softAssert3 = new SoftAssert();
		 String CosmosDBOfferTypeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_DATABASE_ACCOUNT_OFFER_TYPE_XPATH)).getText().strip(); 
		 WebElement CosmosDBOfferType = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_DATABASE_ACCOUNT_OFFER_TYPE_XPATH));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(CosmosDBOfferTypeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, CosmosDBOfferTypeElement);
				 softAssert3.assertEquals(CosmosDBOfferTypeElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",CosmosDBOfferType ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",CosmosDBOfferType );
				  reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				  softAssert3.assertAll();
				 
				
	 }
	 
	 @Test (priority=5)
	  public  void TestCosmosDBAccountKind() throws Exception{
	     SoftAssert softAssert4 = new SoftAssert(); 
		 driver.findElement(By.xpath("/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[1]/div/a")).click();
		 Thread.sleep(2000);
		 String CosmosDBAccountKindElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_ACCOUNT_KIND_XPATH)).getText().strip(); 
		 WebElement CosmosDBAccountKind = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_ACCOUNT_KIND_XPATH));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(CosmosDBAccountKindElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, CosmosDBAccountKindElement);
				 softAssert4.assertEquals(CosmosDBAccountKindElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",CosmosDBAccountKind ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",CosmosDBAccountKind );
				  reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				  softAssert4.assertAll();
				 
				
	 } */
	 
	 @Test (priority=6)
	  public  void TestCosmosDBTableName() throws Exception{
		 SoftAssert softAssert5 = new SoftAssert();
		 String CosmosDBTableNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_TABLE_XPATH)).getText().strip(); 
		 WebElement CosmosDBTableName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_TABLE_XPATH));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(CosmosDBTableNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, CosmosDBTableNameElement);
				 softAssert5.assertEquals(CosmosDBTableNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",CosmosDBTableName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",CosmosDBTableName );
				  reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				  softAssert5.assertAll();
				 
				
	 }
	 
	 @Test (priority=7)
	  public  void TestCosmosDBKeySpace() throws Exception{
		 SoftAssert softAssert6 = new SoftAssert();
		 String CosmosDBKeySpaceElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_DATABASE_NAME_XPATH)).getText().strip(); 
		 WebElement CosmosDBKeySpace = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.COSMOSDB_DATABASE_NAME_XPATH));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(CosmosDBKeySpaceElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, CosmosDBKeySpaceElement);
				 softAssert6.assertEquals(CosmosDBKeySpaceElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",CosmosDBKeySpace ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",CosmosDBKeySpace );
				  reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				  softAssert6.assertAll();
				 
				
	 }

}
