package autoOps.frameworkvalidator.azurevalidationservices;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestSynapsePrivateLinkHub extends Setup { 
	
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Synapse(Private Link Hubs)";
	  String status;
	  
	 
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();
	 String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	  
	 @Test (priority=1)
	  public  void TestSynapsePrivateLinkHubResourceGroupName() throws Exception{
		 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
		 Thread.sleep(2000);
	    
	  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
	    Thread.sleep(3000);
	    
	    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
	    Thread.sleep(5000);	
	    
		 SoftAssert softAssert = new SoftAssert();
		  Thread.sleep(2000);
		  String synapsePrivateLinkHubResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_RG_NAME)).getText().strip(); 
		  WebElement synapsePrivateLinkHubResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_RG_NAME));
		  String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(synapsePrivateLinkHubResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, synapsePrivateLinkHubResourceGroupNameElement);
				 softAssert.assertEquals(synapsePrivateLinkHubResourceGroupNameElement.strip(), expectedResult.strip());
				
				 
				// Highlighting element & Taking screenshot
				
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapsePrivateLinkHubResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +  testId + ".png" );
				 Thread.sleep(1000);				 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapsePrivateLinkHubResourceGroupName ); 
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertAll();
				  
		
	}
	 
	 
	 @Test (priority=2)
	  public  void TestSynapsePrivateLinkHubName() throws Exception{
		 SoftAssert softAssert1 = new SoftAssert();
		  Thread.sleep(2000);
		  String synapsePrivateLinkHubNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_NAME)).getText().strip(); 
		  WebElement synapsePrivateLinkHubName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_NAME));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(synapsePrivateLinkHubNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, synapsePrivateLinkHubNameElement);
				 softAssert1.assertEquals(synapsePrivateLinkHubNameElement.strip(), expectedResult.strip());
				
				 
				// Highlighting element & Taking screenshot
				
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapsePrivateLinkHubName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +  testId + ".png" );
				 Thread.sleep(1000);				 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapsePrivateLinkHubName ); 
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert1.assertAll();
				  
		
	}

	@Test (priority=3)
	public  void TestSynapsePrivateLinkHubLocation() throws Exception{
		
		SoftAssert softAssert2 = new SoftAssert();
		String synapsePrivateLinkHubLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_LOCATION)).getText(); 
		WebElement synapsePrivateLinkHubLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_LOCATION));
		String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4);
		 
		String testId = reader.getCellData(sheetname, "TEST ID" , 4);
		 
		 if( synapsePrivateLinkHubLocationElement.equalsIgnoreCase(expectedResult)) {
			 String  status= "pass";
			 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
		
		 }
		 else {
			String status="fail";
			reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
			
		 }
		 
		 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, synapsePrivateLinkHubLocationElement);
		 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
		 softAssert2.assertEquals(synapsePrivateLinkHubLocationElement.strip(), expectedResult.strip());
		    
		  //Highlighting element & Taking screenshot	
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapsePrivateLinkHubLocation ); 
		 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
		 Thread.sleep(1000);
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapsePrivateLinkHubLocation ); 
		 softAssert2.assertAll();
		 
		
		 
	}
	
	
	@Test (priority=4)
	public  void TestSynapsePrivateLinkHubSubcription() throws Exception{
		
		SoftAssert softAssert3 = new SoftAssert();
		String synapsePrivateLinkHubSubcriptionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_SUBSCRITION)).getText(); 
		WebElement synapsePrivateLinkHubSubcription = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_SUBSCRITION));
		String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5);
		 
		String testId = reader.getCellData(sheetname, "TEST ID" , 5);
		 
		 if( synapsePrivateLinkHubSubcriptionElement.equalsIgnoreCase(expectedResult)) {
			 String  status= "pass";
			 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
		
		 }
		 else {
			String status="fail";
			reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
			
		 }
		 
		 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, synapsePrivateLinkHubSubcriptionElement);
		 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
		 softAssert3.assertEquals(synapsePrivateLinkHubSubcriptionElement, expectedResult);
		    
		  //Highlighting element & Taking screenshot	
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapsePrivateLinkHubSubcription ); 
		 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
		 Thread.sleep(1000);
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapsePrivateLinkHubSubcription ); 
		 softAssert3.assertAll();
		 
		
		 
	}

	
	@Test (priority=5)
	public  void TestSynapsePrivateLinkHubPrivateEndpointConnection() throws Exception{
		
		SoftAssert softAssert4 = new SoftAssert();
		driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_PRIVATE_ENDPOINT_CONNECTIONS_TAB_CLICK)).click();
		Thread.sleep(4000);
		String privateEndpointConnectionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_PRIVATE_ENDPOINT_CONNECTIONS_NAME)).getText(); 
		WebElement privateEndpointConnection = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSE_PRIVATE_LINK_HUB_PRIVATE_ENDPOINT_CONNECTIONS_NAME));
		String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6);
		 
		String testId = reader.getCellData(sheetname, "TEST ID" , 6);
		 
		 if( privateEndpointConnectionElement.equalsIgnoreCase(expectedResult)) {
			 String  status= "pass";
			 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
		
		 }
		 else {
			String status="fail";
			reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
			
		 }
		 
		 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, privateEndpointConnectionElement);
		 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
		 softAssert4.assertEquals(privateEndpointConnectionElement, expectedResult);
		    
		  //Highlighting element & Taking screenshot	
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",privateEndpointConnection ); 
		 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
		 Thread.sleep(1000);
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",privateEndpointConnection ); 
		 softAssert4.assertAll();
		 Thread.sleep(2000);
		 
		
		 
	}

}
