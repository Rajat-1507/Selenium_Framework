package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestSqlDB extends Setup {

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="SQL-DB";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestSqlServerResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    Thread.sleep(8000);	
			    //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
		 SoftAssert softAssert = new SoftAssert();	    
		 String sqlServerResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		 WebElement sqlServerResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_RESOURCE_GROUP_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(sqlServerResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, sqlServerResourceGroupNameElement);
				 softAssert.assertEquals(sqlServerResourceGroupNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sqlServerResourceGroupName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sqlServerResourceGroupName ); 
				  softAssert.assertAll();
				  
				
	 }
	 
@Test (priority=2)
	  public  void TestSqlServerLocation() throws Exception{
	      SoftAssert softAssert1 = new SoftAssert();
		  String sqlServerLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_LOCATION_XPATH)).getText().strip(); 
		  WebElement sqlServerLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_LOCATION_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(sqlServerLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, sqlServerLocationElement);
				 softAssert1.assertEquals(sqlServerLocationElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sqlServerLocation ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", sqlServerLocation);
				  reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				  softAssert1.assertAll();
				 
			
	 }

	 @Test (priority=3)
	  public  void TestSqlServerName() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 String sqlServerNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_NAME_XPATH)).getText().strip(); 
		 WebElement sqlServerName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_NAME_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(sqlServerNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, sqlServerNameElement);
				 softAssert2.assertEquals(sqlServerNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sqlServerName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sqlServerName );
				  reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				  softAssert2.assertAll();
				 
			
	 }
	 
	 @Test (priority=4)
		public  void TestSqlDBSubcription() throws Exception{
			
			SoftAssert softAssert3 = new SoftAssert();
			String sqlDBSubcriptionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_SUBSCRIPTION)).getText(); 
			WebElement sqlDBSubcription = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_SUBSCRIPTION));
			String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5);
			 
			String testId = reader.getCellData(sheetname, "TEST ID" , 5);
			 
			 if( sqlDBSubcriptionElement.equalsIgnoreCase(expectedResult)) {
				 String  status= "pass";
				 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
			
			 }
			 else {
				String status="fail";
				reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
			 }
			 
			 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, sqlDBSubcriptionElement);
			 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
			 softAssert3.assertEquals(sqlDBSubcriptionElement, expectedResult);
			    
			  //Highlighting element & Taking screenshot	
			 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
			 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sqlDBSubcription ); 
			 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
			 Thread.sleep(1000);
			 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sqlDBSubcription ); 
			 softAssert3.assertAll();	
			 
		}

	 
	 @Test (priority=5)
	  public  void TestSqlServerLogin() throws Exception{
		 
		 SoftAssert softAssert4 = new SoftAssert();
		 String sqlServerLoginElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_ADMIN_LOGIN_XPATH)).getText().strip(); 
		 WebElement sqlServerLogin = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_ADMIN_LOGIN_XPATH));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(sqlServerLoginElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, sqlServerLoginElement);
				 softAssert4.assertEquals(sqlServerLoginElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sqlServerLogin ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sqlServerLogin );
				  reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				  softAssert4.assertAll();
				 
				
	 }
	 
	 
	 @Test (priority=6)
	  public  void TestSqlServerAuthentionMethod() throws Exception{
		 
		 SoftAssert softAssert5 = new SoftAssert();
			
		 String sqlServerAuthMethodElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_AUTH_METHOD)).getText().strip(); 
		 WebElement sqlServerAuthMethod = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_AUTH_METHOD));

		 // Scrolling to database name
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(sqlServerAuthMethodElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, sqlServerAuthMethodElement);
				 softAssert5.assertEquals(sqlServerAuthMethodElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", sqlServerAuthMethod ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", sqlServerAuthMethod);
				  reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				  softAssert5.assertAll();
				 
		
	 }
	 
	 
	 @Test (priority=7)
	  public  void TestServerSetAzureADAdmin() throws Exception{
		 SoftAssert softAssert6 = new SoftAssert();
			
		 String serverSetAzureADAdminElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_SET_AZURE_AD_ADMIN)).getText().strip(); 
		 WebElement serverSetAzureADAdmin = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_SET_AZURE_AD_ADMIN));
		
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(serverSetAzureADAdminElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, serverSetAzureADAdminElement);
				 softAssert6.assertEquals(serverSetAzureADAdminElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", serverSetAzureADAdmin ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", serverSetAzureADAdmin);
				  
				  softAssert6.assertAll();
				 
		
	 }
	 
	 
	 @Test (priority=8)
	  public  void TestSqlServerDatabaseName() throws Exception{
		 
		 SoftAssert softAssert7 = new SoftAssert();
			
		 String sqlServerDatabaseNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_DATABASE_NAME_XPATH)).getText().strip(); 
		 WebElement sqlServerDatabaseName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_DATABASE_NAME_XPATH));
		 
		// Scrolling down 
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", sqlServerDatabaseName);
	      Thread.sleep(5000);
	      
		  String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(sqlServerDatabaseNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, sqlServerDatabaseNameElement);
				 softAssert7.assertEquals(sqlServerDatabaseNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", sqlServerDatabaseName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", sqlServerDatabaseName);
				 
				  softAssert7.assertAll();
				 
		
	 }
	 
	 
	
	 
	 @Test (priority=9)
	  public  void TestSqlElasticPool() throws Exception{
		 SoftAssert softAssert8 = new SoftAssert();
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_ELASTIC_POOL_CLICK)).click();
		 Thread.sleep(4000);	
		 String sqlElasticPoolElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_ELASTIC_POOL)).getText().strip(); 
		 WebElement sqlElasticPool = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_ELASTIC_POOL));
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 10);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",10).strip();
		
				 if(sqlElasticPoolElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 10, sqlElasticPoolElement);
				 softAssert8.assertEquals(sqlElasticPoolElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 10, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", sqlElasticPool ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", sqlElasticPool);
				 
				  softAssert8.assertAll();
				 
		
	 }
	 
	 
	 @Test (priority=10)
	  public  void TestNetworkConnectivity() throws Exception{
		 SoftAssert softAssert9 = new SoftAssert();
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_NETWORKING_CLICK)).click();
		 Thread.sleep(5000);
		 
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_IFRAME)));
		 
		 String networkConnectivityElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_NETWORK_CONNECTIVITY)).getText().strip(); 
		 WebElement networkConnectivity = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_NETWORK_CONNECTIVITY));
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 11);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",11).strip();
		
				 if(networkConnectivityElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 11, networkConnectivityElement);
				 softAssert9.assertEquals(networkConnectivityElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 11, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", networkConnectivity ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", networkConnectivity);
				  driver.switchTo().defaultContent();
				  softAssert9.assertAll();
				 
		
	 }
	 
	 @Test (priority=11)
	  public  void TestConnectionPolicy() throws Exception{
		 SoftAssert softAssert10 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_IFRAME)));
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_CONNECTION_POLICY_CLICK)).click();
		 Thread.sleep(3000);	
		 String connectionPolicyElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_CONNECTION_POLICY)).getText().strip(); 
		 WebElement connectionPolicy = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_CONNECTION_POLICY));
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 12);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",12).strip();
		
				 if(connectionPolicyElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 12, connectionPolicyElement);
				 softAssert10.assertEquals(connectionPolicyElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 12, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", connectionPolicy ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", connectionPolicy);
				  driver.switchTo().defaultContent();
				  softAssert10.assertAll();
				 
		
	 }
	 
	 
	 @Test (priority=12)
	  public  void TestMicrosoftDefenderForSql() throws Exception{
		 SoftAssert softAssert11 = new SoftAssert();
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_MICROSOFT_DEFENDER_CLOUD_CLICK)).click();
		 Thread.sleep(3000);	
		 //String microsoftDefenderForSqlElement = "";
		 String microsoftDefenderForSqlElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_MICROSOFT_DEFENDER_FOR_SQL)).getText().strip(); 
		 WebElement microsoftDefenderForSql = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_MICROSOFT_DEFENDER_FOR_SQL));
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 13);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",13).strip();
		
				 if(microsoftDefenderForSqlElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 13, microsoftDefenderForSqlElement);
				 softAssert11.assertEquals(microsoftDefenderForSqlElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 13, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", microsoftDefenderForSql ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", microsoftDefenderForSql);
				 
				  softAssert11.assertAll();
				 
		
	 }
	 
	 @Test (priority=13)
	  public  void TestIndentity() throws Exception{
		 SoftAssert softAssert12 = new SoftAssert();
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_INDENTITY_CLICK)).click();
		 Thread.sleep(3000);	
		 String indentityElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_INDENTITY)).getText().strip(); 
		 WebElement identity = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_INDENTITY));
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 14);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",14).strip();
		
				 if(indentityElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 14, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 14, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 14, indentityElement);
				 softAssert12.assertEquals(indentityElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 14, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", identity ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", identity);
				 
				  softAssert12.assertAll();
				 
		
	 }
	 
	 @Test (priority=14)
	  public  void TestTransparentDataEncryption() throws Exception{
		 SoftAssert softAssert13 = new SoftAssert();
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_TRANSPERENT_DATA_ENCRYPTION_CLICK)).click();
		 Thread.sleep(3000);	
		 String transparentDataEncryptionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_TRANSPERENT_DATA_ENCRYPTION)).getText().strip(); 
		 WebElement transparentDataEncryption = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_TRANSPERENT_DATA_ENCRYPTION));
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 15);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",15).strip();
		
				 if(transparentDataEncryptionElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 15, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 15, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 15, transparentDataEncryptionElement);
				 softAssert13.assertEquals(transparentDataEncryptionElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 15, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", transparentDataEncryption ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", transparentDataEncryption);
				 
				  softAssert13.assertAll();
				 
		
	 }
	 
	 
	 @Test (priority=15)
	  public  void TestComputeStorage() throws Exception{
		 
		 SoftAssert softAssert14 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_OVERVIEW)).click();
		 Thread.sleep(4000);
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_DATABASE_NAME_XPATH)).click();
		 Thread.sleep(5000);
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_COMPUTE_STORAGE_CLICK)).click();
		 Thread.sleep(6000);
		 
		 String computeStorageElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_COMPUTE_STORAGE)).getText().strip(); 
		 WebElement computeStorage = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_COMPUTE_STORAGE));
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 16);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",16).strip();
		
				 if(computeStorageElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 16, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 16, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 16, computeStorageElement);
				 softAssert14.assertEquals(computeStorageElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 16, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", computeStorage ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", computeStorage);
				 
				  softAssert14.assertAll();
				 
		
	 }
	 
	 
	 @Test (priority=16)
	  public  void TestBackupStorageRedundancy() throws Exception{
		 
		 SoftAssert softAssert15 = new SoftAssert();
		
		 String backupStorageRedundancyElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_BSR)).getText().strip(); 
		 WebElement backupStorageRedundancy = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_BSR));
		 
		// Scrolling down 
				 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", backupStorageRedundancy);
			      Thread.sleep(5000);
		 
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 17);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",17).strip();
		
				 if(backupStorageRedundancyElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 17, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 17, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 17, backupStorageRedundancyElement);
				 softAssert15.assertEquals(backupStorageRedundancyElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 17, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", backupStorageRedundancy ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", backupStorageRedundancy);
				 
				  softAssert15.assertAll();
				 
		
	 }
	 
	 @Test (priority=17)
	  public  void TestMaintenanceWindow() throws Exception{
		 
		 SoftAssert softAssert16 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_MAIN_WINDOW_CLICK)).click();
		 Thread.sleep(20000);
		
		 String maintenanceWindowElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_MAIN_WINDOW)).getText().strip(); 
		 WebElement maintenanceWindow = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_MAIN_WINDOW));		 
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 18);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",18).strip();
		
				 if(maintenanceWindowElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 18, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 18, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 18, maintenanceWindowElement);
				 softAssert16.assertEquals(maintenanceWindowElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 18, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", maintenanceWindow ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", maintenanceWindow);
				 
				  softAssert16.assertAll();
				  Thread.sleep(2000);
				 
		
	 }
	 
	 
	 @Test (priority=18)
	  public  void TestCollation() throws Exception{
		 
		 SoftAssert softAssert17 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_PROPERTIES_CLICK)).click();
		 Thread.sleep(20000);
		
		 String collationElement = "SQL_Latin1_General_CP1_CI_AS"; 
		 WebElement collation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SQLSERVER_COLLATION));		 
		 
		  String testId = reader.getCellData(sheetname, "TEST ID", 19);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",19).strip();
		
				 if(collationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 19, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 19, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 19, collationElement);
				 softAssert17.assertEquals(collationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 19, testId + ".png");
				 Thread.sleep(2000);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')", collation ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')", collation);
				 
				  softAssert17.assertAll();
				  Thread.sleep(2000);
				 
		
	 }
}
