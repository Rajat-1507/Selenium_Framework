package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestAppServicePlan extends Setup {
	
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="AppServicePlan";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	  //click function
	  public  void clickfunction(String Xpath) throws Exception {
		
			  driver.findElement(By.xpath(Xpath)).click();
			  Thread.sleep(5000);
	  }
	 
	 @Test (priority=1)
	  public  void TestAppServicePlanResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    clickfunction(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK);
			    Thread.sleep(3000);	
			  
			    
		 SoftAssert softAssert = new SoftAssert();	
		 
		 String appServicePlanResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_RESOURCEGROUPNAME)).getText().strip(); 
		 WebElement appServicePlanResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_RESOURCEGROUPNAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(appServicePlanResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, appServicePlanResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(appServicePlanResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",appServicePlanResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",appServicePlanResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestAppServicePlanLocation() throws Exception{
		
		  SoftAssert softAssert1 = new SoftAssert();
		  String appServicePlanLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_LOCATION)).getText().strip(); 
		  WebElement appServicePlanLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_LOCATION));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(appServicePlanLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, appServicePlanLocationElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(appServicePlanLocationElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",appServicePlanLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",appServicePlanLocation ); 
				 softAssert1.assertAll();
				 				  
	 }

	 @Test (priority=3)
	  public  void TestAppServicePlanName() throws Exception{
		 
		 SoftAssert softAssert2 = new SoftAssert();
		 String appServicePlanNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_NAME)).getText().strip(); 
		 WebElement appServicePlanName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_NAME));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(appServicePlanNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, appServicePlanNameElement);
				 softAssert2.assertEquals(appServicePlanNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",appServicePlanName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",appServicePlanName ); 
				 softAssert2.assertAll();
				 
	 }

	 
	 @Test (priority=4)
	  public  void TestAppServicePlanOS() throws Exception{
		 
		 SoftAssert softAssert3 = new SoftAssert();
		 String appServicePlanOSElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_OS)).getText().strip(); 
		 WebElement appServicePlanOS = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_OS));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(appServicePlanOSElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, appServicePlanOSElement);
				 softAssert3.assertEquals(appServicePlanOSElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",appServicePlanOS ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",appServicePlanOS ); 
				 softAssert3.assertAll();
		 
	 }
	 
	 @Test (priority=5)
	  public  void TestAppServicePlanSize() throws Exception{
		 
		 SoftAssert softAssert4 = new SoftAssert();
		 String appServicePlanSizeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_SIZE)).getText().strip(); 
		 WebElement appServicePlanSize = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_SIZE));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(appServicePlanSizeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, appServicePlanSizeElement);
				 softAssert4.assertEquals(appServicePlanSizeElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",appServicePlanSize ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",appServicePlanSize ); 
				 softAssert4.assertAll();		 
			
	 }  
	 
	 @Test (priority=6)
	  public  void TestAppServicePlanTag() throws Exception{
		 
		 SoftAssert softAssert6 = new SoftAssert();
	      
		  String appServicePlanTagElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_TAG)).getText().strip(); 
		  WebElement appServicePlanTag = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_TAG));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		  
		  String lines[] = appServicePlanTagElement.split("\\r?\\n");
			System.out.println(lines[0]);
			System.out.println(lines[1]);
			System.out.println(lines[2]);
			String AppServicePlanTagElement1="";
			for (String Tag : lines)
			{    
				AppServicePlanTagElement1= AppServicePlanTagElement1 + Tag + " ";  
					
			       }
		
				 if(AppServicePlanTagElement1.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, AppServicePlanTagElement1);
				 softAssert6.assertEquals(AppServicePlanTagElement1.strip(), expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",appServicePlanTag ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",appServicePlanTag ); 
				 softAssert6.assertAll(); 			
		 
		 	 
				
	 }	 
	 
	 @Test (priority=7)
	  public  void TestAppServicePlanAppName() throws Exception{
		 
		 SoftAssert softAssert5 = new SoftAssert();
		 
	      driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_APP_CLICK)).click();
	      Thread.sleep(3000);
		  String appServicePlanAppNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_APP_NAME)).getText().strip(); 
		  WebElement appServicePlanAppName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APP_SERVICE_PLAN_APP_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(appServicePlanAppNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, appServicePlanAppNameElement);
				 softAssert5.assertEquals(appServicePlanAppNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",appServicePlanAppName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",appServicePlanAppName ); 
				 softAssert5.assertAll(); 		  
				
	 }	 

}
