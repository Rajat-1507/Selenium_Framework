package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestSynapseAnalytics extends Setup{
	
	  Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Synapse";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestSynapseAnalyticsResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();	
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
			    Thread.sleep(2000);
			    
		 SoftAssert softAssert = new SoftAssert();	    
		 String synapseAnalyticsResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		 WebElement synapseAnalyticsResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_RESOURCE_GROUP_NAME_XPATH));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(synapseAnalyticsResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, synapseAnalyticsResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(synapseAnalyticsResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapseAnalyticsResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapseAnalyticsResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestSynapseAnalyticsName() throws Exception{
	
	      SoftAssert softAssert1 = new SoftAssert();
		  String synapseAnalyticsNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_WORKSPACE_NAME_XPATH)).getText().strip(); 
		 
		  WebElement synapseAnalyticsName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_WORKSPACE_NAME_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		  
		  
		  
				 if(synapseAnalyticsNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, synapseAnalyticsNameElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(synapseAnalyticsNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapseAnalyticsName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapseAnalyticsName ); 
				 softAssert1.assertAll();
				 
				  
	 } 

	 @Test (priority=3)
	  public  void TestSynapseAnalyticsLocation() throws Exception{
		 
		 SoftAssert softAssert2 = new SoftAssert();
		 
		 String synapseAnalyticsLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_LOCATION_XPATH)).getText().strip(); 
		 WebElement synapseAnalyticsLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_LOCATION_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(synapseAnalyticsLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, synapseAnalyticsLocationElement);
				 softAssert2.assertEquals(synapseAnalyticsLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapseAnalyticsLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapseAnalyticsLocation ); 
				 softAssert2.assertAll();
				 
	 } 

	 
	 @Test (priority=4)
	  public  void TestSynapseAnalyticsSQLAdminUserName() throws Exception{
		 
		 SoftAssert softAssert3 = new SoftAssert();
		 String SynapseAnalyticsSQLAdminUserNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_ADMIN_USERNAME_XPATH)).getText().strip(); 
		 WebElement SynapseAnalyticsSQLAdminUserName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_ADMIN_USERNAME_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(SynapseAnalyticsSQLAdminUserNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, SynapseAnalyticsSQLAdminUserNameElement);
				 softAssert3.assertEquals(SynapseAnalyticsSQLAdminUserNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsSQLAdminUserName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsSQLAdminUserName ); 
				 softAssert3.assertAll();
		 
	 }
	 
	 @Test (priority=5)
	  public  void TestSynapseAnalyticsSQLPool() throws Exception{
		 SoftAssert softAssert4 = new SoftAssert();
		 
		 Actions at = new Actions(driver);
	      at.sendKeys(Keys.PAGE_DOWN).build().perform();
	      Thread.sleep(3000);
	      
		 String SynapseAnalyticsSQLPoolElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_SQL_POOL_NAME_XPATH)).getText().strip(); 
		 WebElement SynapseAnalyticsSQLPool = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_SQL_POOL_NAME_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(SynapseAnalyticsSQLPoolElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, SynapseAnalyticsSQLPoolElement);
				 softAssert4.assertEquals(SynapseAnalyticsSQLPoolElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsSQLPool ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsSQLPool ); 
				 softAssert4.assertAll();
				 
			
	 }
	 
	 @Test (priority=6)
	  public  void TestSynapseAnalyticsSQLPoolSkuName() throws Exception{
		 
		 SoftAssert softAssert5 = new SoftAssert();
		 
		 String SynapseAnalyticsSQLPoolSkuNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_SQL_POOL_SKU_NAME)).getText().strip(); 
		 WebElement SynapseAnalyticsSQLPoolSkuName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_SQL_POOL_SKU_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(SynapseAnalyticsSQLPoolSkuNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
								
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, SynapseAnalyticsSQLPoolSkuNameElement);
				 softAssert5.assertEquals(SynapseAnalyticsSQLPoolSkuNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsSQLPoolSkuName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsSQLPoolSkuName ); 
				 softAssert5.assertAll(); 				
	 }
	 
	 @Test (priority=8)
	  public  void TestSynapseAnalyticsFirewallRuleName() throws Exception{	 
		 
		 SoftAssert softAssert7 = new SoftAssert();
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_SHOW_FIREWALL_SETTING_XPATH)).click();
		 Thread.sleep(3000);
		 
		 Actions at = new Actions(driver);
	     at.sendKeys(Keys.PAGE_DOWN).build().perform();	   
		 Thread.sleep(3000);
		 
		 String SynapseAnalyticsFirewallRuleNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_FIREWALL_RULE_NAME_XPATH)).getText().strip(); 
		 WebElement SynapseAnalyticsFirewallRuleName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_FIREWALL_RULE_NAME_XPATH));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(SynapseAnalyticsFirewallRuleNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				 
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, SynapseAnalyticsFirewallRuleNameElement);
				 softAssert7.assertEquals(SynapseAnalyticsFirewallRuleNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsFirewallRuleName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsFirewallRuleName ); 
				 softAssert7.assertAll(); 
				 
		
		 
	 }
	 
	 @Test (priority=9)
	  public  void TestSynapseAnalyticsStartIpAddress() throws Exception{
		 
		 SoftAssert softAssert8 = new SoftAssert();
		 
		 String SynapseAnalyticsStartIpAddressElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_START_IP_ADDRESS)).getText().strip(); 
		 WebElement SynapseAnalyticsStartIpAddress = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_START_IP_ADDRESS))	;
		  String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(SynapseAnalyticsStartIpAddressElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, SynapseAnalyticsStartIpAddressElement);
				 softAssert8.assertEquals(SynapseAnalyticsStartIpAddressElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsStartIpAddress ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsStartIpAddress ); 
				 softAssert8.assertAll();
				 
			
		 
	 } 
	 @Test (priority=10)
	  public  void TestSynapseAnalyticsStopIpAddress() throws Exception{
		 SoftAssert softAssert9 = new SoftAssert();
	  	
		 String SynapseAnalyticsStopIpAddressElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_STOP_IP_ADDRESS)).getText(); 
		 WebElement SynapseAnalyticsStopIpAddress = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_STOP_IP_ADDRESS));
		  String testId = reader.getCellData(sheetname, "TEST ID", 10);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",10).strip();
		
				 if(SynapseAnalyticsStopIpAddressElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 10, SynapseAnalyticsStopIpAddressElement);
				 softAssert9.assertEquals(SynapseAnalyticsStopIpAddressElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 10, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsStopIpAddress ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsStopIpAddress ); 
				 softAssert9.assertAll();
				 
			
		 
	 } 
	 @Test (priority=7)
	  public  void TestSynapseAnalyticsADLSGen2fileSystem() throws Exception{
		 
		 SoftAssert softAssert6 = new SoftAssert();
		 
		 String SynapseAnalyticsADLSGen2fileSystemElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_FILE_SYSTEM_NAME_XPATH)).getText().strip(); 
		 WebElement SynapseAnalyticsADLSGen2fileSystem = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SYNAPSEANALYTICS_FILE_SYSTEM_NAME_XPATH));
			
		  String testId = reader.getCellData(sheetname, "TEST ID", 11);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT", 11).strip();
		
				 if(SynapseAnalyticsADLSGen2fileSystemElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 11, SynapseAnalyticsADLSGen2fileSystemElement);
				 softAssert6.assertEquals(SynapseAnalyticsADLSGen2fileSystemElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 11, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsADLSGen2fileSystem ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsADLSGen2fileSystem ); 
				 softAssert6.assertAll();
				 
				
		 
	 } 
	 
	 @Test (priority=11)
	  public  void TestSynapseAnalyticsMetricAlertName() throws Exception{
		 
		 SoftAssert softAssert10 = new SoftAssert();	 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ALERT_SIDEBAR_CLICK)).click();
		   Thread.sleep(4000);
		   driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_MANAGE_ALERT_RULES_CLICK_XPATH)).click();
		   Thread.sleep(4000);
			
			
  	     
		 String synapseAnalyticsMetricAlertNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_NAME_XPATH)).getText().strip(); 
		 WebElement synapseAnalyticsMetricAlertName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 12);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",12).strip();
		
				 if(synapseAnalyticsMetricAlertNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 12, synapseAnalyticsMetricAlertNameElement);
				 softAssert10.assertEquals(synapseAnalyticsMetricAlertNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 12, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapseAnalyticsMetricAlertName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapseAnalyticsMetricAlertName ); 
				  softAssert10.assertAll();		  
				
	 }
	 
	 @Test (priority=12)
	  public  void TestSynapseAnalyticsMetricAlertDescription() throws Exception{
		 
		 SoftAssert softAssert11 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_NAME_XPATH)).click();
		 Thread.sleep(3000);
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_ALERT_IFRAME)));
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_PROPERTIES_XPATH)).click();
		 Thread.sleep(5000);
		 driver.switchTo().defaultContent();
			    
		 String SynapseAnalyticsMetricAlertDescriptionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_DESCRIPTION_XPATH)).getText().strip(); 
		 WebElement SynapseAnalyticsMetricAlertDescription = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_METRIC_ALERT_DESCRIPTION_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 13);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",13).strip();
		 
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",SynapseAnalyticsMetricAlertDescription);
		 Thread.sleep(3000);
		
				 if(SynapseAnalyticsMetricAlertDescriptionElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 13, SynapseAnalyticsMetricAlertDescriptionElement);
				 softAssert11.assertEquals(SynapseAnalyticsMetricAlertDescriptionElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 13, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsMetricAlertDescription ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsMetricAlertDescription ); 
				  softAssert11.assertAll();		  
				
	 }
	 
	 @Test (priority=13)
	  public  void TestSynapseAnalyticsFrequency() throws Exception{
		 
		 SoftAssert softAssert12 = new SoftAssert();
				 
		 String synapseAnalyticsAggregationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_FREQUENCY_XPATH)).getText().strip(); 
		 WebElement SynapseAnalyticsAggregation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_FREQUENCY_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 14);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",14).strip();
		
				 if(synapseAnalyticsAggregationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 14, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 14, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 14, synapseAnalyticsAggregationElement);
				 softAssert12.assertEquals(synapseAnalyticsAggregationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 14, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsAggregation ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsAggregation ); 
				  softAssert12.assertAll();		  
				
	 }
	 
	 @Test (priority=14)
	  public  void TestSynapseAnalyticsWindowSize() throws Exception{
		 
		 SoftAssert softAssert13 = new SoftAssert();   
		 
		 String SynapseAnalyticsOperatorElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_WINDOW_SIZE_XPATH)).getText().strip(); 
		 WebElement SynapseAnalyticsOperator = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGEACCOUNT_WINDOW_SIZE_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 15);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",15).strip();
		
				 if(SynapseAnalyticsOperatorElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 15, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 15, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 15, SynapseAnalyticsOperatorElement);
				 softAssert13.assertEquals(SynapseAnalyticsOperatorElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 15, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SynapseAnalyticsOperator ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SynapseAnalyticsOperator ); 
				  softAssert13.assertAll();		  
				
	 }
	 
/*	 @Test (priority=15)
	  public  void TestSynapseAnalyticsThreshold() throws Exception{
		 
		 SoftAssert softAssert14 = new SoftAssert();	    
		 
		 String synapseAnalyticsThresholdElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_THRESHOLD_XPATH)).getText().strip(); 
		 WebElement synapseAnalyticsThreshold = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_THRESHOLD_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 16);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",16).strip();
		
				 if(synapseAnalyticsThresholdElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 16, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 16, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 16, synapseAnalyticsThresholdElement);
				 softAssert14.assertEquals(synapseAnalyticsThresholdElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 16, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",synapseAnalyticsThreshold ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",synapseAnalyticsThreshold ); 
				  softAssert14.assertAll();		  
				
	 } 
	 
	 
 
	 @Test (priority=16)
	  public  void TestADFScheduleTrigger() throws Exception{
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(7000));
			
		 SoftAssert softAssert9= new SoftAssert();
		 driver.findElement(By.xpath(FrameworkValidator_Constants.Constants.ADF_BREADCRUM_CLICK)).click();
	        Thread.sleep(1000);
	        driver.findElement(By.xpath(FrameworkValidator_Constants.Constants.ADF_BREADCRUM_CLICK)).click();
	        Thread.sleep(3000);
		// click on lunch Workspace   
	        driver.findElement(By.xpath(FrameworkValidator_Constants.Constants.ADF_LUNCH_STUDIO)).click();
	        Thread.sleep(20000);
	        
	        Set<String> windowhandles = driver.getWindowHandles();
	        Iterator<String> iterator =windowhandles.iterator();
	        String parentwindow = iterator.next();
	        String childwindow = iterator.next();
	        
	        driver.switchTo().window(childwindow);
	        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(FrameworkValidator_Constants.Constants.ADF_MANAGE_CLICK))).click();
	        
	        Thread.sleep(2000);
	        driver.findElement(By.xpath(FrameworkValidator_Constants.Constants.ADF_TRIGGER_CLICK)).click();
	        Thread.sleep(2000);
	       
	        
			    
		 String ADFScheduleTriggerElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_SCHEDULE_TRIGGER_NAME)).getText().strip(); 
		 WebElement ADFScheduleTrigger = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ADF_SCHEDULE_TRIGGER_NAME));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 17);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",17).strip();
		
				 if(ADFScheduleTriggerElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 17, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 17, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 17, ADFScheduleTriggerElement);
				 softAssert9.assertEquals(ADFScheduleTriggerElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 17, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",ADFScheduleTrigger ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath + testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",ADFScheduleTrigger ); 
				  driver.close();
				  driver.switchTo().window(parentwindow);
				  softAssert9.assertAll();		  
				
	 }  */
	
	 

}
