package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestDataLakeGen2 extends Setup {
	
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="ADLS";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestDataLakeGen2ResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 System.out.println(test_result);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    Thread.sleep(4000);	
			   // driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
		 SoftAssert softAssert = new SoftAssert();	    
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	    
		 String dataLakeGen2ResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2ResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_RESOURCE_GROUP_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(dataLakeGen2ResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, dataLakeGen2ResourceGroupNameElement);
				 softAssert.assertEquals(dataLakeGen2ResourceGroupNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2ResourceGroupName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2ResourceGroupName ); 
				  driver.switchTo().defaultContent();
				  softAssert.assertAll();
				  
				
	 }
	 
	 @Test (priority=2)
	  public  void TestDataLakeGen2Location() throws Exception{
		 SoftAssert softAssert1 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	
			    
		 String dataLakeGen2LocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_LOCATION_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2Location = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_LOCATION_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(dataLakeGen2LocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, dataLakeGen2LocationElement);
				 softAssert1.assertEquals(dataLakeGen2LocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2Location ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2Location ); 
				  driver.switchTo().defaultContent();
				  softAssert1.assertAll();		  
				
	 }
	 
	 @Test (priority=6)
	  public  void TestDataLakeGen2Name() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();	    
		 String dataLakeGen2NameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ACCOUNT_NAME_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2Name = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ACCOUNT_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(dataLakeGen2NameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, dataLakeGen2NameElement);
				 softAssert2.assertEquals(dataLakeGen2NameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2Name ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2Name ); 
				  softAssert2.assertAll();		  
				
	 }
	 
	 @Test (priority=3)
	  public  void TestDataLakeGen2AccountTier() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	
			    
		 String dataLakeGen2AccountTierElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_PERFORMANCE_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2AccountTier = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_PERFORMANCE_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(dataLakeGen2AccountTierElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, dataLakeGen2AccountTierElement);
				 softAssert2.assertEquals(dataLakeGen2AccountTierElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2AccountTier ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2AccountTier ); 
				  driver.switchTo().defaultContent();
				  softAssert2.assertAll();		  
				
	 }
	 
	 @Test (priority=4)
	  public  void TestDataLakeGen2AccountReplication() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	
			    
		 String dataLakeGen2AccountReplicationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_REDUNDANCY_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2AccountReplication = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_REDUNDANCY_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(dataLakeGen2AccountReplicationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, dataLakeGen2AccountReplicationElement);
				 softAssert3.assertEquals(dataLakeGen2AccountReplicationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2AccountReplication ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2AccountReplication ); 
				  driver.switchTo().defaultContent();
				  softAssert3.assertAll();		  
				
	 }
	 
	 @Test (priority=5)
	  public  void TestDataLakeGen2AccountKind() throws Exception{
		 SoftAssert softAssert4 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	
			    
		 String dataLakeGen2AccountKindElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ACCOUNT_KIND_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2AccountKind = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ACCOUNT_KIND_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(dataLakeGen2AccountKindElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, dataLakeGen2AccountKindElement);
				 softAssert4.assertEquals(dataLakeGen2AccountKindElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2AccountKind ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2AccountKind ); 
				  driver.switchTo().defaultContent();
				  softAssert4.assertAll();		  
				
	 }
	 
	 @Test (priority=7)
	  public  void TestDataLakeGen2HnsEnabled() throws Exception{
		 SoftAssert softAssert6 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String dataLakeGen2HnsEnabledElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ENABLE_HEIRARCHICAL_NAMESPACE_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2HnsEnabled = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ENABLE_HEIRARCHICAL_NAMESPACE_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(dataLakeGen2HnsEnabledElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, dataLakeGen2HnsEnabledElement);
				 softAssert6.assertEquals(dataLakeGen2HnsEnabledElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2HnsEnabled ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2HnsEnabled ); 
				  driver.switchTo().defaultContent();
				  softAssert6.assertAll();		  
				
	 }
	 
	 @Test (priority=8)
	  public  void TestDataLakeGen2FileSystem() throws Exception{
		 SoftAssert softAssert7 = new SoftAssert();
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_CONTAINER_CLICK_XPATH)).click();
		 Thread.sleep(5000);
		 String dataLakeGen2FileSystemElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_FILESYSTEM_NAME_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2FileSystem = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_FILESYSTEM_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(dataLakeGen2FileSystemElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, dataLakeGen2FileSystemElement);
				 softAssert7.assertEquals(dataLakeGen2FileSystemElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2FileSystem ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2FileSystem ); 
				  softAssert7.assertAll();		  
				
	 } 
	 
	 @Test (priority=9)
	  public  void TestDataLakeGen2MetricAlertName() throws Exception{
		 
	SoftAssert softAssert8 = new SoftAssert();
	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.ALERT_SIDEBAR_CLICK)).click();
	Thread.sleep(5000);
	      
		 String dataLakeGen2MetricAlertNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_METRIC_ALERT_NAME_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2MetricAlertName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_METRIC_ALERT_NAME_XPATH));	
		
		 String testId = reader.getCellData(sheetname, "TEST ID", 11);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",11).strip();
		
				 if(dataLakeGen2MetricAlertNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 11, dataLakeGen2MetricAlertNameElement);
				 softAssert8.assertEquals(dataLakeGen2MetricAlertNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 11, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2MetricAlertName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2MetricAlertName ); 
				  softAssert8.assertAll();		  
				
	 }
	 
	 @Test (priority=10)
	  public  void TestDataLakeGen2MetricAlertDescription() throws Exception{
		 SoftAssert softAssert9 = new SoftAssert();
		 
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
		 Thread.sleep(3000);
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_METRIC_ALERT_NAME_XPATH)).click();
		 Thread.sleep(3000);
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		 String dataLakeGen2LocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_METRIC_ALERT_DESCRIPTION_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2Location = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_METRIC_ALERT_DESCRIPTION_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 12);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",12).strip();
		 
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",dataLakeGen2Location);
		 Thread.sleep(3000);
		
				 if(dataLakeGen2LocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 12, dataLakeGen2LocationElement);
				 softAssert9.assertEquals(dataLakeGen2LocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 12, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2Location ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2Location ); 
				  softAssert9.assertAll();		  
				
	 }
	 
	 @Test (priority=11)
	  public  void TestDataLakeGen2Aggregation() throws Exception{
		 SoftAssert softAssert10 = new SoftAssert();
	 
		 
		 String dataLakeGen2AggregationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_AGGREGATION_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2Aggregation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_AGGREGATION_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 13);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",13).strip();
		
				 if(dataLakeGen2AggregationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 13, dataLakeGen2AggregationElement);
				 softAssert10.assertEquals(dataLakeGen2AggregationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 13, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2Aggregation ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2Aggregation ); 
				  softAssert10.assertAll();		  
				
	 }
	 
	 @Test (priority=12)
	  public  void TestDataLakeGen2Operator() throws Exception{
		 SoftAssert softAssert11 = new SoftAssert();    
		 String dataLakeGen2OperatorElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_OPERATOR_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2Operator = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_OPERATOR_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 14);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",14).strip();
		
				 if(dataLakeGen2OperatorElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 14, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 14, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 14, dataLakeGen2OperatorElement);
				 softAssert11.assertEquals(dataLakeGen2OperatorElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 14, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2Operator ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2Operator ); 
				  softAssert11.assertAll();		  
				
	 }
	 
	 @Test (priority=13)
	  public  void TestDataLakeGen2Threshold() throws Exception{
		 SoftAssert softAssert12 = new SoftAssert();
			    
		 String dataLakeGen2ThresholdElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_THRESHOLD_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2Threshold = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_THRESHOLD_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 15);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",15).strip();
		
				 if(dataLakeGen2ThresholdElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 15, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 15, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 15, dataLakeGen2ThresholdElement);
				 softAssert12.assertEquals(dataLakeGen2ThresholdElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 15, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2Threshold ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2Threshold );
				  Thread.sleep(2000);
				  softAssert12.assertAll();		  
				
	 } 		

}
