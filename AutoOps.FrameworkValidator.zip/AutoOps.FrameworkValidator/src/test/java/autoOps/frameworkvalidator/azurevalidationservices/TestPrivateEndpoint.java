package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestPrivateEndpoint extends Setup {

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="PrivateEndpoint";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestPrivateEndpointResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			   // Thread.sleep(5000);	
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
			    SoftAssert softAssert = new SoftAssert();	    
		 String PrivateEndpointResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PRIVATE_ENDPOINT_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement PrivateEndpointResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PRIVATE_ENDPOINT_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(PrivateEndpointResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, PrivateEndpointResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(PrivateEndpointResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",PrivateEndpointResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",PrivateEndpointResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestPrivateEndpointName() throws Exception{
	      SoftAssert softAssert1 = new SoftAssert();
		  String privateEndpointNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PRIVATE_ENDPOINT_NAME)).getText().strip(); 
		  WebElement privateEndpointName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PRIVATE_ENDPOINT_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(privateEndpointNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, privateEndpointNameElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert1.assertEquals(privateEndpointNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",privateEndpointName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",privateEndpointName ); 
				 softAssert1.assertAll();
				 
				  
	 }

	 @Test (priority=3)
	  public  void TestPrivateEndpointLocation() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 String PrivateEndpointLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PRIVATE_ENDPOINT_LOCATION)).getText().strip(); 
		 WebElement PrivateEndpointLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PRIVATE_ENDPOINT_LOCATION));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(PrivateEndpointLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, PrivateEndpointLocationElement);
				 softAssert2.assertEquals(PrivateEndpointLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",PrivateEndpointLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",PrivateEndpointLocation ); 
				 softAssert2.assertAll();
				 
	 }
	 
	 @Test (priority=4)
	  public  void TestPublicIpSku() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		 String publicIpSkuElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_SKU)).getText().strip(); 
		 WebElement publicIpSku = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_SKU));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(publicIpSkuElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, publicIpSkuElement);
				 softAssert3.assertEquals(publicIpSkuElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicIpSku ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicIpSku ); 
				 softAssert3.assertAll();			 

	 }  
/*	 
	 @Test (priority=4)
	  public  void TestPrivateEndpoint() throws Exception{
		 
		 String PrivateEndpointElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_VM_NAME)).getText().strip(); 
		 WebElement PrivateEndpoint = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_VM_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(publicIpVmNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, publicIpVmNameElement);
				 softAssert.assertEquals(publicIpVmNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicIpVmName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicIpVmName ); 
				 softAssert.assertAll();			 

	 }  

	 
	 @Test (priority=6)
	  public  void TestPrivateEndpoint() throws Exception{
		 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_CONFIGURATION_CLICK)).click();
		 Thread.sleep(3000);
		 
		 String PrivateEndpointElement = "Dynamic";
		 WebElement PrivateEndpoint = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_ALLOCATION_METHOD));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(publicIpAllocationMethodElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, publicIpAllocationMethodElement);
				 softAssert.assertEquals(publicIpAllocationMethodElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicIpAllocationMethod ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicIpAllocationMethod ); 
				 softAssert.assertAll();
		 
	 }  */
	 
	
}
