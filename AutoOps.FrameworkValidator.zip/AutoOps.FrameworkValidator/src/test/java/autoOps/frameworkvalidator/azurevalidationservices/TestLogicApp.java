package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestLogicApp extends Setup{
    // Initialize sheetname, status, reader.
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Logic-App";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	  //click function
	  public  void clickfunction(String Xpath) throws Exception {
		
			  driver.findElement(By.xpath(Xpath)).click();
			  Thread.sleep(4000);
	  }
	 
	 @Test (priority=1)
	  public  void TestLogicAppResourceGroupName() throws Exception{
	             // Reading data from Excel.
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(1000);
			    // Writing data in search box using sendkeys.
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(5000);
			    
			   // Click on search Result.
			    clickfunction(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK);
			    Thread.sleep(8000);
			    
			    clickfunction(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_CLICK);
			   
			    SoftAssert softAssert = new SoftAssert(); 
		 // Reading actual data on Azure portal using gettext method.	    		 
		 String logicAppResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement logicAppResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_RESOURCE_GROUP_NAME));
		 // Reading Test id from Excel Test Id column.
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	 
		// Reading Expected data from Excel EXPECTED RESULT  column.
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
		 		// Condition to check expected data & actual data.
				 if(logicAppResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				 // Writing the actual result in Excel ACTUAL RESULT column.
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, logicAppResourceGroupNameElement);
				 // Writing the screenshot file name in Excel Evidence Column.
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(logicAppResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logicAppResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logicAppResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
	 @Test (priority=2)
	  public  void TestLogicAppLocation() throws Exception{
	
		 SoftAssert softAssert1 = new SoftAssert();		 
			    
		 String logicAppLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_LOCATION)).getText().strip(); 
		 WebElement logicAppLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_LOCATION));
		 String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(logicAppLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, logicAppLocationElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(logicAppLocationElement, expectedResult);
				 
				 
				
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logicAppLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logicAppLocation ); 
				 softAssert1.assertAll();
				 
	 }
	 
	 @Test (priority=3)
	  public  void TestLogicAppName() throws Exception{
	
		 SoftAssert softAssert2 = new SoftAssert();	 
			    
		 String logicAppNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_NAME)).getText().strip(); 
		 WebElement logicAppName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(logicAppNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, logicAppNameElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert2.assertEquals(logicAppNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logicAppName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logicAppName ); 
				 softAssert2.assertAll();
				 
	 }
	  
	 @Test (priority=4)
	  public  void TestLogicAppServiceName_Sku_Size() throws Exception{
	
		 SoftAssert softAssert3 = new SoftAssert();	 
			    
		 String logicAppServiceNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_SERVICE_NAME_SKU_SIZE)).getText().strip(); 
		 WebElement logicAppServiceName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_SERVICE_NAME_SKU_SIZE));
		 String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(logicAppServiceNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, logicAppServiceNameElement);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 softAssert3.assertEquals(logicAppServiceNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logicAppServiceName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logicAppServiceName ); 
				 softAssert3.assertAll();
				 
	 }
	 
	 
	 @Test (priority=5)
	  public  void TestLogicAppWindowsPlan() throws Exception{
	
		 SoftAssert softAssert4 = new SoftAssert();	 
			    
		 String logicAppWindowsPlanElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_WINDOWS_PLAN)).getText().strip(); 
		 WebElement logicAppWindowsPlan = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_WINDOWS_PLAN));
		 String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(logicAppWindowsPlanElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, logicAppWindowsPlanElement);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 softAssert4.assertEquals(logicAppWindowsPlanElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logicAppWindowsPlan ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logicAppWindowsPlan ); 
				 softAssert4.assertAll();
				 
	 }
	 
	 
	 @Test (priority=6)
	  public  void TestLogicApp_Publish_PricingTier() throws Exception{
	
		 SoftAssert softAssert6 = new SoftAssert();	 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_PROPERTIES_CLICK)).click();
	  	 Thread.sleep(4000);    
		 String logicAppPublishPricingTierElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_PUBLISH_PRICINGTIER)).getText().strip(); 
		 WebElement logicAppPublishPricingTier = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_PUBLISH_PRICINGTIER));
		 String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(logicAppPublishPricingTierElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, logicAppPublishPricingTierElement);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 softAssert6.assertEquals(logicAppPublishPricingTierElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logicAppPublishPricingTier ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logicAppPublishPricingTier ); 
				 softAssert6.assertAll();
				 
	 }
	 
	 
	 @Test (priority=7)
	  public  void TestLogicAppAppInsight() throws Exception{
	
		 SoftAssert softAssert7 = new SoftAssert();	 
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.KEYVAULT_APPINSIGHT_CLICK)).click();
	  	 Thread.sleep(4000);  	    
		 String logicAppAppInsightElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_APP_INSIGHTS)).getText().strip(); 
		 WebElement logicAppAppInsight = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.LOGIC_APP_APP_INSIGHTS));
		 String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(logicAppAppInsightElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, logicAppAppInsightElement);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 softAssert7.assertEquals(logicAppAppInsightElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",logicAppAppInsight ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",logicAppAppInsight ); 
				 softAssert7.assertAll();
				 Thread.sleep(2000);
				 
	 }
	 
	 
	 
}
