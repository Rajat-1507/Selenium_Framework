package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestFunctionApp extends Setup {
	
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Function-App";
	  String status;
	 
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	  
	  //click function
	  public  void clickfunction(String Xpath) throws Exception {
		
			  driver.findElement(By.xpath(Xpath)).click();
			  Thread.sleep(5000);
	  }
	 
	 @Test (priority=1)
	  public  void TestFunctionAppResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(1000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(5000);
			    
			    clickfunction(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK);
			    Thread.sleep(3000);
			    
			    
			 
			    SoftAssert softAssert = new SoftAssert();
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
		 String functionAppResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.FUNCTION_APP_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement functionAppResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.FUNCTION_APP_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(functionAppResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, functionAppResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(functionAppResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",functionAppResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",functionAppResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
	 @Test (priority=2)
	  public  void TestFunctionAppLocation() throws Exception{	 
		 SoftAssert softAssert1 = new SoftAssert();	    
		 String functionAppLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.FUNCTION_APP_LOCATION)).getText().strip(); 
		 WebElement functionAppLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.FUNCTION_APP_LOCATION));
		 String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(functionAppLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, functionAppLocationElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(functionAppLocationElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",functionAppLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",functionAppLocation ); 
				 softAssert1.assertAll();
				 
	 }
	 
	 @Test (priority=3)
	  public  void TestFunctionAppName() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();				 
			    
		 String functionAppNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.FUNCTION_APP_NAME)).getText().strip(); 
		 WebElement functionAppName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.FUNCTION_APP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(functionAppNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, functionAppNameElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert2.assertEquals(functionAppNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",functionAppName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",functionAppName ); 
				 softAssert2.assertAll();
				 
	 }
	 
	 @Test (priority=3)
		public  void TestFunctionTag() throws Exception{
		    SoftAssert softAssert2 = new SoftAssert();
			String functionAppTagElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.FUNCTION_APP_TAG)).getText(); 
			WebElement functionAppTag = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.FUNCTION_APP_TAG));
			String lines[] = functionAppTagElement.split("\\r?\\n");
			System.out.println(lines[0]);
			System.out.println(lines[1]);
			System.out.println(lines[2]);
			String FunctionAppTagElement1="";
			for (String Tag : lines)
			{    
				FunctionAppTagElement1= FunctionAppTagElement1 + Tag + " ";  
					
			       }
			
			String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5);
			String testId = reader.getCellData(sheetname, "TEST ID" , 5);
			 
			 if( FunctionAppTagElement1.strip().equalsIgnoreCase(expectedResult)) {
			     String  status= "pass";
			     reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
			 }
			 else {
				String status="fail";
				reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
			 }
			 
			 	softAssert2.assertEquals(FunctionAppTagElement1.strip(), expectedResult); 
			 	
			    reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, functionAppTagElement);
			    reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
			 
			 
			 
			 //Highlighting element & Taking screenshot 
			  JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
			  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",functionAppTag ); 
			  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
			  Thread.sleep(1000);
			  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",functionAppTag ); 
			  softAssert2.assertAll();
				 
			
			
		} 


}
