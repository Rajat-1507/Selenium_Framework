package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestApplicationGateway extends Setup {
	
	  Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Application_Gateway";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestApplicationGatewayResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
			    
		 SoftAssert softAssert = new SoftAssert();	
		 
		 String applicationGatewayResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement applicationGatewayResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				if(applicationGatewayResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, applicationGatewayResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(applicationGatewayResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",applicationGatewayResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",applicationGatewayResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestApplicationGatewayLocation() throws Exception{
		
		  SoftAssert softAssert1 = new SoftAssert();
		  
		  String applicationGatewayLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_LOCATION)).getText().strip(); 
		  WebElement applicationGatewayLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_LOCATION));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				if(applicationGatewayLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, applicationGatewayLocationElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(applicationGatewayLocationElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",applicationGatewayLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",applicationGatewayLocation ); 
				 softAssert1.assertAll();
				 				  
	 }

	 @Test (priority=3)
	  public  void TestApplicationGatewayPublicIpId() throws Exception{
		 
		 SoftAssert softAssert2 = new SoftAssert();
		 
		 String applicationGatewayPublicIpIdElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_PUBLIC_IP_ID)).getText().strip(); 
		 WebElement ApplicationGatewayPublicIpId = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_PUBLIC_IP_ID));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(applicationGatewayPublicIpIdElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, applicationGatewayPublicIpIdElement);
				 softAssert2.assertEquals(applicationGatewayPublicIpIdElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",ApplicationGatewayPublicIpId ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",ApplicationGatewayPublicIpId ); 
				 softAssert2.assertAll();
				 
	 }

	 
	 @Test (priority=4)
	  public  void TestApplicationGatewayVnetSubnet() throws Exception{
		 
		 SoftAssert softAssert3 = new SoftAssert();
		 
		 String applicationGatewayVnetSubnetElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_VIRTUAL_NETWORK_SUBNET)).getText().strip(); 
		 WebElement applicationGatewayVnetSubnet = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_VIRTUAL_NETWORK_SUBNET));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(applicationGatewayVnetSubnetElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, applicationGatewayVnetSubnetElement);
				 softAssert3.assertEquals(applicationGatewayVnetSubnetElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",applicationGatewayVnetSubnet ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",applicationGatewayVnetSubnet ); 
				 softAssert3.assertAll();
		 
	 }
	 
	 @Test (priority=5)
	  public  void TestApplicationGatewayName() throws Exception{
		 
		 SoftAssert softAssert4 = new SoftAssert();
		 
		 String applicationGatewayNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_NAME)).getText().strip(); 
		 WebElement applicationGatewayName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				if(applicationGatewayNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, applicationGatewayNameElement);
				 softAssert4.assertEquals(applicationGatewayNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",applicationGatewayName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",applicationGatewayName ); 
				 softAssert4.assertAll();		 
			
	 }  
	 
	 @Test (priority=6)
	  public  void TestApplicationGatewaySku() throws Exception{
		 
		  SoftAssert softAssert5 = new SoftAssert();
		  
	      driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_CONFIGURATION_CLICK)).click();
	      Thread.sleep(3000);
		  String applicationGatewaySkuElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_SKU)).getText().strip(); 
		  WebElement applicationGatewaySku = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_SKU));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(applicationGatewaySkuElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, applicationGatewaySkuElement);
				 softAssert5.assertEquals(applicationGatewaySkuElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",applicationGatewaySku ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",applicationGatewaySku ); 
				 softAssert5.assertAll(); 			 
				
	 }	 
	 
	 @Test (priority=7)
	  public  void TestApplicationGatewayIpConfigName() throws Exception{
		 
		  SoftAssert softAssert6 = new SoftAssert();
		  
	      driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_FRONTEND_IP_CONFIG_CLICK)).click();
	      Thread.sleep(2000);
		  String applicationGatewayIpConfigNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_IP_CONFIGURATION_NAME)).getText().strip(); 
		  WebElement applicationGatewayIpConfigName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.APPGATEWAY_IP_CONFIGURATION_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(applicationGatewayIpConfigNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, applicationGatewayIpConfigNameElement);
				 softAssert6.assertEquals(applicationGatewayIpConfigNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",applicationGatewayIpConfigName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",applicationGatewayIpConfigName ); 
				 softAssert6.assertAll(); 			 
				
	 }	 
	 
	 
}
