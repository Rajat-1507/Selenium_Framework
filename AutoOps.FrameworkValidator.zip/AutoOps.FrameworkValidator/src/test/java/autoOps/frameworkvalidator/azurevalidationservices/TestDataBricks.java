package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestDataBricks extends Setup {
	
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Databricks";
	  String status;
	  
	 
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();
	 String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	  
	 @Test (priority=1)
	  public  void TestDataBricksResourceGroupName() throws Exception{
		   

		 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
		 Thread.sleep(2000);
	    
	  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
	    Thread.sleep(3000);
	    
	    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
	   	
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
	      SoftAssert softAssert = new SoftAssert();
		  String dataBricksResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		  WebElement dataBricksresourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_RESOURCE_GROUP_NAME_XPATH));
		  String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(dataBricksResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, dataBricksResourceGroupNameElement);
				 softAssert.assertEquals(dataBricksResourceGroupNameElement, expectedResult);
				
				 
				// Highlighting element & Taking screenshot
				
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksresourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +  testId + ".png" );
				 Thread.sleep(1000);				 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksresourceGroupName ); 
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertAll();
				  
		
	}

	@Test (priority=2)
	public  void TestDataBricksLocation() throws Exception{
		SoftAssert softAssert1 = new SoftAssert();
		String dataBricksLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_LOCATION_XPATH)).getText(); 
		WebElement dataBricksLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_LOCATION_XPATH));
		String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3);
		 
		String testId = reader.getCellData(sheetname, "TEST ID" , 3);
		 
		 if( dataBricksLocationElement.equalsIgnoreCase(expectedResult)) {
			 String  status= "pass";
			 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
		
		 }
		 else {
			String status="fail";
			reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
			
		 }
		 
		 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, dataBricksLocationElement);
		 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
		 softAssert1.assertEquals(dataBricksLocationElement, expectedResult);
		    
		  //Highlighting element & Taking screenshot	
		 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksLocation ); 
		 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
		 Thread.sleep(1000);
		 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksLocation ); 
		 softAssert1.assertAll();
		 
		
		 
	}
	
	@Test (priority=3)
	public  void TestDataBricksTag() throws Exception{
		SoftAssert softAssert2 = new SoftAssert();
		String dataBricksTagElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_TAGS_XPATH)).getText(); 
		WebElement dataBricksTag = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_TAGS_XPATH));
		String lines[] = dataBricksTagElement.split("\\r?\\n");
		System.out.println(lines[0]);
		System.out.println(lines[1]);
		System.out.println(lines[2]);
		String DataBricksTagTagElement1="";
		for (String Tag : lines)
		{    
			DataBricksTagTagElement1= DataBricksTagTagElement1 + Tag + " ";  
				
		       }
		System.out.println(DataBricksTagTagElement1);
		String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4);
		String testId = reader.getCellData(sheetname, "TEST ID" , 4);
		 
		 if( DataBricksTagTagElement1.strip().equalsIgnoreCase(expectedResult)) {
		     String  status= "pass";
		     reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
		 }
		 else {
			String status="fail";
			reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
		 }
		 
		 	softAssert2.assertEquals(DataBricksTagTagElement1.strip(), expectedResult); 
		 	
		    reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, dataBricksTagElement);
		    reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
		 
		 
		 
		 //Highlighting element & Taking screenshot 
		  JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
		  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksTag ); 
		  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
		  Thread.sleep(1000);
		  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksTag ); 
		  softAssert2.assertAll();
			 
		
		
	} 
	
	@Test (priority=4)
	  public  void TestDataBricksName() throws Exception{
		SoftAssert softAssert3 = new SoftAssert();
		  String dataBricksNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_NAME_XPATH)).getText().strip(); 
		  WebElement dataBricksName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_NAME_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(dataBricksNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, dataBricksNameElement);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 softAssert3.assertEquals(dataBricksNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksName ); 
				 softAssert3.assertAll();
				 
				  
	 }

	@Test (priority=5)
	  public  void TestDataBricksSku() throws Exception{
		  SoftAssert softAssert4 = new SoftAssert();
		  String dataBricksSkuElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_PRICING_TIER_XPATH)).getText().strip(); 
		  WebElement dataBricksSku = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_PRICING_TIER_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(dataBricksSkuElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, dataBricksSkuElement);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 softAssert4.assertEquals(dataBricksSkuElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksSku ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksSku ); 
				 softAssert4.assertAll();
				 
				  
	 }

	@Test (priority=6)
	  public  void TestDataBricksClusterName() throws Exception{
		    SoftAssert softAssert5 = new SoftAssert();	 
	     // click on lunch Workspace   
	        driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_LUNCH_WORKSPACE_XPATH)).click();
	        Thread.sleep(9000);
	        
	        Set<String> windowhandles = driver.getWindowHandles();
	        Iterator<String> iterator =windowhandles.iterator();
	        String parentwindow = iterator.next();
	        String childwindow = iterator.next();
	        
	        driver.switchTo().window(childwindow);
	        driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_COMPUTE_CLICK_XPATH)).click();
	        Thread.sleep(3000);
	        //driver.findElement(By.xpath(FrameworkValidator_Constants.Constants.DATABRICKS_ALL_CLICK_XPATH)).click();
	       // Thread.sleep(4000);
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
	        driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_CLUSTER_NAME_CLICK_XPATH)).click();
	        Thread.sleep(3000);
	        
	        
			
	
		  String dataBricksClusterNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_CLUSTER_XPATH)).getText().strip(); 
		  WebElement dataBricksClusterName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_CLUSTER_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(dataBricksClusterNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, dataBricksClusterNameElement);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 softAssert5.assertEquals(dataBricksClusterNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksClusterName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksClusterName ); 				
				 softAssert5.assertAll();
				 
				 
				  
	 }
	
	@Test (priority=7)
	  public  void TestDataBricksSparkVersion() throws Exception{
		SoftAssert softAssert6 = new SoftAssert();
		driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_CLUSTER_XPATH)).click();
		Thread.sleep(3000);
	
		  String dataBricksSparkVersionElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_SPARKVERSION_XPATH)).getText().strip(); 
		  WebElement dataBricksSparkVersion= driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_SPARKVERSION_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(dataBricksSparkVersionElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, dataBricksSparkVersionElement);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 softAssert6.assertEquals(dataBricksSparkVersionElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksSparkVersion ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksSparkVersion ); 
				 softAssert6.assertAll();
				 
				  
	 }
	
	@Test (priority=8)
	  public  void TestDataBricksNodeTypeId() throws Exception{
		SoftAssert softAssert7 = new SoftAssert();
		  String dataBricksNodeTypeIdElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_NODE_TYPE_ID_XPATH)).getText().strip(); 
		  WebElement dataBricksNodeTypeId= driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_NODE_TYPE_ID_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(dataBricksNodeTypeIdElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, dataBricksNodeTypeIdElement);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 softAssert7.assertEquals(dataBricksNodeTypeIdElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksNodeTypeId ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksNodeTypeId ); 
				 softAssert7.assertAll();
				 
				  
	 }
	
	@Test (priority=9)
	  public  void TestDataBricksAutoterminationMinutes() throws Exception{
		  SoftAssert softAssert8 = new SoftAssert();
		  String dataBricksAutoterminationMinutesElement = "10"; 
		  System.out.println(dataBricksAutoterminationMinutesElement);
		  WebElement dataBricksAutoterminationMinutes= driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_AUTOTERMINATION_MINUTES_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 10);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",10).strip();
		
				 if(dataBricksAutoterminationMinutesElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 10, dataBricksAutoterminationMinutesElement);
				 reader.setCellData(sheetname, "Evidence", 10, testId + ".png");
				 softAssert8.assertEquals(dataBricksAutoterminationMinutesElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksAutoterminationMinutes ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksAutoterminationMinutes ); 
				 softAssert8.assertAll();
				 
				  
	 }
	
	@Test (priority=10)
	  public  void TestDataBricksMinWorkers() throws Exception{
		  SoftAssert softAssert9 = new SoftAssert();
		  String dataBricksMinWorkersElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_MINIMUM_WORKERS_XPATH)).getText().strip(); 
		  WebElement dataBricksMinWorkers= driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_MINIMUM_WORKERS_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 11);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",11).strip();
		
				 if(dataBricksMinWorkersElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 11, dataBricksMinWorkersElement);
				 reader.setCellData(sheetname, "Evidence", 11, testId + ".png");
				 softAssert9.assertEquals(dataBricksMinWorkersElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksMinWorkers ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksMinWorkers ); 
				 softAssert9.assertAll();
				 				  
	 }
	
	@Test (priority=11)
	  public  void TestDataBricksMaxWorkers() throws Exception{
		SoftAssert softAssert10 = new SoftAssert();
		Set<String> windowhandles = driver.getWindowHandles();
        Iterator<String> iterator =windowhandles.iterator();
        String parentwindow = iterator.next();
        String childwindow = iterator.next();
	
		  String dataBricksMaxWorkersElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_MAXIMUM_WORKERS_XPATH)).getText().strip(); 
		  WebElement dataBricksMaxWorkers= driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATABRICKS_MAXIMUM_WORKERS_XPATH));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 12);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",12).strip();
		
				 if(dataBricksMaxWorkersElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 12, dataBricksMaxWorkersElement);
				 reader.setCellData(sheetname, "Evidence", 12, testId + ".png");
				 softAssert10.assertEquals(dataBricksMaxWorkersElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataBricksMaxWorkers ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataBricksMaxWorkers );
				 driver.close();
				 driver.switchTo().window(parentwindow);
				 
				 softAssert10.assertAll();
				 			  
	 }


}
