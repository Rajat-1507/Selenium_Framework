package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestSynapseDedicated extends Setup{

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="SynapseDedicated";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestDedicatedSqlPoolName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    Thread.sleep(6000);	
			   
			    
		 SoftAssert softAssert = new SoftAssert();	    
		 String dedicatedSqlPoolNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_NAME)).getText().strip(); 
		 WebElement DedicatedSqlPoolName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(dedicatedSqlPoolNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, dedicatedSqlPoolNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(dedicatedSqlPoolNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",DedicatedSqlPoolName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",DedicatedSqlPoolName ); 
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestDedicatedSqlPerformanceLevel() throws Exception{
		
		  SoftAssert softAssert1 = new SoftAssert();
		  String dedicatedSqlPerformanceLevelElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_PERFORMANCE_LEVEL)).getText().strip(); 
		  WebElement dedicatedSqlPerformanceLevel = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_PERFORMANCE_LEVEL));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(dedicatedSqlPerformanceLevelElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, dedicatedSqlPerformanceLevelElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(dedicatedSqlPerformanceLevelElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dedicatedSqlPerformanceLevel ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dedicatedSqlPerformanceLevel ); 
				 softAssert1.assertAll();
				 				  
	 }

	 @Test (priority=3)
	  public  void TestDedicatedSqlPoolCollation() throws Exception{
		 
		 SoftAssert softAssert2 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_PROPERTIES_CLICK)).click();
		 Thread.sleep(4000);
		 String dedicatedSqlPoolCollationElement = "SQL_Latin1_General_CP1_CI_AS"; 
		 WebElement dedicatedSqlPoolCollation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_COLLATION));
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(dedicatedSqlPoolCollationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, dedicatedSqlPoolCollationElement);
				 softAssert2.assertEquals(dedicatedSqlPoolCollationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dedicatedSqlPoolCollation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dedicatedSqlPoolCollation ); 
				 softAssert2.assertAll();
				 
	 }

	 
	 @Test (priority=4)
	  public  void TestDedicatedSqlPoolPrivateEndpoint() throws Exception{
		 
		 SoftAssert softAssert3 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_OVERVIEW_CLICK)).click();
		 Thread.sleep(4000);
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_WORKSPACE_CLICK)).click();
		 Thread.sleep(4000);
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_PRIVATE_ENDPOINT_CONNECTION_CLICK)).click();
		 Thread.sleep(4000);
		 String dedicatedSqlPoolPrivateEndpointElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_PRIVATE_ENDPOINT_NAME)).getText().strip(); 
		 WebElement dedicatedSqlPoolPrivateEndpoint = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DEDICATED_SQL_POOL_PRIVATE_ENDPOINT_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(dedicatedSqlPoolPrivateEndpointElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, dedicatedSqlPoolPrivateEndpointElement);
				 softAssert3.assertEquals(dedicatedSqlPoolPrivateEndpointElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dedicatedSqlPoolPrivateEndpoint ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dedicatedSqlPoolPrivateEndpoint ); 
				 softAssert3.assertAll();
				 Thread.sleep(2000);
		 
	 }
	
}
