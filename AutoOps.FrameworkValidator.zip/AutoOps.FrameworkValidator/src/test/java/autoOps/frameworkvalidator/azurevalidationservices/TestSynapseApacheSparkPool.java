package autoOps.frameworkvalidator.azurevalidationservices;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestSynapseApacheSparkPool extends Setup {

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="SynapseSparkPool";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	  public  void clickfunction(String Xpath) throws Exception {
		
		  
			  driver.findElement(By.xpath(Xpath)).click();
			  Thread.sleep(4000);
		
	  }
	 
	 @Test (priority=1)
	  public  void TestSparkPoolResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(1000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(2000);
			    
			    clickfunction(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK);
			    Thread.sleep(6000);
			 
			    SoftAssert softAssert = new SoftAssert(); 
			    		 
		 String sparkPoolResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement sparkPoolResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(sparkPoolResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, sparkPoolResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(sparkPoolResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sparkPoolResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sparkPoolResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
	 @Test (priority=2)
	  public  void TestSparkPoolName() throws Exception{
	
		 SoftAssert softAssert1 = new SoftAssert();		 
			    
		 String sparkPoolNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_NAME)).getText().strip(); 
		 WebElement sparkPoolName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(sparkPoolNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, sparkPoolNameElement);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 softAssert1.assertEquals(sparkPoolNameElement, expectedResult);
				 
				 
				
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sparkPoolName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sparkPoolName ); 
				 softAssert1.assertAll();
				 
	 }
	 
	 @Test (priority=3)
	  public  void TestNodeSize() throws Exception{
	
		 SoftAssert softAssert2 = new SoftAssert();	 
		 
		 clickfunction(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_PROPERTIES_CLICK);
		 Thread.sleep(4000);    
		 
		 String nodeSizeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_NODE_SIZE)).getText().strip(); 
		 WebElement nodeSize = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_NODE_SIZE));
		 String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
		// Scrolling down 
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",nodeSize );
	      Thread.sleep(5000);
		 
				 if(nodeSizeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, nodeSizeElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert2.assertEquals(nodeSizeElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",nodeSize ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",nodeSize ); 
				 softAssert2.assertAll();
				 
	 }
	  
	 @Test (priority=4)
	  public  void TestNodeSizeFamily() throws Exception{
	
		 SoftAssert softAssert3 = new SoftAssert();	 
			    
		 String nodeSizeFamilyElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_NODE_SIZE_FAMILY)).getText().strip(); 
		 WebElement nodeSizeFamily = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_NODE_SIZE_FAMILY));
		
		// Scrolling down 
				 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",nodeSizeFamily );
			      Thread.sleep(2000);
			      
		 String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(nodeSizeFamilyElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, nodeSizeFamilyElement);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 softAssert3.assertEquals(nodeSizeFamilyElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",nodeSizeFamily ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",nodeSizeFamily ); 
				 softAssert3.assertAll();
				 
	 }
	 
	 
	 @Test (priority=5)
	  public  void TestIntelligentCacheSize() throws Exception{
	
		 SoftAssert softAssert4 = new SoftAssert();	 
			    
		 String intelligentCacheSizeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_INTELLIGENT_CACHE_SIZE)).getText().strip(); 
		 WebElement intelligentCacheSize = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_INTELLIGENT_CACHE_SIZE));
		 
		// Scrolling down 
		 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",intelligentCacheSize );
	      Thread.sleep(2000);
	      
		 String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(intelligentCacheSizeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, intelligentCacheSizeElement);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 softAssert4.assertEquals(intelligentCacheSizeElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",intelligentCacheSize ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",intelligentCacheSize ); 
				 softAssert4.assertAll();
				 
	 }
	 
	 
	 @Test (priority=6)
	  public  void TestNoOfNodes() throws Exception{
	
		 SoftAssert softAssert6 = new SoftAssert();	 
		    
		 String noOfNodesElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_NO_OF_NODES)).getText().strip(); 
		 WebElement noOfNodes = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_NO_OF_NODES));
		 String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(noOfNodesElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, noOfNodesElement);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 softAssert6.assertEquals(noOfNodesElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",noOfNodes ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",noOfNodes ); 
				 softAssert6.assertAll();
				 
	 }
	 
	 
	 @Test (priority=7)
	  public  void TestAutomaticPausing() throws Exception{
	
		 SoftAssert softAssert7 = new SoftAssert();	 
		  	    
		 String automaticPausingElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_AUTOMATIC_PAUSING)).getText().strip(); 
		 WebElement automaticPausing = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_AUTOMATIC_PAUSING));
		 String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(automaticPausingElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, automaticPausingElement);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 softAssert7.assertEquals(automaticPausingElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",automaticPausing ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",automaticPausing ); 
				 softAssert7.assertAll();
	 }
	 
	 @Test (priority=8)
	  public  void TestSparkPoolPrivateEndpoint() throws Exception{
	
		 SoftAssert softAssert8 = new SoftAssert();	 
		 clickfunction(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_OVERVIEW_CLICK);
		 
		 clickfunction(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_WORKSPACE_CLICK);
		 
		 clickfunction(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_PRIVATE_ENDPOINT_CONNECTION_CLICK);
		 
		  	    
		 String sparkPoolPrivateEndpointElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_PRIVATE_ENDPOINT)).getText().strip(); 
		 WebElement sparkPoolPrivateEndpoint = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SPARK_POOL_PRIVATE_ENDPOINT));
	      
		 String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(sparkPoolPrivateEndpointElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, sparkPoolPrivateEndpointElement);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 softAssert8.assertEquals(sparkPoolPrivateEndpointElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",sparkPoolPrivateEndpoint ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",sparkPoolPrivateEndpoint ); 
				 softAssert8.assertAll();
				 Thread.sleep(2000);
	 }			 
	 
	 
}
