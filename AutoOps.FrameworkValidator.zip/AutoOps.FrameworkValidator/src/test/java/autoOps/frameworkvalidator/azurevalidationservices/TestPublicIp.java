package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestPublicIp extends Setup{

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Public-Ip";
	  String status;
	 
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestPublicIpResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    Thread.sleep(5000);	
			  
		 SoftAssert softAssert = new SoftAssert();	    
		 String publicIpResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement publicIpResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(publicIpResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, publicIpResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(publicIpResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicIpResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicIpResourceGroupName ); 
				 softAssert.assertAll();
				 
	 }
	 
@Test (priority=2)
	  public  void TestPublicIpName() throws Exception{
	      SoftAssert softAssert1 = new SoftAssert();
		  String publicIpNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_NAME)).getText().strip(); 
		  WebElement publicIpName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(publicIpNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, publicIpNameElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert1.assertEquals(publicIpNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicIpName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicIpName ); 
				 softAssert1.assertAll();
				 
				  
	 }

	 @Test (priority=3)
	  public  void TestPublicIpLocation() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 String publicIpLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_LOCATION)).getText().strip(); 
		 WebElement publicIpLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_LOCATION));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(publicIpLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, publicIpLocationElement);
				 softAssert2.assertEquals(publicIpLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicIpLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicIpLocation ); 
				 softAssert2.assertAll();
				 
	 }
	 
	 @Test (priority=4)
	  public  void TestPublicIpSku() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		 
		 String publicIpSkuElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_SKU)).getText().strip(); 
		 WebElement publicIpSku = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_SKU));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(publicIpSkuElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, publicIpSkuElement);
				 softAssert3.assertEquals(publicIpSkuElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicIpSku ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicIpSku ); 
				 softAssert3.assertAll();			 

	 }  
	 
	 @Test (priority=5)
	  public  void TestPublicIpVmName() throws Exception{
		 SoftAssert softAssert4 = new SoftAssert();
		 
		 String publicIpVmNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_VM_NAME)).getText().strip(); 
		 WebElement publicIpVmName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_VM_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(publicIpVmNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, publicIpVmNameElement);
				 softAssert4.assertEquals(publicIpVmNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicIpVmName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicIpVmName ); 
				 softAssert4.assertAll();			 

	 }  

	 
	 @Test (priority=6)
	  public  void TestPublicIpAllocationMethod() throws Exception{
		 SoftAssert softAssert5 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_CONFIGURATION_CLICK)).click();
		 Thread.sleep(3000);
		 
		 String publicIpAllocationMethodElement = "Dynamic";
		 WebElement publicIpAllocationMethod = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.PUBLIC_IP_ALLOCATION_METHOD));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(publicIpAllocationMethodElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, publicIpAllocationMethodElement);
				 softAssert5.assertEquals(publicIpAllocationMethodElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",publicIpAllocationMethod ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",publicIpAllocationMethod ); 
				 softAssert5.assertAll();
		 
	 }
	 
	
}
