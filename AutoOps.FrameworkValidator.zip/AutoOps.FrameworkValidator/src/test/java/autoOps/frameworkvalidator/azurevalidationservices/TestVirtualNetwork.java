package autoOps.frameworkvalidator.azurevalidationservices;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestVirtualNetwork extends Setup {
	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Virtual_Network";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	 
	 @Test (priority=1)
	  public  void TestVirtualNetworkResourceGroupName() throws Exception{
		  
	
		 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
		 Thread.sleep(2000);
	    System.out.println(test_result);
	  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);
	  	
	    Thread.sleep(3000);
	    
	    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
	    Thread.sleep(10000);
			   
			   	    
		 SoftAssert softAssert = new SoftAssert();	
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_IFRAME)));
		 Thread.sleep(2000);
		 String virtualNetworkResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_RESOURCE_GROUP_NAME)).getText().strip(); 
		 WebElement virtualNetworkResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_RESOURCE_GROUP_NAME));
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(virtualNetworkResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, virtualNetworkResourceGroupNameElement);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 softAssert.assertEquals(virtualNetworkResourceGroupNameElement, expectedResult);
				 
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualNetworkResourceGroupName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualNetworkResourceGroupName ); 
				 driver.switchTo().defaultContent();
				 softAssert.assertAll();
		  
		  

	
				 
	 }
	 
	 @Test (priority=2)
	  public  void TestVirtualNetworkLocation() throws Exception{
		 
		 SoftAssert softAssert1 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_IFRAME)));
		 Thread.sleep(2000);
		 String virtualNetworkLocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_LOCATION)).getText().strip(); 
		 WebElement virtualNetworkLocation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_LOCATION));
		  String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(virtualNetworkLocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, virtualNetworkLocationElement);
				 softAssert1.assertEquals(virtualNetworkLocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualNetworkLocation ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualNetworkLocation ); 
				 driver.switchTo().defaultContent();
				 softAssert1.assertAll(); 
	 	
				 
	 } 

	 
@Test (priority=3)
	  public  void TestVirtualNetworkName() throws Exception{
		 
		 
	    SoftAssert softAssert2 = new SoftAssert();   
	
		  String virtualNetworNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_NAME)).getText().strip(); 
		  WebElement virtualNetworName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_NAME));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(virtualNetworNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, virtualNetworNameElement);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 softAssert2.assertEquals(virtualNetworNameElement, expectedResult);
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualNetworName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualNetworName ); 
				 softAssert2.assertAll();
				 
				  
	 }

	
	 
	 @Test (priority=4)
	  public  void TestVirtualNetworkSubnetName() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_SUBNETS_CLICK)).click();
		 Thread.sleep(3000);
		 
		 String virtualNetworkSubnetNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_SUBNET_NAME)).getText().strip(); 
		 WebElement virtualNetworkSubnetName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_SUBNET_NAME));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(virtualNetworkSubnetNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, virtualNetworkSubnetNameElement);
				 softAssert3.assertEquals(virtualNetworkSubnetNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",virtualNetworkSubnetName ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",virtualNetworkSubnetName ); 
				 softAssert3.assertAll();
		 
	 }
	 
	 @Test (priority=5)
	  public  void TestPowerBiSubject() throws Exception{
		 SoftAssert softAssert4 = new SoftAssert();
		
		 String powerBiSubnetElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_POWERBI_SUBNET)).getText().strip(); 
		 WebElement powerBiSubnet = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.VNET_POWERBI_SUBNET));	
		  String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		  String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(powerBiSubnetElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					 String status="fail";
					 reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, powerBiSubnetElement);
				 softAssert4.assertEquals(powerBiSubnetElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",powerBiSubnet ); 
				 autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath  + testId + ".png" );
				 Thread.sleep(1000);
				 jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",powerBiSubnet ); 
				 softAssert4.assertAll();
				 Thread.sleep(2000);
		 
	 }
	 
	 

}
