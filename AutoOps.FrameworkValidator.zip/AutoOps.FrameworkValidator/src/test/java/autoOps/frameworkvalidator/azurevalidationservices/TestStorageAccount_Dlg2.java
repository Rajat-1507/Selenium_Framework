package autoOps.frameworkvalidator.azurevalidationservices;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import autoOps.frameworkvalidator.util.*;
import autoOps.frameworkvalidator.utils.*;
import autoOps.frameworkvalidator.azurevalidationservices.*;
import autoOps.frameworkvalidator.intializer.Setup;

public class TestStorageAccount_Dlg2 extends Setup{

	Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	  String sheetname="Storage(Datalake)";
	  String status;
	  
	  Navigator object = new Navigator();
	  String directory = object.Timestamp();  
	  String  filePath = autoOps.frameworkvalidator.config.Config.Screenshot_folder_path  + directory ;
	 
	  public  void clickfunction(String Xpath) throws Exception {
			
		  
		  driver.findElement(By.xpath(Xpath)).click();
		  Thread.sleep(4000);
	
}

	 
	 @Test (priority=1)
	  public  void TestResourceGroupName() throws Exception{
	
				 String test_result = reader.getCellData(sheetname, "TEST DATA", 2);
				 Thread.sleep(2000);
			    
			  	driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SERVICE_SEARCH_XPATH)).sendKeys(test_result);    
			    Thread.sleep(3000);
			    
			    driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.SEARCH_SERVICE_CLICK)).click();
			    Thread.sleep(4000);	
			  
		 SoftAssert softAssert = new SoftAssert();	    
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	    
		 String dataLakeGen2ResourceGroupNameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_RESOURCE_GROUP_NAME_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2ResourceGroupName = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_RESOURCE_GROUP_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 2);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",2).strip();
		
				 if(dataLakeGen2ResourceGroupNameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 2, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 2, dataLakeGen2ResourceGroupNameElement);
				 softAssert.assertEquals(dataLakeGen2ResourceGroupNameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 2, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2ResourceGroupName ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2ResourceGroupName ); 
				  driver.switchTo().defaultContent();
				  softAssert.assertAll();
				  
				
	 }
	 
	 @Test (priority=2)
	  public  void TestLocation() throws Exception{
		 SoftAssert softAssert1 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	
			    
		 String dataLakeGen2LocationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_LOCATION_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2Location = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_LOCATION_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 4);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",4).strip();
		
				 if(dataLakeGen2LocationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 4, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 4, dataLakeGen2LocationElement);
				 softAssert1.assertEquals(dataLakeGen2LocationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 4, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2Location ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2Location ); 
				  driver.switchTo().defaultContent();
				  softAssert1.assertAll();		  
				
	 }
	 
	 @Test (priority=6)
	  public  void TestStorageAccountName() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();	    
		 String dataLakeGen2NameElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ACCOUNT_NAME_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2Name = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ACCOUNT_NAME_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 3);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",3).strip();
		
				 if(dataLakeGen2NameElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 3, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 3, dataLakeGen2NameElement);
				 softAssert2.assertEquals(dataLakeGen2NameElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 3, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2Name ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2Name ); 
				  softAssert2.assertAll();		  
				
	 }
	 
	 @Test (priority=3)
	  public  void TestPerformance() throws Exception{
		 SoftAssert softAssert2 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	
			    
		 String dataLakeGen2AccountTierElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_PERFORMANCE_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2AccountTier = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_PERFORMANCE_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 5);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",5).strip();
		
				 if(dataLakeGen2AccountTierElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 5, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 5, dataLakeGen2AccountTierElement);
				 softAssert2.assertEquals(dataLakeGen2AccountTierElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 5, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2AccountTier ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2AccountTier ); 
				  driver.switchTo().defaultContent();
				  softAssert2.assertAll();		  
				
	 }
	 
	 @Test (priority=4)
	  public  void TestRedundancy() throws Exception{
		 SoftAssert softAssert3 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	
			    
		 String dataLakeGen2AccountReplicationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_REDUNDANCY_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2AccountReplication = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_REDUNDANCY_XPATH));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 6);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",6).strip();
		
				 if(dataLakeGen2AccountReplicationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 6, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 6, dataLakeGen2AccountReplicationElement);
				 softAssert3.assertEquals(dataLakeGen2AccountReplicationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 6, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2AccountReplication ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2AccountReplication ); 
				  driver.switchTo().defaultContent();
				  softAssert3.assertAll();		  
				
	 }
	 
	 @Test (priority=5)
	  public  void TestSubScription() throws Exception{
		 SoftAssert softAssert4 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));	
			    
		 String dataLakeGen2AccountKindElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_SUBSCRIPTION)).getText().strip(); 
		 WebElement dataLakeGen2AccountKind = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_SUBSCRIPTION));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 7);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",7).strip();
		
				 if(dataLakeGen2AccountKindElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 7, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 7, dataLakeGen2AccountKindElement);
				 softAssert4.assertEquals(dataLakeGen2AccountKindElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 7, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2AccountKind ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2AccountKind ); 
				  driver.switchTo().defaultContent();
				  softAssert4.assertAll();		  
				
	 }
	 
	 @Test (priority=7)
	  public  void TestEnabledHierarchicalNamespace() throws Exception{
		 SoftAssert softAssert6 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String dataLakeGen2HnsEnabledElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ENABLE_HEIRARCHICAL_NAMESPACE_XPATH)).getText().strip(); 
		 WebElement dataLakeGen2HnsEnabled = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.DATALAKEGEN2_ENABLE_HEIRARCHICAL_NAMESPACE_XPATH));	
		 
		// Scrolling down 
				 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);",dataLakeGen2HnsEnabled );
			      Thread.sleep(3000);
		 
		 String testId = reader.getCellData(sheetname, "TEST ID", 8);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",8).strip();
		
				 if(dataLakeGen2HnsEnabledElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 8, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 8, dataLakeGen2HnsEnabledElement);
				 softAssert6.assertEquals(dataLakeGen2HnsEnabledElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 8, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",dataLakeGen2HnsEnabled ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",dataLakeGen2HnsEnabled ); 
				  driver.switchTo().defaultContent();
				  softAssert6.assertAll();		  
				
	 }
	 
	 @Test (priority=8)
	  public  void TestRST_RestApiOperation() throws Exception{
		 SoftAssert softAssert7 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String rSTRestApiOperationElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_REST_API_OPERATION)).getText().strip(); 
		 WebElement rSTRestApiOperation = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_REST_API_OPERATION));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 9);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",9).strip();
		
				 if(rSTRestApiOperationElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 9, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 9, rSTRestApiOperationElement);
				 softAssert7.assertEquals(rSTRestApiOperationElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 9, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",rSTRestApiOperation ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",rSTRestApiOperation ); 
				  driver.switchTo().defaultContent();
				  softAssert7.assertAll();		  
				
	 }
	 
	 
	 @Test (priority=9)
	  public  void TestEnableBlobPublicAccess() throws Exception{
		 SoftAssert softAssert8 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String enableBlobPublicAccessElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_BLOB_PUBLIC_ACCESS)).getText().strip(); 
		 WebElement enableBlobPublicAccess = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_BLOB_PUBLIC_ACCESS));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 10);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",10).strip();
		
				 if(enableBlobPublicAccessElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 10, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 10, enableBlobPublicAccessElement);
				 softAssert8.assertEquals(enableBlobPublicAccessElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 10, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",enableBlobPublicAccess ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",enableBlobPublicAccess ); 
				  driver.switchTo().defaultContent();
				  softAssert8.assertAll();		  
				
	 }
	
	 @Test (priority=10)
	  public  void TestStorageAccKeyAccess() throws Exception{
		 SoftAssert softAssert9 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String enableStorageAccKeyAccessElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_KEY_ACCESS)).getText().strip(); 
		 WebElement enableStorageAccKeyAccess = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_KEY_ACCESS));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 11);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",11).strip();
		
				 if(enableStorageAccKeyAccessElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 11, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 11, enableStorageAccKeyAccessElement);
				 softAssert9.assertEquals(enableStorageAccKeyAccessElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 11, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",enableStorageAccKeyAccess ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",enableStorageAccKeyAccess ); 
				  driver.switchTo().defaultContent();
				  softAssert9.assertAll();		  		
	 }
	 
	 
	 @Test (priority=11)
	  public  void TestNetworkAccess() throws Exception{
		 SoftAssert softAssert10 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String networkAccessElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_NETWORK_ACCESS)).getText().strip(); 
		 WebElement networkAccess = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_NETWORK_ACCESS));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 12);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",12).strip();
		
				 if(networkAccessElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 12, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 12, networkAccessElement);
				 softAssert10.assertEquals(networkAccessElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 12, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",networkAccess ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",networkAccess ); 
				  driver.switchTo().defaultContent();
				  softAssert10.assertAll();		  
				
	 }
	 
	 @Test (priority=12)
	  public  void TestRoutingPreference() throws Exception{
		 SoftAssert softAssert11 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String routingPreferenceElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_ROUTING_PREFERENCE)).getText().strip(); 
		 WebElement routingPreference = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_ROUTING_PREFERENCE));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 13);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",13).strip();
		
				 if(routingPreferenceElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 13, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 13, routingPreferenceElement);
				 softAssert11.assertEquals(routingPreferenceElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 13, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",routingPreference ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",routingPreference ); 
				  driver.switchTo().defaultContent();
				  softAssert11.assertAll();		  
				
	 }
	 
	 
	 @Test (priority=13)
	  public  void TestSoftDeleteBLobs() throws Exception{
		 SoftAssert softAssert12 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String SoftDeleteBLobElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_SOFT_DELETE_BLOBS)).getText().strip(); 
		 WebElement SoftDeleteBLob = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_SOFT_DELETE_BLOBS));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 14);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",14).strip();
		
				 if(SoftDeleteBLobElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 14, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 14, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 14, SoftDeleteBLobElement);
				 softAssert12.assertEquals(SoftDeleteBLobElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 14, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SoftDeleteBLob ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SoftDeleteBLob ); 
				  driver.switchTo().defaultContent();
				  softAssert12.assertAll();		  
				
	 }
	 
	 
	 @Test (priority=14)
	  public  void TestSoftDeleteContainer() throws Exception{
		 SoftAssert softAssert13 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String SoftDeleteContainerElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_SOFT_DELETE_CONTAINERS)).getText().strip(); 
		 WebElement SoftDeleteContainers = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_SOFT_DELETE_CONTAINERS));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 15);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",15).strip();
		
				 if(SoftDeleteContainerElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 15, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 15, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 15, SoftDeleteContainerElement);
				 softAssert13.assertEquals(SoftDeleteContainerElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 15, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SoftDeleteContainers ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SoftDeleteContainers ); 
				  driver.switchTo().defaultContent();
				  softAssert13.assertAll();		  
				
	 }
	 
	 
	 @Test (priority=15)
	  public  void TestSoftDeleteFileShare() throws Exception{
		 SoftAssert softAssert14 = new SoftAssert();
		 driver.switchTo().frame(driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.IFRAME_XPATH)));
		 
		 String SoftDeleteFileShareElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_SOFT_DELETE_FILE_SHARE)).getText().strip(); 
		 WebElement SoftDeleteFileShare = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_SOFT_DELETE_FILE_SHARE));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 16);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",16).strip();
		
				 if(SoftDeleteFileShareElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 16, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 16, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 16, SoftDeleteFileShareElement);
				 softAssert14.assertEquals(SoftDeleteFileShareElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 16, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",SoftDeleteFileShare ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",SoftDeleteFileShare ); 
				  driver.switchTo().defaultContent();
				  softAssert14.assertAll();		  
				
	 }
	
	 
	 @Test (priority=16)
	  public  void TestEncryptinType() throws Exception{
		 SoftAssert softAssert15 = new SoftAssert();
		
		 
		 clickfunction(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_ENCRYPTION_CLICK);
		 
		 
		 String encryptinTypeElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_ENCRYPTION_TYPE)).getText().strip(); 
		 WebElement encryptinType = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_ENCRYPTION_TYPE));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 17);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",17).strip();
		
				 if(encryptinTypeElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 17, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 17, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 17, encryptinTypeElement);
				 softAssert15.assertEquals(encryptinTypeElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 17, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",encryptinType ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",encryptinType ); 
				  
				  softAssert15.assertAll();		  
				
	 }
	 
	 
	 @Test (priority=17)
	  public  void TestEnableSupportCustomersManagedkey() throws Exception{
	
		 SoftAssert softAssert16 = new SoftAssert();
	
		 String enableSupportCustomersManagedkeyElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_ENABLE_SUPPORT_CUSTOMERS_MANAGED_KEY)).getText().strip(); 
		 WebElement enableSupportCustomersManagedkey = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_ENABLE_SUPPORT_CUSTOMERS_MANAGED_KEY));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 18);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",18).strip();
		
				 if(enableSupportCustomersManagedkeyElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 18, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 18, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 18, enableSupportCustomersManagedkeyElement);
				 softAssert16.assertEquals(enableSupportCustomersManagedkeyElement, expectedResult);
				 reader.setCellData(sheetname, "Evidence", 18, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",enableSupportCustomersManagedkey ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",enableSupportCustomersManagedkey ); 
				 
				  softAssert16.assertAll();	
				  Thread.sleep(2000);
				
	 }
	 
/* 
	 @Test (priority=18)
	  public  void TestPrivateEndpoint() throws Exception{
		 
		 SoftAssert softAssert17 = new SoftAssert();
		 
		 driver.navigate().to("https://portal.azure.com/?feature.msaljs=false#@abbritishports.onmicrosoft.com/resource/subscriptions/2911a71f-a2f2-4fb1-a771-a13269a04477/resourceGroups/abp-data-dev-uks-rg01/providers/Microsoft.Network/privateEndpoints/uksdev-vnet-storage-pe01-endpoint/overview");
		 Thread.sleep(7000);
		 		 
		 String privateEndpointElement = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_PRIVATE_ENDPOINT)).getText().strip(); 
		 WebElement privateEndpoint = driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.STORAGE_ACC_PRIVATE_ENDPOINT));	
		 String testId = reader.getCellData(sheetname, "TEST ID", 19);	    
		 String   expectedResult = reader.getCellData(sheetname,"EXPECTED RESULT",19).strip();
		
				 if(privateEndpointElement.equalsIgnoreCase(expectedResult))
				{
				   String  status= "pass";
				   reader.setCellData(sheetname, "STATUS/PASS/FAIL", 19, status);
				
				 }
				 else {
					String status="fail";
					reader.setCellData(sheetname, "STATUS/PASS/FAIL", 19, status);
					
				 }
				
				
				 reader.setCellData(sheetname,"ACTUAL  RESULT" , 19, privateEndpointElement);
				 softAssert17.assertEquals(privateEndpointElement,expectedResult);
				 reader.setCellData(sheetname, "Evidence", 19, testId + ".png");
				 
				// Highlighting element & Taking screenshot
				 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: ')",privateEndpoint ); 
				  autoOps.frameworkvalidator.utils.Screenshot.takeSnapShot(driver,filePath +testId + ".png" );
				  Thread.sleep(1000);
				  jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: ; border: ')",privateEndpoint ); 
				 
				  softAssert17.assertAll();		  
				
	 }  */
	
}

