package autoOps.frameworkvalidator.intializer;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import autoOps.frameworkvalidator.util.Xls_Reader;
import flexjson.JSONDeserializer;
import io.github.bonigarcia.wdm.WebDriverManager;


public class Setup {
	public WebDriver driver;
	//public static WebDriver driver;
	public ExtentReports extent= new ExtentReports();
    public ExtentSparkReporter spark = new ExtentSparkReporter("ExtentReport.html");
	
	//providing path of excels sheet using casting & specifying sheetname in string.
	static Xls_Reader reader =new Xls_Reader(autoOps.frameworkvalidator.config.Config.Excel_file_path1);
	String sheetname="RG";
			
		 			
	
	       // It will run before every class, using this function we will login onto Azure portal.
	        @BeforeClass
	        public void startFMV() throws Throwable {
	        	
	        	//LoginInit instancedriver =LoginInit.getInstance();
	        	//driver = instancedriver.login();
	        	
	       	
	        	// Providing Key vault url.
	        	String keyVaultUri = "https://tcsazaokvdev.vault.azure.net";
	        	//String keyVaultUri = "https://abp-dev-data-uks-kv01.vault.azure.net";
	            
	            SecretClient secretClient = new SecretClientBuilder()
	                    .vaultUrl(keyVaultUri)
	                    .credential(new DefaultAzureCredentialBuilder().build())
	                    .buildClient();
	            
	            //storing username & password in keyvault secrets variables.	             
	            String username = "uname";
	            String password = "pwd";	           
	            String retrieved_username = secretClient.getSecret(username).getValue();
	            String retrieved_password = secretClient.getSecret(password).getValue();
	            String my_username= retrieved_username;
	            String my_password= retrieved_password;
	         
	        	 // Launching chrome browser using webdriver manager.
	        	 WebDriverManager.chromedriver().setup();
	 			 driver = new ChromeDriver();
	 		    	 			 
	 			 driver.manage().window().maximize();
	 			 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
	 			 
	 			 driver.get(autoOps.frameworkvalidator.config.Config.baseUrl);
	 			 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
	 			 
				
				 // It will fill the username using sendkeys method & click on next button.
				 driver.findElement(By.id("i0116")).sendKeys(my_username);
				 Thread.sleep(4000);
				 driver.findElement(By.id("idSIButton9")).click();
				 Thread.sleep(4000);
				
				// It will fill the password using sendkeys method & click on next button.
				 driver.findElement(By.id("i0118")).sendKeys(my_password);
				 Thread.sleep(4000);
				 driver.findElement(By.id("idSIButton9")).click();
				 Thread.sleep(5000);
				
				 // Click on yes pop up.
				 driver.findElement(By.id("idSIButton9")).click();
				 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
				 Thread.sleep(2000); 
				 
				
				 			  
			     // Click on resource group.
				 driver.findElement(By.linkText("Resource groups")).click();
				 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
				 Thread.sleep(3000);

				int row_count =reader.getRowCount(sheetname);
				System.out.println(row_count);

			 // Taking Test data from Excel & storing into string.
				 String test_result = reader.getCellData(sheetname,"TEST DATA", 2);
				 System.out.println(test_result);
				Thread.sleep(3000);
			    
				 // Click on Search box & fill the test data using sendkeys.
			  	 driver.findElement(By.xpath(autoOps.frameworkvalidator.config.Constants.RESOURCE_GROUP_SEARCH)).sendKeys(test_result);    
			     Thread.sleep(5000);
			    
			      // Click on particular service.
	              driver.findElement(By.xpath("/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[3]/div/div/div[2]/div/div[2]/div[1]/div/div/div[1]/div[2]/div/a")).click();
			      driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));	
			      Thread.sleep(9000);
	        	  			      					    
	        }
	        
	       
	        	        
           // It will run After every class run & close the browser.
	        @AfterClass
	        public void stopFMV() {
	        	
	        	driver.close();
	           driver.quit();
	          extent.flush();
	         
	        }
	       
      
	       


	       
	        	
	           
}
