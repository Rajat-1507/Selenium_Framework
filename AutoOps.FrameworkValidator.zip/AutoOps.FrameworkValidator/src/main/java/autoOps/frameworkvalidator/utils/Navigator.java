package autoOps.frameworkvalidator.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Navigator {


	 public  String Timestamp() {
		 DateTimeFormatter formatter
	     = DateTimeFormatter.ofPattern(
	         "dd-MM-yyyy_HH_mm");
	 // Creating an object of LocalDateTime class
	 // and getting local date and time using now()
	 // method
	 LocalDateTime now = LocalDateTime.now();
	 // Formatting LocalDateTime to string
	 String dateTimeString = now.format(formatter);
	 String directory = "fmv_" + dateTimeString + "/" ;
	 return directory;
		 
	 }
}
