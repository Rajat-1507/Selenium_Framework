package autoOps.frameworkvalidator.config;

public class Constants {

	
	// Xpaths for Search & Navigate
			public static final String SERVICE_SEARCH_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[2]/div[2]/div[2]/div/div[1]/div[1]/div[2]/div/div/div/input";
			public static final String  TEST_DATA_SEARCH_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div/div/div/input";
			public static final String SEARCH_SERVICE = "/html/body/div[1]/div[4]/main/div[3]/div[1]/div/nav/a[3]" ;
			public static final String SEARCH_SERVICE_CLICK1 ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[2]/div[2]/div[2]/div/div[3]/div/div/div[2]/div/div[2]/div[1]/div/div[2]/div[1]/div[2]/div/a";
			public static final String SEARCH_SERVICE_CLICK = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[2]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[2]/div[2]/div[2]/div/div[3]/div/div/div[2]/div/div[2]/div[1]/div/div/div[1]/div[2]/div/a";
			
			// Xpaths for Resource Group Element
			
			public static final String RESOURCE_GROUP_NAME_XPATH= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[2]/header/div[2]/div/div[1]/h2";
			public static final String RESOURCE_GROUP_LOCATION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[2]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[1]/div/div[2]/div[4]/div[2]/div[3]/div/div/div[1]";
			public static final String RESOURCE_GROUP_SUBSCRIPTION ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[2]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			public static final String RESOURCE_GROUP_TAGS_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[2]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[1]/div/div[3]/div/div[4]/div/div[1]/div/span";
			public static final String RESOURCE_GROUP_SEARCH = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div/div/div/input";
			
			// Xpaths for KeyVault Elements
			
			public static final String KEYVAULT_RESOURCE_GROUP_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a" ;         
			public static final String KEYVAULT_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			public static final String KEYVAULT_LOCATION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[2]/div[3]/div/div/div[1]";                  
			public static final String KEYVAULT_SKU_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[2]/div[3]/div/div/div[1]";
			public static final String KEYVAULT_PRUGE_PROTECTION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[6]/div[3]/div/div/button" ;                                
			public static final String KEYVAULT_RETENTION_DAYS_XPATH="90" ;       
			public static final String KEYVAULT_RETENTION_DAYS="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[11]/div[2]/div/div/div[2]/div/div/div/input" ; 	
			public static final String KEYVAULT_CERTIFICATE_NAME_XPATH="azc-br-muted.msportalfx-tooltip-overflow";
			public static final String certificate_key_xpath = "//div[@class='azc-grid-cellContent']";
			public static final String KEYVAULT_KEY_NAME_XPATH="(//div[@class='azc-grid-cellContent'])[1]";
			public static final String KEYVAULT_KEY_TYPE_XPATH="//span[@data-bind='text: keyType()']";
			public static final String KEYVAULT_SECRET_NAME_XPATH="azc-br-muted.msportalfx-tooltip-overflow";
			public static final String KEYVAULT_HOLD_CLICK_XPATH="/html/body/div[1]/div[4]/main/div[4]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]";
			public static final String KEYVAULT_OBJECT_ID_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div[3]/div/div/div[1]";
			public static final String KEYVAULT_KEY_SIZE_XPATH="//span[@data-bind='text: keySizeorCurveName()']";
			public static final String KEYVAULT_VERSION_CLICK_XPATH="(//div[@class='azc-grid-cellContent'])[10]";
			public static final String KEYVAULT_ACCESS_POLICIES_CLICK= "//div[normalize-space()='Access policies']";
			public static final String KEYVAULT_DEPLOYMENT= "(//label[normalize-space()='Azure Virtual Machines for deployment'])[1]";
			public static final String KEYVAULT_DEPLOYMENT_TEMPLETE= "(//label[normalize-space()='Azure Resource Manager for template deployment'])[1]";
			public static final String KEYVAULT_ACCESS_POLICIES_NAME= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div[2]/div[2]/div/div/div/div/div[2]/div/div[2]/div[1]/div/div[2]/div[1]/div[2]/div";
			public static final String KEYVAULT_NETWORKING_CLICK= "//div[normalize-space()='Networking']";
			public static final String KEYVAULT_CONNECTIVITY_METHOD= "//span[.='Allow public access from all networks']";
			public static final String KEYVAULT_ACCESS_CONFIG_CLICK= "//div[normalize-space()='Access configuration']";
			
			
		   //Xpaths for SQL-Server
			
			 
			public static final String SQLSERVER_RESOURCE_GROUP_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			public static final String SQLSERVER_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";                       
			public static final String SQLSERVER_LOCATION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			public static final String SQLSERVER_ADMIN_LOGIN_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[1]/div[3]/div/div/div[1]";
			public static final String SQLSERVER_KEY_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div/table/tbody/tr[3]/td[1]/div";
			public static final String SQLSERVER_DATABASE_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[3]/div/div/div/div[2]/div[2]/div/table/tbody/tr[2]/td[1]/div/div/span[2]";
			public static final String SQLSERVER_NAME_XPATH1="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[4]/div[3]/div/div/div[1]";
			public static final String SQLSERVER_CLICK_HOLD = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div";
			public static final String SQLSERVER_SUBSCRIPTION ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[4]/div[3]/div/div/a";
			public static final String SQLSERVER_AUTH_METHOD ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div[1]/label";
			public static final String SQLSERVER_SET_AZURE_AD_ADMIN ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div[3]/div/div/button";
			public static final String SQLSERVER_ELASTIC_POOL_CLICK ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[2]/div[2]/li[3]/a/div[2]";
			public static final String SQLSERVER_ELASTIC_POOL ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div/table/tbody/tr/td";
			public static final String SQLSERVER_NETWORKING_CLICK ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[4]/div[2]/li[1]/a/div[2]";
			public static final String SQLSERVER_NETWORK_CONNECTIVITY ="/html/body/div[4]/div/div[2]/div[2]/div/div[1]/div[2]/div[1]/div/div/div[2]/div/label/span";
			public static final String SQLSERVER_CONNECTION_POLICY_CLICK ="/html/body/div[4]/div/div[2]/div[1]/button[3]";
			public static final String SQLSERVER_CONNECTION_POLICY ="/html/body/div[4]/div/div[2]/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div/label/span";
			public static final String SQLSERVER_MICROSOFT_DEFENDER_CLOUD_CLICK ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[4]/div[2]/li[2]/a/div[2]";
			public static final String SQLSERVER_MICROSOFT_DEFENDER_FOR_SQL ="(//span[@data-bind='text: azureDefenderStatusText'])[1]";
			public static final String SQLSERVER_INDENTITY_CLICK ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[4]/div[2]/li[4]/a/div[2]";
			public static final String SQLSERVER_INDENTITY ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[1]/div[1]/div[3]/div[2]/div/div/ul/li[1]/span[2]";
			public static final String SQLSERVER_TRANSPERENT_DATA_ENCRYPTION_CLICK ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[4]/div[2]/li[3]/a/div[2]";
			public static final String SQLSERVER_TRANSPERENT_DATA_ENCRYPTION ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[1]/div[2]/div/div/ul/li[1]/span[2]";
			public static final String SQLSERVER_COMPUTE_STORAGE_CLICK ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[3]/div[2]/li[1]/a/div[2]";
			public static final String SQLSERVER_OVERVIEW ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[1]/div[2]/li[1]/a/div[2]";
			public static final String SQLSERVER_COMPUTE_STORAGE="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[1]/div[1]/div[3]/div[2]/div/div[1]/div";
			public static final String SQLSERVER_BSR="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[1]/div[7]/div/div[1]/div[2]/div/div/ul/li[3]/span[2]";
			public static final String SQLSERVER_MAIN_WINDOW_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[3]/div[2]/li[3]/a/div[2]";
			public static final String SQLSERVER_MAIN_WINDOW="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div/div[2]/div[1]/div[3]/div[2]/div/div[1]/div";
			public static final String SQLSERVER_IFRAME ="/html/body/div[1]/div[4]/main/div[3]/div[2]/iframe[1]";
			public static final String SQLSERVER_PROPERTIES_CLICK = "(//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Properties'])[3]";
			public static final String SQLSERVER_COLLATION = "//input[@title='SQL_Latin1_General_CP1_CI_AS']";
			
		  //Xpath of CosmosDB -CDB

			public static final String COSMOSDB_RESOURCE_GROUP_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[3]/div[2]/div[3]/div/div/a";
			public static final String COSMOSDB_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
		    public static final String COSMOSDB_FAILOVER_LOCATION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[4]/div[2]/div[3]/div/div/div[1]";
		    public static final String COSMOSDB_DATABASE_ACCOUNT_OFFER_TYPE_XPATH="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div[1]/div[2]/div[1]/div[4]/div[5]/span/span[4]";
			public static final String COSMOSDB_ACCOUNT_KIND_XPATH="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div[1]/div[2]/div[1]/div[4]/div[13]/span/span[4]";
			public static final String COSMOSDB_TABLE_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div[1]/div/div[3]/div[1]/div/div/div/div/div[2]/div[2]/div/table/tbody/tr/td[1]/div";
			public static final String COSMOSDB_DATABASE_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div[1]/div/div[3]/div[1]/div/div/div/div/div[2]/div[2]/div/table/tbody/tr/td[2]/div";
			
			// Xpaths for Data Lake Gen2 Parameters
			
			public static final String DATALAKEGEN2_OVERVIEW="//div[@class='essentialsNoWrap-90 essentialsValue-95']";
			public static final String DATALAKEGEN2_RESOURCE_GROUP_NAME_XPATH="/html/body/div[4]/div/div/div[2]/div/div[2]/div[1]/div/div[3]/div/div/div/div/div[1]/div/a";
			public static final String DATALAKEGEN2_ACCOUNT_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			public static final String DATALAKEGEN2_LOCATION_XPATH="/html/body/div[4]/div/div/div[2]/div/div[2]/div[1]/div/div[6]/div/div[1]/div";
			public static final String DATALAKEGEN2_PERFORMANCE_XPATH="/html/body/div[4]/div/div/div[2]/div/div[2]/div[2]/div/div[3]/div/div[1]/div";
			public static final String DATALAKEGEN2_REDUNDANCY_XPATH="/html/body/div[4]/div/div/div[2]/div/div[2]/div[2]/div/div[6]/div/div[1]/div";
			public static final String DATALAKEGEN2_ACCOUNT_KIND_XPATH="/html/body/div[4]/div/div/div[2]/div/div[2]/div[2]/div/div[9]/div/div[1]/div";
			public static final String DATALAKEGEN2_ENABLE_HEIRARCHICAL_NAMESPACE_XPATH="/html/body/div[4]/div/div/div[3]/div/div[2]/div/div/div[1]/div/div/div/div/div[1]/div[1]/div/div[2]/div/div[2]/div";
			public static final String DATALAKEGEN2_FILESYSTEM_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div/div[2]/div[2]/div/table/tbody/tr[1]/td[2]/div";
			public static final String DATALAKEGEN2_FILESYSTEM_NAME1_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div/div[2]/div[2]/div/table/tbody/tr[2]/td[2]/div";
			public static final String DATALAKEGEN2_MANAGE_ALERT_RULES_CLICK_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[3]/div/div/div[2]/div/div[2]/div[1]/div/div[1]/div[1]/div[2]/div/a";
			public static final String DATALAKEGEN2_METRIC_ALERT_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[3]/div/div/div[2]/div/div[2]/div[1]/div/div[1]/div[1]/div[2]/div/a"; 
			public static final String DATALAKEGEN2_METRIC_ALERT_DESCRIPTION_XPATH="//div[normalize-space()='Action will be triggered']";
			public static final String DATALAKEGEN2_AGGREGATION_XPATH="(//span[@class='ext-text-with-link'])[9]";
			public static final String DATALAKEGEN2_OPERATOR_XPATH="(//span[@class='ext-text-with-link'])[11]";
			public static final String DATALAKEGEN2_THRESHOLD_XPATH="(//span[@class='ext-text-with-link'])[13]";
			public static final String DATALAKEGEN2_METRIC_NAMESPACE_XPATH="(//span[@class='ext-text-with-link'])[7]";
			public static final String DATALAKEGEN2_METRIC_NAME_XPATH="(//span[@class='ext-text-with-link'])[5]";
			public static final String DATALAKEGEN2_CANCEL_XPATH = "/html/body/div[1]/div[4]/div[2]/section/header/div[2]/div/div[1]/div/button[5]";
			public static final String IFRAME_XPATH = "/html/body/div[1]/div[4]/main/div[3]/div[2]/iframe[1]";
			public static final String DATALAKE_HOLD_CLICK_XPATH="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]";
			public static final String DATALAKEGEN2_CONDTION_CLICK_XPATH="//div[@class='ext-alertsvnext-control-spacing ext-remove-bottom-border fxc-base fxc-gc-hscroll fxc-gc-fixture fxs-vivaresize']/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/div[1]/div/div[2]/div/div/div/div[2]/div/a";
			public static final String ALERT_SIDEBAR_CLICK ="(//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Alerts'])[2]";
			public static final String DATALAKEGEN2_CONTAINER_CLICK_XPATH="(//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Containers'])";
			
			// XPATH of Storage Acc(Logic App)
			
			public static final String STORAGE_ACC_REST_API_OPERATION= "/html/body/div[4]/div/div/div[3]/div/div[2]/div/div/div[1]/div/div/div/div/div[2]/div[1]/div/div[2]/div/div[2]/div/button";
																	
			public static final String STORAGE_ACC_BLOB_PUBLIC_ACCESS= "/html/body/div[4]/div/div/div[3]/div/div[2]/div/div/div[1]/div/div/div/div/div[1]/div[1]/div/div[4]/div/div[2]/div/button";
			public static final String STORAGE_ACC_KEY_ACCESS= "/html/body/div[4]/div/div/div[3]/div/div[2]/div/div/div[1]/div/div/div/div/div[2]/div[1]/div/div[3]/div/div[2]/div/button";
			public static final String STORAGE_ACC_NETWORK_ACCESS= "/html/body/div[4]/div/div/div[3]/div/div[2]/div/div/div[1]/div/div/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/button";
			public static final String STORAGE_ACC_ROUTING_PREFERENCE= "/html/body/div[4]/div/div/div[3]/div/div[2]/div/div/div[1]/div/div/div/div/div[2]/div[2]/div/div[4]/div/div[2]/div/button";
			public static final String STORAGE_ACC_SOFT_DELETE_BLOBS= "/html/body/div[4]/div/div/div[3]/div/div[2]/div/div/div[1]/div/div/div/div/div[1]/div[1]/div/div[5]/div/div[2]/div/button";
			public static final String STORAGE_ACC_SOFT_DELETE_CONTAINERS= "/html/body/div[4]/div/div/div[3]/div/div[2]/div/div/div[1]/div/div/div/div/div[1]/div[1]/div/div[6]/div/div[2]/div/button";
			public static final String STORAGE_ACC_SOFT_DELETE_FILE_SHARE= "/html/body/div[4]/div/div/div[3]/div/div[2]/div/div/div[1]/div/div/div/div/div[1]/div[2]/div/div[4]/div/div[2]/div/button";
			public static final String STORAGE_ACC_ENCRYPTION_CLICK= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[3]/div[2]/li[4]/a/div[2]";
			public static final String STORAGE_ACC_ENABLE_SUPPORT_CUSTOMERS_MANAGED_KEY= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[2]/div/div";
			public static final String STORAGE_ACC_ENCRYPTION_TYPE= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[4]/div[2]/div/div/ul/li[1]/span[2]";
			public static final String STORAGE_ACC_SUBSCRIPTION ="/html/body/div[4]/div/div/div[2]/div/div[2]/div[1]/div/div[12]/div/div/div/div/div[1]/div/a";
			public static final String STORAGE_ACC_NETWORKING_CLICK="/html[1]/body[1]/div[1]/div[4]/main[1]/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[2]/li[1]/a[1]/div[2]";
			public static final String STORAGE_ACC_PRIVATE_ENDPOINT="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[2]/header/div[2]/div/div[1]/h2";
			public static final String STORAGE_ACC_ARROW_DOWN_CLICK="//div[@class='azc-grid-hierarchical-icon-collapsed']//*[name()='svg']//*[name()='use' and contains(@href,'#FxSymbol0')]";
			public static final String STORAGE_ACC_PRIVATE_ENDPOINT_CLICK="//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Private endpoints']";
			public static final String STORAGE_ACC_SUBNET_NAME_CLICK="/html[1]/body[1]/div[1]/div[4]/main[1]/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/div[2]/div[3]/div[5]/div[2]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[2]/td[2]/div[1]/div[1]";
			
			// Logic App Locators
			
			public static final String LOGIC_APP_CLICK ="/html/body/div[1]/div[4]/main/div[3]/div[1]/div/nav/a[4]";
			public static final String LOGIC_APP_RESOURCE_GROUP_NAME="(//a[contains(@class,'msportalfx-text-primary fxc-essentials-value fxs-portal-text fxs-fxclick')])[2]";
			public static final String LOGIC_APP_LOCATION="(//div[@class='fxc-essentials-value fxs-portal-text'])[3]";
			public static final String LOGIC_APP_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			public static final String LOGIC_APP_SERVICE_NAME_SKU_SIZE="(//button[@class='msportalfx-text-primary fxc-essentials-value fxs-portal-text fxs-fxclick'])[2]";
			public static final String LOGIC_APP_WINDOWS_PLAN="(//div[@class='fxc-essentials-value fxs-portal-text'])[6]";
			public static final String KEYVAULT_PROPERTIES_CLICK="(//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Properties'])[2]";
			public static final String LOGIC_APP_PUBLISH_PRICINGTIER="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/ul/li[4]/div[2]/div";
			public static final String KEYVAULT_APPINSIGHT_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[5]/div[2]/li[2]/a/div[2]";
			public static final String LOGIC_APP_APP_INSIGHTS="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div/div/div/span";
			

		    // Xpath of Function App

			public static final String FUNCTION_APP_RESOURCE_GROUP_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			public static final String FUNCTION_APP_LOCATION="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			public static final String FUNCTION_APP_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			public static final String FUNCTION_APP_TAG="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[1]/div/div[3]/div/div[4]/div/div[1]/div/span";
			
			 //Xpath of Web App

			 public static final String WEB_APP_RESOURCE_GROUP_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String WEB_APP_LOCATION="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			 public static final String WEB_APP_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 
			 
			// Xpath for Virtual Machine- VM

			 public static final String VM_RESOURCE_GROUP_NAME="(//a[contains(@class,'msportalfx-text-primary fxc-essentials-value fxs-portal-text fxs-fxclick')])[2]";
			 public static final String VM_LOCATION="(//div[@class='fxc-essentials-value fxs-portal-text'])[4]";
			 public static final String VM_NAME="(//h2[@class='fxs-blade-title-titleText msportalfx-tooltip-overflow'])[3]";
			 public static final String VM_SIZE="(//div[@class='ext-overview-property-value'])[17]";
			 public static final String VM_CACHING="//div[@aria-label='Host caching']";
			 public static final String VM_OS_DISK_NAME="(//div[@class='ext-overview-property-value'])[20]";
			 public static final String VM_NETWORK_INTERFACE_ID="//a[@data-bind='fxclick: nicOpenBlade, text: nicName']";
			 public static final String VM_OS_XPATH="(//div[@class='ext-overview-property-value'])[3]";
			 public static final String VM_DISK_TYPE="(//div[contains(@class,'fxc-gc-text')])[96]";
			 public static final String VM_STORAGE_PUBLISHER="(//div[@class='ext-overview-property-value'])[4]";
			 public static final String VM_STORAGE_OFFER="(//div[@class='ext-overview-property-value'])[5]";
			 public static final String VM_STORAGE_PLAN="(//div[@class='ext-overview-property-value'])[6]";
			 public static final String VM_COMPUTER_NAME="(//div[@class='ext-overview-property-value'])[1]";
			 public static final String VM_HOLD_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]";

			 // Xpath of Virtual Network- VNET

			 public static final String VNET_RESOURCE_GROUP_NAME="/html/body/div[4]/div/div/div[3]/div[1]/div[1]/div/div[2]/div[1]/div/div[3]/div/div/div/div/div[1]/div/a" ;                     
			 public static final String VNET_LOCATION="/html/body/div[4]/div/div/div[3]/div[1]/div[1]/div/div[2]/div[1]/div/div[6]/div/div/div/div/div[1]";
			 public static final String VNET_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String VNET_ADDRESS_SPACE="fxc-essentials-value fxs-portal-text";
			 public static final String VNET_SUBNET_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/div[2]/div/div[2]/div[1]/div/div[1]/div[1]/div[1]/div";
			 public static final String VNET_VM_BASTON_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div[2]/div/div[1]/div/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div";
			 public static final String VNET_SUBNETS_SECURITY_GROUP="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/div[2]/div/div[2]/div[1]/div/div[1]/div[1]/div[6]/div/a";
			 public static final String VNET_SUBNETS_CLICK = "(//div[normalize-space()='Subnets'])[1]";
			 public static final String VNET_BASTION_CLICK = "(//div[normalize-space()='Bastion'])[1]";
			 public static final String VNET_PROPERTIES_CLICK ="(//div[normalize-space()='Properties'])[2]"; 
			 public static final String VNET_OVERVIEW_CLICK ="(//div[normalize-space()='Overview'])[2]";
			 public static final String VNET_IFRAME ="/html/body/div[1]/div[4]/main/div[3]/div[2]/iframe[1]";
			 public static final String VNET_POWERBI_SUBNET= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/div[2]/div/div[2]/div[1]/div/div[2]/div[1]/div[1]/div/a";
			 
			 // Xpaths & Class_name for Synapse-Analytics parameter
			 
			 public static final String SYNAPSEANALYTICS_RESOURCE_GROUP_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String SYNAPSEANALYTICS_WORKSPACE_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String SYNAPSEANALYTICS_LOCATION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			 public static final String SYNAPSEANALYTICS_ACCOUNT_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[4]/div[2]/div[3]/div/div/div[1]";
			 public static final String SYNAPSEANALYTICS_FILE_SYSTEM_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[4]/div[3]/div[3]/div/div/div[1]";
			 public static final String SYNAPSEANALYTICS_ADMIN_USERNAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[4]/div[4]/div[3]/div/div/div[1]";
			 public static final String SYNAPSEANALYTICS_PASSWORD_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[4]/div[6]/div[3]/div/div/div[1]";
			 public static final String SYNAPSEANALYTICS_LOGIN_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[4]/div[5]/div[3]/div/div/button";
			 public static final String SYNAPSEANALYTICS_OBJECT_ID_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[3]/div[7]/div[3]/div/div/div[1]";
			 public static final String SYNAPSEANALYTICS_TAGS_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[3]/div/div[4]/div/div[1]/div";
			 public static final String SYNAPSEANALYTICS_TENANT_ID_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[3]/div[5]/div[3]/div/div/div[1]";
			 public static final String SYNAPSEANALYTICS_SHOW_FIREWALL_SETTING_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[4]/div[1]/div[3]/div/div/button";
			 public static final String SYNAPSEANALYTICS_FIREWALL_RULE_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div[11]/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/div[1]/div";
			 public static final String SYNAPSEANALYTICS_SQL_POOL_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div[2]/div[2]/div/div/div[4]/div/div/div/div[2]/div[2]/div/table/tbody[1]/tr[3]/td[2]/div";
			 public static final String SYNAPSEANALYTICS_MANAGE_ALERT_RULES_CLICK_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[1]/div/ul/li[2]/div/div[2]";
			 public static final String SYNAPSEANALYTICS_METRIC_ALERT_NAME_XPATH="//a[@class='ext-underline-on-hover ext-ellipsisText fxs-fxclick']"; 
			 public static final String SYNAPSEANALYTICS_METRIC_ALERT_DESCRIPTION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[5]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[7]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div/div/div[1]/textarea";
			 public static final String SYNAPSEANALYTICS_AGGREGATION_XPATH="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div/div[3]/div[2]/div/div[11]/div[1]/div[2]/div[2]/div/div[1]/div";
			 public static final String SYNAPSEANALYTICS_OPERATOR_XPATH="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div/div[3]/div[2]/div/div[11]/div[1]/div[1]/div[2]/div/div[1]/div";
			 public static final String SYNAPSEANALYTICS_THRESHOLD_XPATH="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div/div[3]/div[2]/div/div[11]/div[1]/div[3]/div[2]/div/div/div/input";
			 public static final String SYNAPSEANALYTICS_HOLD_CLICK_XPATH="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]";
			 public static final String SYNAPSEANALYTICS_CONDTION_CLICK_XPATH="//div[@class='ext-alertsvnext-control-spacing ext-remove-bottom-border fxc-base fxc-gc-hscroll fxc-gc-fixture fxs-vivaresize']/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/div[1]/div/div[2]/div/div/div/div[2]/div/a";
			 public static final String SYNAPSEANALYTICS_PIPELINE_XPATH="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-app-mainlayout/div[2]/div[2]/app-authoring-main/div/div[2]/div[1]/div[1]/app-authoring-orchestrate/app-authoring-sidebar/div/div[1]/div[2]/app-sidebar-tab/div[3]/app-resource-list/div/div/div[3]/div/div/div/div[3]";
			 public static final String SYNAPSEANALYTICS_TRIGGER_XPATH="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-app-mainlayout/div[2]/div[2]/app-management-main/div/div/app-management-list-view/app-management-triggers/div[3]/app-authoring-triggers-tab/div/div[2]/app-access-watermark/app-watermark/div/div[2]";
			 public static final String SYNAPSEANALYTICS_LINKEDSERVICE_XPATH="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-app-mainlayout/div[2]/div[2]/app-management-main/div/div/app-management-list-view/app-management-linkedservices/div[3]/app-linked-service-tab/div/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr[1]/td[1]/div/div[2]/span";
			 public static final String SYNAPSEANALYTICS_SQL_POOL_NAME_HOLD_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div[2]/div[2]/div/div/div[4]/div/div/div/div[2]/div[2]/div/table/tbody[1]/tr[2]/td[2]/div";
			 public static final String SYNAPSEANALYTICS_FREQUENCY_HOLD_XPATH="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]";
			 public static final String SYNAPSEANALYTICS_BACKTO_SA_OVERVIEW = "/html/body/div[1]/div[4]/main/div[3]/div[1]/div/nav/a[4]";
			 public static final String SYNAPSEANALYTICS_MANAGE_SERVICE = "//button[@class = 'nav-hover']";
			 public static final String SYNAPSEANALYTICS_LINKED_CLICK= "//button[@class= 'nav-hover ng-star-inserted']";
			 public static final String SYNAPSEANALYTICS_TRIGGER_CLICK = "//button[@class= 'nav-hover ng-star-inserted']";
			 public static final String SYNAPSEANALYTICS_WORKSPACE_XPATH = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div[1]/div[2]/div/div/div[2]/div[1]/div[2]/ul/li/a";
			 public static final String SYNAPSEANALYTICS_CONTINUE_XPATH = "/html/body/div[4]/div[2]/div/mat-dialog-container/app-confirm-dialog/div[2]/div/div/button/span[1]";
			 public static final String SYNAPSEANALYTICS_INTEGRATE_XPATH = "//button/div[@class = 'icon svg-a365-orchestrate ng-star-inserted']";
			 public static final String SYNAPSEANALYTICS_EXPAND_ARROW_XPATH = "/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-app-mainlayout/div[2]/div[2]/app-authoring-main/div/div[2]/div[1]/div[1]/app-authoring-orchestrate/app-authoring-sidebar/div/div[1]/div[2]/app-sidebar-tab/div[3]/app-resource-list/div/div/div[1]/div[1]/div";
			 public static final String SYNAPSEANALYTICS_HOLD_CLICK_XPATH1="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[5]/div[1]/div[1]/div[4]";
			 public static final String SYNAPSEANALYTICS_SQL_POOL_SKU_NAME ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div[2]/div[2]/div/div/div[4]/div/div/div/div[2]/div[2]/div/table/tbody[1]/tr[3]/td[4]/div";
			 public static final String SYNAPSEANALYTICS_START_IP_ADDRESS= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div[11]/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/div[2]/div";
			 public static final String SYNAPSEANALYTICS_STOP_IP_ADDRESS= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div[11]/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/div[3]/div";
			 public static final String SYNAPSEANALYTICS_ALERT_SIDEBAR_CLICK ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[5]/div[2]/li[1]/a/div[2]";
			
			 public static final String SYNAPSEANALYTICS_FILESYSTEM_NAME ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[4]/div[3]/div[3]/div/div/div[1]";
			 public static final String SYNAPSEANALYTICS_ENCRYPTION_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[4]/div[2]/li[1]/a/div[2]";
			 public static final String SYNAPSEANALYTICS_DOUBLE_ENCRYPTION="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[5]/div";
			 public static final String SYNAPSEANALYTICS_MANAGED_VIRTUAL_NETWORK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div/div[2]/div[3]/div[6]/div[3]/div/div/div[1]";
			 public static final String SYNAPSEANALYTICS_NETWORKING_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[4]/div[2]/li[2]/a/div[2]";
			 public static final String SYNAPSEANALYTICS_PUBLIC_NETWORK_ACCESS="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div[2]/div[3]/div[2]/div/div/ul/li[1]/span[2]";
			 public static final String SYNAPSEANALYTICS_PRIVATE_ENDPOINT_CONNECTION_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[4]/div[2]/li[4]/a/div[2]";
			 public static final String SYNAPSEANALYTICS_ON_DEMAND_ENDPOINT="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[4]/div/div/div/div[2]/div[2]/div/table/tbody/tr[2]/td[4]/div/div/a";
			 public static final String SYNAPSEANALYTICS_MANAGED_ENDPOINT="(//span[@class='link'])[3]";
			 public static final String SYNAPSEANALYTICS_OVERVIEW_CLICK= "(//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Overview'])[2]";
			 public static final String SYNAPSEANALYTICS_MANAGE_ENDPOINT_CLICK="//div[normalize-space()='Managed private endpoints']";
			 public static final String SYNAPSE_MANAGE_CLICK= "//div[@class='icon svg-management-icon ng-star-inserted']";
			 public static final String SYNAPSE_LUNCH_STUDIO = "//a[normalize-space()='Open']";
			 
			 // Xpath for Azure Databricks Service

			 public static final String DATABRICKS_RESOURCE_GROUP_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[2]/div[3]/div/div/a";
			 public static final String DATABRICKS_LOCATION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			 public static final String DATABRICKS_TAGS_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[3]/div/div[4]/div/div[1]/div/span";
			 public static final String DATABRICKS_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String DATABRICKS_PRICING_TIER_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div[3]/div[3]/div/div/div[1]";
			 public static final String DATABRICKS_LUNCH_WORKSPACE_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[2]/div[1]/a[1]/div";
			 public static final String DATABRICKS_COMPUTE_CLICK_XPATH="//*[@id=\"sidebar\"]/div/div[1]/nav/div[3]/div[1]/div[2]/a[1]/span[1]";
			 public static final String DATABRICKS_CLUSTER_NAME_CLICK_XPATH="//*[@id=\"content\"]/div/div/div/div/div/div/div/div[3]/div/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a";
			 public static final String DATABRICKS_ALL_CLICK_XPATH="/html/body/div[5]/div[3]/div/div[2]/div/div/div/div/div/div/div/div[1]/div[2]/div/label[1]/span[2]";
			 public static final String DATABRICKS_CLUSTER_XPATH="//*[@id=\"content\"]/div/div/div/form/div[1]/div/h2/div[1]";
			 public static final String DATABRICKS_SPARKVERSION_XPATH="//*[@id=\"content\"]/div/div/div/form/div[2]/div/div/div/div[2]/uses-legacy-bootstrap/div/div[1]/div[1]/div[3]/div/span";
			 public static final String DATABRICKS_NODE_TYPE_ID_XPATH="//*[@id=\"content\"]/div/div/div/form/div[2]/div/div/div/div[2]/uses-legacy-bootstrap/div/div[1]/div[1]/div[5]/div/div[1]/div/div/div[1]/div/div/span[1]";
			 public static final String DATABRICKS_AUTOTERMINATION_MINUTES_XPATH="//*[@id=\"content\"]/div/div/div/form/div[2]/div/div/div/div[2]/uses-legacy-bootstrap/div/div[1]/div[1]/ul/li[2]/div/label/span/input";
			 public static final String DATABRICKS_MINIMUM_WORKERS_XPATH="(//span[@class='min-worker fake-static-input'])[1]";
			 public static final String DATABRICKS_MAXIMUM_WORKERS_XPATH="(//span[@class='max-worker fake-static-input'])[1]";

			 //Xpath of Storage Account- S
			 
			 public static final String STORAGEACCOUNT_RESOURCE_GROUP_NAME_XPATH="/html/body/div[4]/div/div/div[2]/div[1]/div[1]/div/div[2]/div[1]/div/div[3]/div/div/div";
			 public static final String STORAGEACCOUNT_ACCOUNT_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String STORAGEACCOUNT_LOCATION_XPATH="//html/body/div[4]/div/div/div[2]/div[1]/div[1]/div/div[2]/div[1]/div/div[6]";
			 public static final String STORAGEACCOUNT_PERFORMANCE_XPATH="/html/body/div[4]/div/div/div[2]/div[1]/div[1]/div/div[2]/div[2]/div/div[3]";
			 public static final String STORAGEACCOUNT_REDUNDANCY_XPATH="/html/body/div[4]/div/div/div[2]/div[1]/div[1]/div/div[2]/div[2]/div/div[6]";
			 public static final String STORAGEACCOUNT_ACCOUNT_KIND_XPATH="/html/body/div[4]/div/div/div[2]/div/div[2]/div[2]/div/div[9]/div/div[1]/div";
			 public static final String STORAGEACCOUNT_MANAGE_ALERT_RULES_CLICK_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[1]/div/ul/li[2]/div/div[2]";
			 public static final String STORAGEACCOUNT_METRIC_ALERT_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[3]/div/div/div[2]/div/div[2]/div[1]/div/div[1]/div[1]/div[2]/a/span[1]"; 
			 public static final String STORAGEACCOUNT_METRIC_ALERT_DESCRIPTION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[5]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[2]/div/div[2]/div[1]/div";
			 public static final String STORAGEACCOUNT_FREQUENCY_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[5]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[6]/div/div[2]/div[1]/div";
			 public static final String STORAGEACCOUNT_WINDOW_SIZE_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[5]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[7]/div/div[2]/div[1]/div";
			 public static final String STORAGEACCOUNT_THRESHOLD_XPATH="(//span[@class='ext-text-with-link'])[13]";			
			 public static final String STORAGEACCOUNT_IFRAME_XPATH = "/html/body/div[1]/div[4]/main/div[3]/div[2]/iframe[1]";
			 public static final String STORAGEACCOUNT_HOLD_CLICK_XPATH="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]";
			 public static final String STORAGEACCOUNT_CONDTION_CLICK_XPATH="//div[@class='ext-alertsvnext-control-spacing ext-remove-bottom-border fxc-base fxc-gc-hscroll fxc-gc-fixture fxs-vivaresize']/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/div[1]/div/div[2]/div/div/div/div[2]/div/a";
			 public static final String STORAGE_ACCOUNT_CONTAINER_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div/div[2]/div[2]/div/table/tbody/tr[2]/td[2]/div";
			 public static final String STORAGE_ACCOUNT_ACCESS_TYPE_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div/div/div[2]/div[2]/div/table/tbody/tr[2]/td[4]/div";
			 public static final String STORAGE_ACCOUNT_CONTAINER_CLICK_XPATH="(//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Containers'])";
			 public static final String STORAGEACCOUNT_METRIC_ALERT_PROPERTIES_XPATH="/html/body/div[4]/div/div/div[1]/div/div/div/div/div[2]/button/span/span/span";
			 public static final String STORAGEACCOUNT_ALERT_IFRAME="/html/body/div[1]/div[4]/div[2]/iframe";
			 
			 public static final String LOG_ANALYTICS_RESOURCE_GROUP_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String LOG_ANALYTICS_LOCATION="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			 public static final String LOG_ANALYTICS_WORKSPACE="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String LOG_ANALYTICS_SKU="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div/div[2]/div[4]/div[3]/div[3]/div/div/div[1]";

			 // Xpath for Virtual Network Gateway- VGN
			 
			 public static final String VNG_RESOURCE_GROUP_NAME="(//a[@class='msportalfx-text-primary fxc-essentials-value fxs-portal-text fxs-fxclick'])[2]";
			 public static final String VNG_LOCATION="(//div[@class='fxc-essentials-value fxs-portal-text'])[3]";
			 public static final String VNG_NAME="(//h2[@class='fxs-blade-title-titleText msportalfx-tooltip-overflow'])[3]";
			 public static final String VNG_SKU="(//div[@class='fxc-essentials-value fxs-portal-text'])[5]";
			 public static final String VNG_TYPE="(//div[@class='fxc-essentials-value fxs-portal-text'])[6]";
			 public static final String VNG_VPN_TYPE="(//div[@class='fxc-essentials-value fxs-portal-text'])[7]";
			 public static final String VNG_VIRTUAL_NETWORK_NAME="(//a[@class='msportalfx-text-primary fxc-essentials-value fxs-portal-text fxs-fxclick'])[4]";
			 public static final String VNG_ACTIVE_MODE="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[5]/div[2]/div/div/ul/li[2]";
			 
			 public static final String VNG_SUBNET="(//div[@class='msportalfx-tooltip-overflow'])[2]";
			 public static final String VNG_CONFIGURE_BGP="false";
			 public static final String VNG_CONFIGURATION_CLICK= "//div[normalize-space()='Configuration']";
			 public static final String VNG_PROPERTIES ="(//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Properties'])[2]";


			 // Xpath of Application Gateways- AG
			 
			 public static final String APPGATEWAY_RESOURCE_GROUP_NAME="(//a[@class='msportalfx-text-primary fxc-essentials-value fxs-portal-text fxs-fxclick'])[2]";                               
			 public static final String APPGATEWAY_LOCATION="(//div[@class='fxc-essentials-value fxs-portal-text'])[3]";
			 public static final String APPGATEWAY_PUBLIC_IP_ID="(//a[@class='msportalfx-text-primary fxc-essentials-value fxs-portal-text fxs-fxclick'])[5]";
			 public static final String APPGATEWAY_VIRTUAL_NETWORK_SUBNET="(//a[@class='msportalfx-text-primary fxc-essentials-value fxs-portal-text fxs-fxclick'])[4]";
			 public static final String APPGATEWAY_NAME="(//h2[@class='fxs-blade-title-titleText msportalfx-tooltip-overflow'])[3]";
			 public static final String APPGATEWAY_IP_CONFIGURATION_NAME="(//div[@class='azc-grid-cellContent'])[3]";
			 public static final String APPGATEWAY_FRONTEND_IP_CONFIG_CLICK="//div[normalize-space()='Frontend IP configurations']";
			 public static final String APPGATEWAY_SKU = "//div[@class='azc-formControl azc-input fxc-dropdown-open msportalfx-tooltip-overflow azc-validation-border fxc-dropdown-input']";
			 public static final String APPGATEWAY_CONFIGURATION_CLICK="//div[normalize-space()='Configuration']";
			
			 // Xpath of Network Interface
			 
			 public static final String NETWORK_INTERFACE_RESOURCE_GROUP_NAME="/html/body/div[4]/div/div/div/div[1]/div/div[2]/div/div/div[2]/div[1]/div/div[3]/div/div/div/div/div[1]/div/a";
			 public static final String NETWORK_INTERFACE_LOCATION="/html/body/div[4]/div/div/div/div[1]/div/div[2]/div/div/div[2]/div[1]/div/div[6]/div/div/div/div/div[1]/div";
			 public static final String NETWORK_INTERFACE_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String NETWORK_INTERFACE_IP_CONFIGURATION_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[10]/div/div/div/div[2]/div[2]/div/table/tbody/tr/td[1]/div";
			 public static final String NETWORK_INTERFACE_PRIVATE_IP_ADDRESS_ALLOCATION="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[11]/div[2]/div/div/ul/li[1]";
			 public static final String NETWORK_INTERFACE_SUBNET_ID="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[8]/div[2]/div/div/a";
			 public static final String NETWORK_INTERFACE_NETWORK_SECURITY_GROUP="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div/div[1]/div";
			 public static final String NETWORK_INTERFACE_NAVIGATE_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[1]/div/nav/a[4]";
			 public static final String NETWORK_INTERFACE_IP_CONFIGURATION_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[2]/div[2]/li[1]/a/div[2]";
			 public static final String NETWORK_INTERFACE_IFRAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/iframe[1]";
			 // Xpath for Stream Analytics
			 
			 public static final String STREAM_ANALYTICS_RESOURCE_GROUP="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String STREAM_ANALYTICS_LOCATION="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			 public static final String STREAM_ANALYTICS_JOB_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String STREAM_ANALYTICS_JAVASCRIPT_UDP="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String STREAM_ANALYTICS_COMPATIBILITY_LEVEL="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div[1]/div";
			 public static final String STREAM_ANALYTICS_DATA_LOCALE="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div[1]/div";
			 public static final String STREAM_ANALYTICS_EVENTS_LATE_ARRIVALS_MAX_DELAY_IN_SECONDS="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[6]/div[2]/div/div[1]/div";
			 public static final String STREAM_ANALYTICS_EVENTS_OUT_OF_ORDER_MAX_DELAY_IN_SECONDS_="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[11]/div[2]/div/div[1]/div";
			 public static final String STREAM_ANALYTICS_EVENTS_OUT_OF_ORDER_POLICY="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[14]/div[2]/div/div/ul/li[1]";
			 public static final String STREAM_ANALYTICS_OUTPUT_ERROR_POLICY="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/ul/li[1]";
			 public static final String STREAM_ANALYTICS_STREAMING_UNITS="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/div/div[2]";
			 public static final String STREAM_ANALYTICS_EVENTHUB_NAMESPACE_NAME="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div[2]/div/div[4]/div[2]/div/div";
			 public static final String STREAM_ANALYTICS_EVENTHUB_NAME="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div[2]/div/div[6]";
			 public static final String STREAM_ANALYTICS_EVENTHUB_CONSUMER_GROUP_NAME="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div[2]/div/div[8]/div[2]/div/div/div";
			 public static final String STREAM_ANALYTICS_STREAM_INPUT_EVENTHUB_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[1]/div[1]/div/a";
			 public static final String STREAM_ANALYTICS_SHARED_ACCESS_POLICY_NAME="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div[2]/div/div[9]/div[2]/div/div[3]/div[2]/div/div/div";
			 public static final String STREAM_ANALYTICS_INPUT_IOTHUB="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[2]/div[1]/div[2]/div[1]/div[1]/div/a";
			 public static final String STREAM_ANALYTICS_IOTHUB="/html/body/div[1]/div[4]/div[2]/section/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div[2]/div/div[4]/div[2]/div/div/div/input";
			 public static final String STREAM_ANALYTICS_OUTPUT_EVENTHUB_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[2]/div[1]/div[4]/div[1]/div[1]/div/a";

			// Xpath for Public Ip
			 
			 public static final String PUBLIC_IP_RESOURCE_GROUP_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String PUBLIC_IP_LOCATION="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[2]/div[3]/div/div/div[1]";
			 public static final String PUBLIC_IP_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String PUBLIC_IP_ALLOCATION_METHOD = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[3]/div[1]/div[2]/div/div/ul/li[1]/span[2]";
			 public static final String PUBLIC_IP_SKU = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[4]/div[1]/div[3]/div/div/div[1]";
			 public static final String PUBLIC_IP_VM_NAME = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[4]/div[5]/div[3]/div/div/button";
			 public static final String PUBLIC_IP_CONFIGURATION_CLICK = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[2]/div[2]/li[1]/a/div[2]";

			// Xpath for Private Endpoint
			 
			 public static final String PRIVATE_ENDPOINT_RESOURCE_GROUP_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String PRIVATE_ENDPOINT_LOCATION="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[2]/div[3]/div/div/div[1]";
			 public static final String PRIVATE_ENDPOINT_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String PRIVATE_ENDPOINT_METHOD = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[3]/div[1]/div[2]/div/div/ul/li[1]/span[2]";
			 public static final String PRIVATE_ENDPOINT_SKU = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[4]/div[1]/div[3]/div/div/div[1]";
			 public static final String PRIVATE_ENDPOINT_ = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[4]/div[5]/div[3]/div/div/button";
			 public static final String PRIVATE_ENDPOINT_CLICK = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[2]/div[2]/li[1]/a/div[2]";
			 
			 // Xpaths for Azure Data Factory
			 
			 public static final String ADF_LUNCH_STUDIO ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/a[2]/div[1]";
			 public static final String ADF_MANAGE_CLICK ="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-app-mainlayout/div[2]/div[1]/div/div/div/div[6]/button/div";
			 public static final String ADF_TRIGGER_CLICK ="//div[normalize-space()='Triggers']";
			 public static final String ADF_SCHEDULE_TRIGGER_NAME= "/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-app-mainlayout/div[2]/div[2]/app-management-main/div/div/app-management-list-view/app-management-triggers/div[3]/app-authoring-triggers-tab/div/div[2]/p-table/div/div[1]/table/tbody/tr[1]/td[1]/div/div/span";
			 public static final String ADF_RESOURCE_GROUP_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String ADF_NAME_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String ADF_LOCATION_XPATH="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			 public static final String ADF_SUBSCRIPTION ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[4]/div[3]/div/div/a";
			 public static final String ADF_BREADCRUM_CLICK = "/html/body/div[1]/div[4]/main/div[3]/div[1]/div/nav/a[4]";
			 public static final String ADF_ALERT_SIDEBAR_CLICK ="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[4]/div[2]/li[1]/a/div[2]";
			 public static final String ADF_OVERVIEW_CLICK="(//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Overview'])[2]";
			 // Xpath of App Service Plan- ASP

			 public static final String APP_SERVICE_PLAN_NAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String APP_SERVICE_PLAN_TAG="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[3]/div/div[4]/div/div[1]/div";
			 public static final String APP_SERVICE_PLAN_OS="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[4]/div[3]/div[3]/div/div/div[1]";
			 public static final String APP_SERVICE_PLAN_SKU="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/ul/li[3]/div[2]";
			 public static final String APP_SERVICE_PLAN_SIZE="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[4]/div[1]/div[3]/div/div/div[1]";
			 public static final String APP_SERVICE_PLAN_RESOURCEGROUPNAME="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String APP_SERVICE_PLAN_LOCATION="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[1]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			 public static final String APP_SERVICE_PLAN_APP_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[2]/div[2]/li[1]/a/div[2]";
			 public static final String APP_SERVICE_PLAN_APP_NAME= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div/table/tbody/tr[1]/td[2]";
			 
			 // Xpath of Synapse Private Link Hub
			 
			 public static final String SYNAPSE_PRIVATE_LINK_HUB_RG_NAME = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String SYNAPSE_PRIVATE_LINK_HUB_NAME = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String SYNAPSE_PRIVATE_LINK_HUB_LOCATION = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[3]/div[3]/div/div/div[1]";
			 public static final String SYNAPSE_PRIVATE_LINK_HUB_SUBSCRITION = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[4]/div[3]/div/div/a";
			 public static final String SYNAPSE_PRIVATE_LINK_HUB_PRIVATE_ENDPOINT_CONNECTIONS_TAB_CLICK = "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[3]/div[2]/li/a/div[2]";
			 public static final String SYNAPSE_PRIVATE_LINK_HUB_PRIVATE_ENDPOINT_CONNECTIONS_NAME = "//a[@class='fxs-fxclick']";

			 // Xpath of Synapse Dedicated SQL Pool
			 
			 public static final String DEDICATED_SQL_POOL_NAME = "(//h2[@class='fxs-blade-title-titleText msportalfx-tooltip-overflow'])[3]";
			 public static final String DEDICATED_SQL_POOL_PERFORMANCE_LEVEL="(//div[@class='fxc-essentials-value fxs-portal-text'])[6]";
			 public static final String DEDICATED_SQL_POOL_COLLATION="//input[@title='SQL_Latin1_General_CP1_CI_AS']";
			 public static final String DEDICATED_SQL_POOL_PROPERTIES_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[2]/div[2]/li[5]/a/div[2]";
			 public static final String DEDICATED_SQL_POOL_OVERVIEW_CLICK="(//div[@class='ext-fxc-menu-listView-item'][normalize-space()='Overview'])[2]";
			 public static final String DEDICATED_SQL_POOL_WORKSPACE_CLICK="(//button[@class='msportalfx-text-primary fxc-essentials-value fxs-portal-text fxs-fxclick'])[2]";
			 public static final String DEDICATED_SQL_POOL_PRIVATE_ENDPOINT_CONNECTION_CLICK="//div[normalize-space()='Private endpoint connections']";
			 public static final String DEDICATED_SQL_POOL_PRIVATE_ENDPOINT_NAME="(//a[@class='fxs-fxclick'])[1]";
			 
			 // Xpath for Synapse Spark Pool
			 
			 public static final String SPARK_POOL_RESOURCE_GROUP_NAME= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div/a";
			 public static final String SPARK_POOL_NAME= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/header/div[2]/div/div[1]/h2";
			 public static final String SPARK_POOL_PROPERTIES_CLICK= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[2]/div[2]/li[3]/a/div[2]";
			 public static final String SPARK_POOL_NODE_SIZE= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[5]/div[2]/div/div/div[2]";
			 public static final String SPARK_POOL_NODE_SIZE_FAMILY= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[10]/div[2]/div/div/div[2]";
			 public static final String SPARK_POOL_INTELLIGENT_CACHE_SIZE= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[8]/div[2]/div/div/div[2]";
			 public static final String SPARK_POOL_NO_OF_NODES= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[11]/div[2]/div/div/div[2]";
			 public static final String SPARK_POOL_AUTOMATIC_PAUSING= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[12]/div[2]/div/div/div[2]";
			 public static final String SPARK_POOL_OVERVIEW_CLICK= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[1]/div[2]/li[1]/a/div[2]";
			 public static final String SPARK_POOL_WORKSPACE_CLICK= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[3]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div[2]/div[4]/div/div[3]/div/div/button";
			 public static final String SPARK_POOL_PRIVATE_ENDPOINT= "/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[2]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div/div[4]/div/div/div/div[2]/div[2]/div/table/tbody/tr[3]/td[4]/div/div/a";
			 public static final String SPARK_POOL_PRIVATE_ENDPOINT_CONNECTION_CLICK="/html/body/div[1]/div[4]/main/div[3]/div[2]/section[4]/div[1]/div[1]/div[4]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/div/div[1]/div[4]/div[2]/li[4]/a/div[2]";
}
