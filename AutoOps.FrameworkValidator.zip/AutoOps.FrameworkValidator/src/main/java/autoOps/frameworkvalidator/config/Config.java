package autoOps.frameworkvalidator.config;

public class Config {

	// webpage url
	public static final String baseUrl="https://portal.azure.com";
	
	
	// Relative path of Excel Sheet folder & Screenshot folder
	//public static final String Excel_file_path1="screenshots\\jsondemo.xlsx";
	public static final String Excel_file_path1="screenshots\\AutoOpsTesting(3).xlsx";
	public static final String Screenshot_folder_path= "screenshots\\";
	public static final String Text_folder_path= "Excels\\startup.txt";
	
	
	/** ExtentReports */
	public static final String Reports_Extent_Location = ".//extent_reports";
	public static final String Reports_Extent_Folder = ".//extent_reports//";
}
