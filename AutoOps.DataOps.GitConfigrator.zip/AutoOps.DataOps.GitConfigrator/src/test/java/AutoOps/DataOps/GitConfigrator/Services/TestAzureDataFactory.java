package AutoOps.DataOps.GitConfigrator.Services;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
//import java.sql.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import AutoOps.DataOps.GitConfigrator.Json_Deserializer.Body;
import AutoOps.DataOps.GitConfigrator.Json_Deserializer.RequestComponent;
import AutoOps.DataOps.GitConfigrator.Json_Deserializer.Root;
import AutoOps.DataOps.GitConfigrator.Json_Deserializer.ServiceProperties;
import flexjson.JSONDeserializer;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.asserts.SoftAssert;

import org.openqa.selenium.Keys;

@Test
public class TestAzureDataFactory {

	public WebDriver driver= null;	
	
	String sheetname="ADF";	
	String DevOps_Project_Name="";
	String Repos_Name="";
	String Collaboration_Branch="";
	String Publish_Branch="";
	String Service_Name="";
	String Root_Folder="";
	String Git_Type="";
	String Git_Type_Click="";
	String Azure_Active_Directory="";
	String Azure_DevOps_Organization_Name="";
	String Azure_Active_Directory_Xpath="";
	String Azure_DevOps_Organization_Name_Xpath="";
	
	final static Logger logger = Logger.getLogger(TestAzureDataFactory.class);
	
  public void git_configrator() throws Throwable {
		      	  	  	  		
		PropertyConfigurator.configure("log4j.properties.txt");
			
		try  
			{
				// calling  Deserializer 
				deserializer();
	             	     		
	     		// Providing Key vault url.
	         	String keyVaultUri = "https://tcsazaokvdev.vault.azure.net";
	         		            
	             SecretClient secretClient = new SecretClientBuilder()
	                     .vaultUrl(keyVaultUri)
	                     .credential(new DefaultAzureCredentialBuilder().build())
	                     .buildClient();
	             
	             //storing username & password in keyvault secrets variables.	             
	             String username = "uname";
	             String passwor = "pwd";	           
	             String retrieved_username = secretClient.getSecret(username).getValue();
	             String retrieved_password = secretClient.getSecret(passwor).getValue();
	             String my_username= retrieved_username;
	             String my_password= retrieved_password;
	          
	             SoftAssert softAssert = new SoftAssert();
	         	 // Launching chrome browser using webdriver manager.
	         	 WebDriverManager.chromedriver().setup();
	     		 driver = new ChromeDriver();
	     		    	 			 
	     		 driver.manage().window().maximize();
	     		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
	     			 
	     		 driver.get(AutoOps.DataOps.GitConfigrator.Configurations.Config.base_url);
	     		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));
	     			 				
	     		 // It will fill the username using sendkeys method & click on next button.
	     		 driver.findElement(By.id("i0116")).sendKeys(my_username);
	     		 Thread.sleep(4000);
	     		 driver.findElement(By.id("idSIButton9")).click();
	     		 Thread.sleep(4000);
	     		
	     		// It will fill the password using sendkeys method & click on next button.
	     		 driver.findElement(By.id("i0118")).sendKeys(my_password);
	     		 Thread.sleep(4000);
	     		 driver.findElement(By.id("idSIButton9")).click();
	     		 Thread.sleep(5000);
	     		
	     		 // Click on yes pop up.
	     		 driver.findElement(By.id("idSIButton9")).click();
	     		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	     		 Thread.sleep(5000);
	     		 logger.info("Login Successfully using Azure Keyvault Secrets");
				
	     		 // Click on Search Bar on Home Page.
				 WebElement HomePage_SerachBox = driver.findElement(By.id(AutoOps.DataOps.GitConfigrator.Configurations.Constants.HOME_PAGE_SERACH_BAR));
				 HomePage_SerachBox.click();
				 Thread.sleep(4000);
				
				 // Filling text in homepage Search box.				 
				 HomePage_SerachBox.sendKeys(Service_Name);
				 Thread.sleep(8000);
				
				 // Clicked Enter on Serached Service.
				 HomePage_SerachBox.sendKeys(Keys.ENTER);
				 Thread.sleep(4000);
				 logger.info("Reached particular service");
					
				 WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(6000));
							
				 		// Click on Open ADF Studio link.
						    driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_STUDIO_BUTTON_CLICK)).click();
						    Thread.sleep(15000);
						    logger.info("Reached ADF Studio");   
						
						    Set<String> windowhandles = driver.getWindowHandles();
					        Iterator<String> iterator =windowhandles.iterator();
					        String parentwindow = iterator.next();
					        String childwindow = iterator.next();
					        
					    //  Click on Manage sidebar button.  
					        driver.switchTo().window(childwindow);
					        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_MANAGE_CLICK))).click();
					        Thread.sleep(4000);
					        logger.info("Clicked on Manage sidebar button"); 
					        
					  // Click on Git Configuration sidebar button.      
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_GIT_CONFIGURATION_CLICK)).click();
					        Thread.sleep(4000);
					        logger.info("Clicked on Git Configuration sidebar button");
					        
					  // Click on Configure button.      
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_STUDIO_CONFIGURE_CLICK)).click();
					        Thread.sleep(4000);
					        logger.info("Clicked on Configure button");
					        
					  // Click on Repository Type Dropdown.      
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.REPOSITORY_TYPE_DROPDOWN)).click();
					        Thread.sleep(3000);
					        
					  // Click on Selected Git Type.      
					        driver.findElement(By.xpath(Git_Type_Click)).click();
					        Thread.sleep(4000);	
					        logger.info("Selected Git Type from dropdown");
					        
					  // Click on Azure Active Directory Dropdown.		
					  		driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.AZURE_ACTIVE_DIRECTORY_DROPDOWN)).click();
					        Thread.sleep(4000);
					       
					  // Click on Azure Active Directory.      
					        driver.findElement(By.xpath(Azure_Active_Directory_Xpath)).click();
					        Thread.sleep(4000);
					        logger.info("Selected Azure Active Directory from dropdown");
					        
					  // Click on Continue Button.      					       					        
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_CONTINUE_BUTTON_CLICK)).click();
					        Thread.sleep(5000);
					        logger.info("Click on Continue button");
					        
					        
					  // Click on Organization dropdown.      					       					        
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_DEVOPS_ORGANIZATION_DROPDOWN_CLICK)).click();
					        Thread.sleep(4000); 
					        
					  // Click on Organization Name.      
					        driver.findElement(By.xpath(Azure_DevOps_Organization_Name_Xpath)).click();
					        Thread.sleep(4000);						        
					        logger.info("Selected DevOps Organization Name from dropdown");
					        
					  // Click on project name dropdown & search project name using SendKeys.      
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_PROJECT_NAME_DROPDOWN)).click();
					        Thread.sleep(5000); 
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_PROJECT_NAME__FILTER_SEARCHBAR)).sendKeys(DevOps_Project_Name);					        
					  		Thread.sleep(4000);
					  		driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_PROJECT_NAME__CLICK)).click();
					        Thread.sleep(4000);
					        logger.info("Selected Project Name using filter search");
					        
					 //  Click on Repo name dropdown & search Repo name using SendKeys.     
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_REPO_NAME_DROPDOWN)).click();
					        Thread.sleep(5000); 
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_REPO_NAME_FILTER_SEARCHBAR)).sendKeys(Repos_Name);					        
					  		Thread.sleep(4000);
					  		driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_SEARCHED_CLICK)).click();
					        Thread.sleep(4000);
					        logger.info("Selected Repo Name using filter search");
					        
					 // Click on Collobration Branch dropdown & Collobration Branch Name search  using SendKeys.       
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.COLLOBRATION_BRANCH_DROPDOWN)).click();
					        Thread.sleep(5000); 
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.COLLOBRATION_BRANCH_FILTER_SEARCHBAR)).sendKeys(Collaboration_Branch);					        
					  		Thread.sleep(4000);
					  		//wait.until(ExpectedConditions.elementToBeClickable(By.id(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_SEARCHED_CLICK))).click();
					  		driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_SEARCHED_CLICK)).click();
					        Thread.sleep(4000);
					        logger.info("Selected Collobration branch using filter search");
					        
					 // Click on Publish Branch dropdown & search Publish Branch  name using SendKeys.       
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.PUBLISH_BRANCH_DROPDOWN)).click();
					        Thread.sleep(5000); 
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.PUBLISH_BRANCH_FILTER_SEARCHBAR)).sendKeys(Publish_Branch);					        
					  		Thread.sleep(4000);
					  		driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ADF_SEARCHED_CLICK)).click();
					        Thread.sleep(4000);
					        logger.info("Selected publish branch using filter search");
					        
					// Filling Root folder name using SendKeys.        
					        driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.ROOT_FOLDER_SEARCHBAR)).sendKeys(Root_Folder);					        
					  		Thread.sleep(4000);
					  		 logger.info("Filled Root folder path");
					  		
					// 	Click on Apply button.	
					  		driver.findElement(By.xpath(AutoOps.DataOps.GitConfigrator.Configurations.Constants.APPLY_BUTTON_CLICK)).click();				        
					  		Thread.sleep(6000);
					  		 logger.info("Clicked on Apply button");
					
					  		 
				   // Assert Condition to check git is configured or not.				  		 
					  	String expected = driver.findElement(By.xpath("//div[contains(text(),'Disconnect')]")).getText();					  	
					    String actual = "Disconnect";	
					    softAssert.assertEquals(actual, expected);
					  
					// Closing studio page.				  		
					  		driver.close();
							driver.switchTo().window(parentwindow);		
					// Closing browser.
							driver.close();  
						logger.info("Closed browser");
				       	                
 }    
 	 catch (Exception ex) {
	  	ex.printStackTrace();
	  	logger.error("error is", ex);
	 }    
  	        
}
	
	private void deserializer() {
		
		 ObjectMapper mapper = new ObjectMapper();
     	  
	  	    try {
	  	    	 	      	    	 	  	    
				  mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				  
	 	    	  String f= new String(Files.readAllBytes(Paths.get(AutoOps.DataOps.GitConfigrator.Configurations.Config.Json_file_path)));
	 	    	  	 	   	 
	 	    	  JSONDeserializer<Root> deserializer = new JSONDeserializer<Root>();
	 	    	  Root root = deserializer.deserialize(f, Root.class);
	 	    	
	 	    	  Body body = root.getBody();
	 	    	 	 	    		 	    	 	
	 	    	  for(RequestComponent requestComponents : body.getRequestComponents()) {
	 	    		 
	 	    		  String service_type = requestComponents.getServiceType();
	 	    		  
	 	    		  if(service_type.equalsIgnoreCase(sheetname)) {
	 	    			 
	 	    			  // Creating Object for Service Properties & fetching serviceProperties from requestComponent.
	 	    			  ServiceProperties  serviceProperties = new ServiceProperties();
	 	    		      serviceProperties = requestComponents.getServiceProperties();

		 	    		  Service_Name = serviceProperties.getServiceName();		 	    		  
		 	    		  DevOps_Project_Name= serviceProperties.getDevOpsProjectName();
		 	    		  Repos_Name=serviceProperties.getReposName();
		 	    		  Collaboration_Branch=serviceProperties.getCollaborationBranch();
		 	    		  Publish_Branch=serviceProperties.getPublishBranch();		 	    		 
		 	    		  Root_Folder=serviceProperties.getRootFolder();
		 	    		  Git_Type=serviceProperties.getGitType();
		 	    		  Azure_Active_Directory=serviceProperties.getAzureActiveDirectory();		 	    		  
		 	    		  Azure_DevOps_Organization_Name=serviceProperties.getDevOpsOrganizationName();
		 	    		  
		 	    		  // Creating Git_Type, Azure_Active_Directory, Azure_DevOps_Organization_Name Xpaths in real time.
		 	    		  String  Partial_Xpath="//div[@aria-label='']";
		 	    		  Git_Type_Click = Partial_Xpath.substring(0, 19) + Git_Type + Partial_Xpath.substring(19);
		 	    		  Azure_Active_Directory_Xpath = Partial_Xpath.substring(0, 19) + Azure_Active_Directory + Partial_Xpath.substring(19);
		 	    		 Azure_DevOps_Organization_Name_Xpath = Partial_Xpath.substring(0, 19) + Azure_DevOps_Organization_Name + Partial_Xpath.substring(19);
		 	    				 	    		
	 	    		 	 	    		  
	 	    		  }	
	 	    		  
	 	    		  else {
	 	    			 System.out.println("Not Found");
	 	    		  } 
	 	    	  }			
		}
	  	    
	  	  catch (StreamReadException e) {
		        e.printStackTrace();
		        logger.error("error is", e);
		    } catch (DatabindException e) {
		        e.printStackTrace();
		        logger.error("error is", e);
		    } catch (IOException e) {
		        e.printStackTrace();
		        logger.error("error is", e);
		    } 
	}
	 		 
}