package AutoOps.DataOps.GitConfigrator.Json_Deserializer;

import java.util.HashMap;
import java.util.Map;

public class Root {
    private Body body;
    public Body getBody() {
        return body;
    }
    public void setBody(Body body) {
        this.body = body;
    }
}
