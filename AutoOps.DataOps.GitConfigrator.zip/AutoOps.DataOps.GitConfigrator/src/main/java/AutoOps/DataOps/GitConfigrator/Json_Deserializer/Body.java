package AutoOps.DataOps.GitConfigrator.Json_Deserializer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Body {
    private String requestUID;
    private List<RequestComponent> requestComponents = new ArrayList<RequestComponent>();
    public String getRequestUID() {
        return requestUID;
    }
    public void setRequestUID(String requestUID) {
        this.requestUID = requestUID;
    }
    public List<RequestComponent> getRequestComponents() {
        return requestComponents;
    }
    public void setRequestComponents(List<RequestComponent> requestComponents) {
        this.requestComponents = requestComponents;
    }
}
