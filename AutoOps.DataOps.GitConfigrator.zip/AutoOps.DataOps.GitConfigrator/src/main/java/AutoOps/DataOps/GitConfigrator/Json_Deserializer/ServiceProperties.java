package AutoOps.DataOps.GitConfigrator.Json_Deserializer;

import java.util.HashMap;
import java.util.Map;
public class ServiceProperties {
    private String serviceID;
    private String serviceName;
    private String gitType;
    private String azureActiveDirectory;
    private String devOpsOrganizationName;
    private String devOpsProjectName;
    private String reposName;
    private String collaborationBranch;
    private String publishBranch;
    private String rootFolder;
    
    public String getServiceID() {
        return serviceID;
    }
    public void setServiceID(String serviceID) {
        this.serviceID = serviceID;
    }
    public String getServiceName() {
        return serviceName;
    }
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
    public String getGitType() {
        return gitType;
    }
    public void setGitType(String gitType) {
        this.gitType = gitType;
    }
    public String getAzureActiveDirectory() {
        return azureActiveDirectory;
    }
    public void setAzureActiveDirectory(String azureActiveDirectory) {
        this.azureActiveDirectory = azureActiveDirectory;
    }
    public String getDevOpsOrganizationName() {
        return devOpsOrganizationName;
    }
    public void setDevOpsOrganizationName(String devOpsOrganizationName) {
        this.devOpsOrganizationName = devOpsOrganizationName;
    }
    public String getDevOpsProjectName() {
        return devOpsProjectName;
    }
    public void setDevOpsProjectName(String devOpsProjectName) {
        this.devOpsProjectName = devOpsProjectName;
    }
    public String getReposName() {
        return reposName;
    }
    public void setReposName(String reposName) {
        this.reposName = reposName;
    }
    public String getCollaborationBranch() {
        return collaborationBranch;
    }
    public void setCollaborationBranch(String collaborationBranch) {
        this.collaborationBranch = collaborationBranch;
    }
    public String getPublishBranch() {
        return publishBranch;
    }
    public void setPublishBranch(String publishBranch) {
        this.publishBranch = publishBranch;
    }
    public String getRootFolder() {
        return rootFolder;
    }
    public void setRootFolder(String rootFolder) {
        this.rootFolder = rootFolder;
    }
}
