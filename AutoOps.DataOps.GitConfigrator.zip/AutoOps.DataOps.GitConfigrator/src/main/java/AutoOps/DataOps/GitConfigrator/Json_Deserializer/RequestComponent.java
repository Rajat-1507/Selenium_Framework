package AutoOps.DataOps.GitConfigrator.Json_Deserializer;

import java.util.HashMap;
import java.util.Map;

public class RequestComponent {
    private String serviceType;
    private ServiceProperties serviceProperties;
    public String getServiceType() {
        return serviceType;
    }
    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }
    public ServiceProperties getServiceProperties() {
        return serviceProperties;
    }
    public void setServiceProperties(ServiceProperties serviceProperties) {
        this.serviceProperties = serviceProperties;
    }
}