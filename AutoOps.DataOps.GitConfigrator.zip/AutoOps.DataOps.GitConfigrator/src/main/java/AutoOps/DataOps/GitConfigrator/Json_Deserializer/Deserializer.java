package AutoOps.DataOps.GitConfigrator.Json_Deserializer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import flexjson.JSONDeserializer;

public class Deserializer {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		 ObjectMapper mapper = new ObjectMapper();
    	  
	  	    // Converting Employee JSON string to Employee class object
		 try {  	    
	  	    	  	      	    	 
	  	    	String Service_Name="";
				 
				  mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		  	    	
	 	    	  String f= new String(Files.readAllBytes(Paths.get("C:\\Users\\AutoOpsVM1\\eclipse-workspace\\AutoOps.DataOps.GitConfigrator\\Excel\\GitSetup.json")));
	 	    	  
	 	    	 // JsonNode jsonNode = mapper.readTree(f);
	 	    	 // String service_type = jsonNode.get("serviceType").asText();
	 	    	// System.out.println(service_type);
	 	    	  JSONDeserializer<Root> deserializer = new JSONDeserializer<Root>();
	 	    	  Root root = deserializer.deserialize(f, Root.class);
	 	    	  
	 	    	  Body body = root.getBody();
	 	    	 
	 	    	  String request_uid = body.getRequestUID();
	 	    	 
	 	    	  for(RequestComponent requestcomponents : body.getRequestComponents()) {
	 	    		  
	 	    		  String service_type = requestcomponents.getServiceType();
	 	    		  if(service_type == "ADF") {
	 	    		
	 	    		  ServiceProperties serviceproperties = requestcomponents.getServiceProperties();
	 	    		  Service_Name = serviceproperties.getServiceName();
	 	    		  System.out.println(Service_Name);
	 	    		  }		
	 	    	  }			  	    				  	    				  	    		  		  	    	  	  	 	  	    	  
		 }
		 
		  catch (StreamReadException e) {
		        e.printStackTrace();
		    } catch (DatabindException e) {
		        e.printStackTrace();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }   
		
	}

}
