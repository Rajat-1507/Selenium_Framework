package AutoOps.DataOps.GitConfigrator.Configurations;

public class Config {

	public static final String base_url="https://portal.azure.com/";
	
	public static final String my_username ="autoopstestuser@tcsteg.onmicrosoft.com";
	public static final String my_password="AutoOps@123";
	public static final String sql_database_url="jdbc:sqlserver://dataopsserver03.database.windows.net:1433;database=DataopsDB;user=dataopsserver03@dataopsserver03;password={your_password_here};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";
	
	public static final String Json_file_path="JsonFile\\GitConfigurator.json";

}
