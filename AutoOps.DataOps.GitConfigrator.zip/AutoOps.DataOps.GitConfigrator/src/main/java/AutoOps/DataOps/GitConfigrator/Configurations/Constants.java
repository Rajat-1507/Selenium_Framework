package AutoOps.DataOps.GitConfigrator.Configurations;

public class Constants {

	// Xpath, Id, Link text.
			
		public static final String USERNAME_TEXTBOX_XPATH="i0116";
		public static final String PASSWORD_TEXTBOX_XPATH="i0118";
		public static final String YES_CONTINUE_POPUP_XPATH="idSIButton9";
		public static final String HOME_PAGE_SERACH_BAR="_weave_e_9";
		public static final String ADF_STUDIO_BUTTON_CLICK="(//p[@class='ext-launch-link'])[1]";
		public static final String ADF_MANAGE_CLICK="/html/body/app-root/mat-sidenav-container/mat-sidenav-content/app-app-mainlayout/div[2]/div[1]/div/div/div/div[6]/button/div";
		public static final String ADF_GIT_CONFIGURATION_CLICK="//div[normalize-space()='Git configuration']";
		public static final String ADF_STUDIO_CONFIGURE_CLICK="//div[normalize-space()='Configure']";
		public static final String REPOSITORY_TYPE_DROPDOWN="(//*[contains(@class,'inputIconRight madrid-icon icon-size-12 icon-chevron-down')])[2]";
		public static final String REPOSITORY_TYPE_CLICK="//div[@aria-label='Azure DevOps Git']";
		public static final String AZURE_ACTIVE_DIRECTORY_DROPDOWN="(//div[contains(@class,'inputIconRight madrid-icon icon-size-12 icon-chevron-down')])[3]";
		public static final String AZURE_ACTIVE_DIRECTORY_CLICK="//div[@aria-label='Tata Consultancy Services Ltd. (3c8ea0e4-127c-4a02-ac65-58830e4ac608)']";		
		public static final String ADF_CONTINUE_BUTTON_CLICK="//span[normalize-space()='Continue']";
		public static final String ADF_DEVOPS_ORGANIZATION_DROPDOWN_CLICK ="(//div[contains(@class,'inputIconRight madrid-icon icon-size-12 icon-chevron-down')])[2]";
		public static final String ADF_DEVOPS_ORGANIZATION_NAME_CLICK="//div[@aria-label='MBU-Data-AI-AutoOps']";
		public static final String ADF_PROJECT_NAME_DROPDOWN="(//div[contains(@class,'inputIconRight madrid-icon icon-size-12 icon-chevron-down')])[3]";
		public static final String ADF_PROJECT_NAME__FILTER_SEARCHBAR="(//input[@placeholder='Filter...'])[1]";
		public static final String ADF_PROJECT_NAME__CLICK="/html[1]/body[1]/app-root[1]/mat-sidenav-container[1]/mat-sidenav[1]/div[1]/app-sidenav[1]/mat-sidenav-container[1]/mat-sidenav-content[1]/div[1]/div[2]/app-git-repo-information[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/app-dropdown[1]/app-dropdown-container[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/ul[1]/cdk-virtual-scroll-viewport[1]/div[1]/div[1]/div[1]";
		public static final String ADF_REPO_NAME_DROPDOWN="(//div[contains(@class,'inputIconRight madrid-icon icon-size-12 icon-chevron-down')])[4]";
		public static final String ADF_REPO_NAME_FILTER_SEARCHBAR="(//input[@placeholder='Filter...'])[2]";
		public static final String ADF_SEARCHED_CLICK="/html/body/app-root/mat-sidenav-container/mat-sidenav/div/app-sidenav/mat-sidenav-container/mat-sidenav-content/div/div[2]/app-git-repo-information/div[1]/div[4]/div/div/div/div/div/app-dropdown/app-dropdown-container/div/div[2]/div/div/div/div/div[2]/div[2]/ul/cdk-virtual-scroll-viewport/div[1]/div[1]/div";
		public static final String COLLOBRATION_BRANCH_DROPDOWN="(//div[contains(@class,'inputIconRight madrid-icon icon-size-12 icon-chevron-down')])[5]";
		public static final String COLLOBRATION_BRANCH_FILTER_SEARCHBAR="(//input[@placeholder='Filter...'])[3]";
		public static final String PUBLISH_BRANCH_DROPDOWN="(//div[contains(@class,'inputIconRight madrid-icon icon-size-12 icon-chevron-down')])[6]";
		public static final String PUBLISH_BRANCH_FILTER_SEARCHBAR="(//input[@placeholder='Filter...'])[4]";		
		public static final String ROOT_FOLDER_SEARCHBAR="//input[@aria-label='Root folder']";
		public static final String APPLY_BUTTON_CLICK="//span[normalize-space()='Apply']";
		
		
		// Synapse Locators.
		
		public static final String SYNAPSE_STUDIO_LAUNCH_BUTTON = "(//a[normalize-space()='Open'])[1]";
		public static final String SYNAPSE_MANAGE_CLICK="(//div[@class='icon svg-management-icon ng-star-inserted'])[1]";
		public static final String SYNAPSE_GIT_CONFIGURATIONS_CLICK="(//div[normalize-space()='Git configuration'])[1]";
		public static final String SYNAPSE_ALERT_POPUPs_CLICK="/html/body/div[6]/div/div/mat-dialog-container/div/div";
		
}
