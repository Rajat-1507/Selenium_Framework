package autoops.metadataframework.intializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SheetHandler {
	
	public List<Map<String, String>> getTestcasesToRun() {
		
	ConfigReader configreader = new ConfigReader();
	
	//Method-Readsheet-Take SheetName arraylist & It will read sheet one by one.
	//1st I will call getAllSheet Method
	// For loop 
	
	List<String> allSheets = configreader.getAllSheet();
	List<Map<String,String>> testcasestorun = new  ArrayList<Map<String, String>>();
			
	for(int i=0;i<allSheets.size();i++) {
		List<Map<String,String>> rows = configreader.readSheet(allSheets.get(i));
		
		for(int j=0;i<rows.size();j++) {
			Map<String,String> row = rows.get(j);
			if(row.get("Run_Mode").equalsIgnoreCase("yes")) {
				testcasestorun.add(row);
				
			}
		}
	}
	
	return testcasestorun;
	}
}
