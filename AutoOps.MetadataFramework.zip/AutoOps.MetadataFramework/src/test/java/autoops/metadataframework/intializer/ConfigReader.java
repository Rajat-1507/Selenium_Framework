package autoops.metadataframework.intializer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import autoops.metadataframework.utils.Xls_Reader;

public class ConfigReader {
		
	static Xls_Reader reader =new Xls_Reader("Test_Scenarios//MetaData_Framework.xlsx");
	String config_sheetname="Config";
	
	//Method1-ReadSheet- It will read all the parameter present in Config sheet.
	
	public Hashtable<String, String> readConfigSheet() {
				
		String username = reader.getCellData(config_sheetname,"Path_Value" , 6);       	
       	String password = reader.getCellData(config_sheetname, "Path_Value", 7);      	
       	String Evidence_Path = reader.getCellData(config_sheetname, "Path_Value", 3);
       	
       	Hashtable<String, String> my_dict = new Hashtable<String, String>();	
       	
       	my_dict.put("username", username);
       	my_dict.put("password", password);
       	my_dict.put("Evidence_Path", Evidence_Path);
       	
		return my_dict;		
		
	}
		
	//Method2-GetSheetList/GetAllSheet- Return SheetList(array)-[RG, KV]
	
	 public ArrayList<String> getAllSheet()
	    {
	       
	        String sheet_name = reader.getCellData(config_sheetname, "Path_Value", 5);
			ArrayList<String> GetSheetList = new ArrayList<String>(Arrays.asList(sheet_name.split(",")));
	        System.out.println(GetSheetList);
	        
	        return GetSheetList;
	    }
	 
	 public List<Map<String, String>> readSheet(String sheet_name) {
		 List<Map<String, String>> arr = new ArrayList<Map<String, String>>();
		 int n = reader.getRowCount(sheet_name);
		 for(int i=2;i<=n;i++) {
			 Map<String, String> row = new HashMap<String, String>();
			 
			 row.put("Run_Mode", reader.getCellData(sheet_name, "Run_Mode", i));
			 row.put("TEST_DATA", reader.getCellData(sheet_name, "TEST DATA", i));
			 row.put("EXPECTED_RESULT", reader.getCellData(sheet_name, "EXPECTED RESULT", i));
			 row.put("XPath", reader.getCellData(sheet_name, "XPATH", i));
			 row.put("Navigation_XPath", reader.getCellData(sheet_name, "NAVIGATION_XPATH", i));
			 arr.add(row);
		 }
		 
		 return arr;
	 }
	 
}
