package autoops.metadataframework.intializer;

import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

public class TestcaseHandler extends BaseTest{

	//Method-GetTestCases/TestcasesToRun-It will call sheethandler &  It will read particular sheet from array & Get all the Testcases for particular sheet which Run_mode = Yes.
	//Method-TestCasesExecutor
	
	@Test
	public void TestcaseExecutor() {
		
		SheetHandler sheethandler = new SheetHandler();
		
		List<Map<String,String>> testCasesToRun = sheethandler.getTestcasesToRun();
	}
	  
}
