package AutoOps.DataOps.PipelineGenerator.Configurations;

public class Config {

	public static final String BASE_URL="https://dev.azure.com/MBU-Data-AI-AutoOps/";
	public static final String my_username ="autoopstestuser@tcsteg.onmicrosoft.com";
	public static final String my_password="AutoOps@123";
	public static final String sql_database_url="jdbc:sqlserver://dataopsserver03.database.windows.net:1433;database=DataopsDB;user=dataopsserver03@dataopsserver03;password={your_password_here};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";
	public static final String sql_username ="dataopsserver03";
	public static final String sql_password ="Dataops@123";
}
