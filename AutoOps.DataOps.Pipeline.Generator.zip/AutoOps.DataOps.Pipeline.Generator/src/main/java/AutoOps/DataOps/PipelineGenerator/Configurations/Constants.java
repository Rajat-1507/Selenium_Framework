package AutoOps.DataOps.PipelineGenerator.Configurations;

public class Constants {

	// Xpath, Id, Link text.
	
			public static final String BASE_URL="https://dev.azure.com/";
			
			public static final String LOGIN_TO_AZURE_DEVOPS_LINK_XPATH="(//a[@class='azure-nav-utility__link'][normalize-space()='Sign in'])[2]";
			public static final String USERNAME_TEXTBOX_XPATH="i0116";
			public static final String PASSWORD_TEXTBOX_XPATH="i0118";
			public static final String YES_CONTINUE_POPUP_XPATH="idSIButton9";
			public static final String PROJECT_FILTER_SEARCH_TEXTBOX_XPATH="/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/input";
			public static final String PROJECT_SEARCHED_XPATH="/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div/div/div/div[3]/div[2]/div/table/tbody/tr[3]/td/div/a/div/div[2]/div[1]";
			public static final String PIPELINE_SIDEBAR_CLICK_XPATH="/html/body/div[1]/div/div/div[2]/div[1]/div/div[3]/div[4]/div/a/span[1]/img";
			public static final String NEW_PIPELINE_CLICK="New pipeline";
			public static final String CREATE_PIPELINE_CLICK ="Create Pipeline";
			public static final String AZURE_REPOS_GIT_CLICK="//span[normalize-space()='Azure Repos Git']";
			public static final String REPO_FILTER_SEARCH_TEXTBOX_XPATH="__bolt-textfield-input-1";
			public static final String REPO_SEARCHED_CLICK_XPATH="/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div/div[2]/div/table/tbody/tr[3]/td/div/div/div/div/span";
			public static final String EXISTING_AZURE_PIPELINE_YAML_FILE_CLICK_XPATH="//span[normalize-space()='Existing Azure Pipelines YAML file']";
			public static final String BRANCH_DROPDOWN_CLICK_XPATH="/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[1]/div/div/div/input";
			public static final String BRANCH_FILTER_SEARCH_XPATH="/html/body/div[2]/div[2]/div/div/div/div/div[2]/div/div/div/input";
			public static final String BRANCH_SEARCHED_CLICK_XPATH="/html/body/div[2]/div[2]/div/div/div/div/div[3]/table/tbody/tr[4]";
			public static final String YAML_FILE_PATH_TEXTBOX_XPATH="/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/div/div/input";
			public static final String FRAME_CLICK_XPATH="/html/body/div[2]/div/div/div/div[2]/div/div[3]/div/div[2]/span";
			public static final String CONTINUE_BUTTON_CLICK_XPATH="/html/body/div[2]/div/div/div/div[2]/div/div[4]/div/button[2]";
			public static final String RUN_BUTTON_ARROW_CLICK="/html/body/div[1]/div/div/div[2]/div[2]/div[2]/div/div[2]/div/div[1]/div[2]/div/div/div[2]/button/span";
			public static final String SAVE_BUTTON_CLICK="/html/body/div[2]/div/div/div/div/div/div/table/tbody/tr[3]/td[4]/div/div";
	
}

