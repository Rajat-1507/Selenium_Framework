package AutoOps.DataOps.PipelineGenerator.JsonDeserializer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ServiceData {
    private String request_UID;
    private String devOps_Organisation_Name;
    private String devOps_Project_Name;
    private List<ServiceParameter> serviceParameters = new ArrayList<ServiceParameter>();
    public String getRequest_UID() {
        return request_UID;
    }
    public void setRequest_UID(String request_UID) {
        this.request_UID = request_UID;
    }
    public String getDevOps_Organisation_Name() {
        return devOps_Organisation_Name;
    }
    public void setDevOps_Organisation_Name(String devOps_Organisation_Name) {
        this.devOps_Organisation_Name = devOps_Organisation_Name;
    }
    public String getDevOps_Project_Name() {
        return devOps_Project_Name;
    }
    public void setDevOps_Project_Name(String devOps_Project_Name) {
        this.devOps_Project_Name = devOps_Project_Name;
    }
    public List<ServiceParameter> getServiceParameters() {
        return serviceParameters;
    }
    public void setServiceParameters(List<ServiceParameter> serviceParameters) {
        this.serviceParameters = serviceParameters;
    }
}