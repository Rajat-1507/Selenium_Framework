package AutoOps.DataOps.PipelineGenerator.JsonDeserializer;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Root {
    private List<ServiceData> serviceData = new ArrayList<ServiceData>();
    public List<ServiceData> getServiceData() {
        return serviceData;
    }
    public void setServiceData(List<ServiceData> serviceData) {
        this.serviceData = serviceData;
    }
}