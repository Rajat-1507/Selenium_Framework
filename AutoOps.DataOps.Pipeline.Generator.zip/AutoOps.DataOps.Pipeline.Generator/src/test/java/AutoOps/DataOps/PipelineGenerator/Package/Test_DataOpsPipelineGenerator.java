package AutoOps.DataOps.PipelineGenerator.Package;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONArray;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import AutoOps.DataOps.PipelineGenerator.JsonDeserializer.Root;
import AutoOps.DataOps.PipelineGenerator.JsonDeserializer.ServiceData;
import AutoOps.DataOps.PipelineGenerator.JsonDeserializer.ServiceParameter;
import flexjson.JSONDeserializer;
import io.github.bonigarcia.wdm.WebDriverManager;



public class Test_DataOpsPipelineGenerator {

	public WebDriver driver= null;	
	private Connection connection;
	
	
	String Repo_Name="";
	String Yaml_File_Path ="";
	String Branch ="";
	String DevOpsProjectName="";
	String DevOpsOrganisationName="";
	String RequestUID="";
	String Azure_DevOps_Organization_Name_Xpath="";	
	final static Logger logger = Logger.getLogger(Test_DataOpsPipelineGenerator.class);
	
	
	@Test
	public void pipeline_Generation() throws Throwable {
		
		PropertyConfigurator.configure("log4j.properties.txt");
	
		// Reading Request_UID using config.properties file & using it in SP.
		Properties prop = new Properties();
		InputStream input = new FileInputStream("config.properties");
		prop.load(input);
		String R_id = prop.getProperty("Request_UID");					
		logger.info("Starting AutoOps DataOps Pipeline Generator Test");
			
        String databaseURL = AutoOps.DataOps.PipelineGenerator.Configurations.Config.sql_database_url;
        String user = AutoOps.DataOps.PipelineGenerator.Configurations.Config.sql_username;
        String password = AutoOps.DataOps.PipelineGenerator.Configurations.Config.sql_password;
        connection = null;
        logger.info("Loaded values like uname, pwd & url in string");

 try (   
         Connection conn = DriverManager.getConnection(databaseURL, user, password);
         CallableStatement statement = conn.prepareCall("{call USP_PiplineGenerationJson(?, ?)}");
			 		 
     )
 
 {			statement.setString(1,R_id);
	 		statement.setString(2,"Result");
	 		JSONArray jsonArray = new JSONArray();
	 		
            ResultSet resultSet = statement.executeQuery();	 
            String f = "";
            while(resultSet.next())
            {				
           	// f = resultSet.getString("JSON_F52E2B61-18A1-11d1-B105-00805F49916B");
           	f = resultSet.getString("Result");
            	System.out.println(f);
            }
            // Deserializing JSON String which is Stored Procedure Output.
            ObjectMapper mapper = new ObjectMapper();
			mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    	        	    	            
            JSONDeserializer<Root> deserializer = new JSONDeserializer<Root>();
	    	Root root = deserializer.deserialize(f, Root.class);

	    	// Consuming data as want
	    	  for (ServiceData servicedata : root.getServiceData()) {

	    		  DevOpsOrganisationName = servicedata.getDevOps_Organisation_Name();
	    		  DevOpsProjectName = servicedata.getDevOps_Project_Name();
	    		  RequestUID = servicedata.getRequest_UID();
	    		  
	    		  String Partial_Xpath = "//span[normalize-space()='']";
	    		  Azure_DevOps_Organization_Name_Xpath = Partial_Xpath.substring(0, 26) + DevOpsOrganisationName + Partial_Xpath.substring(26);

	    		  for (ServiceParameter serviceparameter : servicedata.getServiceParameters()) {
	    			  
	    			  String values = serviceparameter.getValue();
	    			  
	    			  if(serviceparameter.getName().equalsIgnoreCase("Publish_Branch")) {
	    				  Branch= values;
	    			  }
	    			  
	    			  else if(serviceparameter.getName().equalsIgnoreCase("Repos_Name")) {
	    				  Repo_Name= values;
	    			  }
	    			   else if(serviceparameter.getName().equalsIgnoreCase("Yaml_FilePath")) {
	    				Yaml_File_Path= values;
	    			  }
	    		  }
	    	  }
	    	  
             	// Providing Key vault url.
	        	String keyVaultUri = "https://tcsazaokvdev.vault.azure.net";
	        		            
	            SecretClient secretClient = new SecretClientBuilder()
	                    .vaultUrl(keyVaultUri)
	                    .credential(new DefaultAzureCredentialBuilder().build())
	                    .buildClient();
	            
	            //storing username & password in keyvault secrets variables.	             
	            String username = "uname";
	            String passwor = "pwd";	           
	            String retrieved_username = secretClient.getSecret(username).getValue();
	            String retrieved_password = secretClient.getSecret(passwor).getValue();
	            String my_username= retrieved_username;
	            String my_password= retrieved_password;
	         
	            WebDriverManager.chromedriver().setup();
	      	    WebDriver driver = new ChromeDriver();
	      	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); 			 
	   		 	   		 
	   		 // Launch Chrome & direct it to the Base URL
	   		 driver.get(AutoOps.DataOps.PipelineGenerator.Configurations.Config.BASE_URL);
	   		 logger.info("Open Azure DevOps site");
	   		 driver.manage().window().maximize();
	   		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
	   		 Thread.sleep(6000);
	   			   		 
	   		 // It will fill the username using sendkeys method & click on next button.
	   		 driver.findElement(By.id(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.USERNAME_TEXTBOX_XPATH)).sendKeys(my_username);
	   		 Thread.sleep(4000);
	   		 	   		 
	   		 driver.findElement(By.id(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.YES_CONTINUE_POPUP_XPATH)).click();
	   		 Thread.sleep(4000);
	   		 	   		
	   		// It will fill the password using sendkeys method & click on next button.
	   		 driver.findElement(By.id(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.PASSWORD_TEXTBOX_XPATH)).sendKeys(my_password);		 
	   		 Thread.sleep(4000);
	   		 driver.findElement(By.id(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.YES_CONTINUE_POPUP_XPATH)).click();
	   		 Thread.sleep(6000);
	   		
	   		 // Click on yes pop up.
	   		 driver.findElement(By.id(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.YES_CONTINUE_POPUP_XPATH)).click();	
	   		 Thread.sleep(5000);
	   		 logger.info("Login is sucessful");

	   		 
	   		 //Login done & Reached Organization.
	 		 driver.findElement(By.xpath(Azure_DevOps_Organization_Name_Xpath)).click();
			  Thread.sleep(4000);

	   		 // click on project filter & fill the data using sendkeys.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.PROJECT_FILTER_SEARCH_TEXTBOX_XPATH)).sendKeys(DevOpsProjectName);		 
	   		 Thread.sleep(4000);
	   		 logger.info("Searched particular project ");
	   		 
	   		 // click on project we searched.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.PROJECT_SEARCHED_XPATH)).click();
	   		 Thread.sleep(4000);
	   		logger.info("Selected & reached particular project");
	   		 
	   		 // click on Pipeline side bar.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.PIPELINE_SIDEBAR_CLICK_XPATH)).click();
	   		 Thread.sleep(6000);
	   		logger.info("Clicked on Pipeline sidebar");
	   		 
	   		 //if there is no pipeline available then it will click on Create pipeline or If there is any pipeline already available then it will click in New Pipeline.
	   		 WebElement Button = driver.findElement(By.xpath("//span[@class='bolt-button-text body-m'] | //span[contains(text(), 'Create Pipeline')]"));
	   	 	 Button.click(); 
	   	 	 Thread.sleep(4000);
	   	 	logger.info("Clicked on Create Pipeline/New Pipeline button");
	   		 
	   		 // click on Azure Repos Git.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.AZURE_REPOS_GIT_CLICK)).click();		 
	   		 Thread.sleep(6000);
	   		logger.info("Selected Azure Repo Git");
	   		 
	   		 // Searching the particular repo using Sendkeys method.
	   		 driver.findElement(By.id(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.REPO_FILTER_SEARCH_TEXTBOX_XPATH)).sendKeys(Repo_Name);		 
	   		 Thread.sleep(8000);
	   		logger.info("Searched particular repo ");

	   		 // click on repo we have searched.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.REPO_SEARCHED_CLICK_XPATH)).click();
	   		 Thread.sleep(6000);
	   		logger.info("Selected particular Repo");
	   		 
	   		 // click on Existing Azure Pipelines YAML file.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.EXISTING_AZURE_PIPELINE_YAML_FILE_CLICK_XPATH)).click();		
	   		 Thread.sleep(6000);
	   		logger.info("Clicked on Existing Azure Pipelines YAML file ");
	   		 		 
	   		 // using Explicitly wait, click on branch dropdown.
	   		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	   		 WebElement ele = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath((AutoOps.DataOps.PipelineGenerator.Configurations.Constants.BRANCH_DROPDOWN_CLICK_XPATH))));
	   		 ele.click();		
	   		 Thread.sleep(5000);
	   		logger.info("Clicked on Branch dropdown");
	   		 
	   		 // click on the search text box and send value  
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.BRANCH_FILTER_SEARCH_XPATH)).sendKeys(Branch);		 		 
	   		 Thread.sleep(6000);
	   		logger.info("Searched particular branch ");
	   		 
	   		 // click on particular branch searched.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.BRANCH_SEARCHED_CLICK_XPATH)).click();		 
	   		 Thread.sleep(5000);
	   		logger.info("Selected particular Branch");
	   		 
	   		// click on the search text box and send value 
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.YAML_FILE_PATH_TEXTBOX_XPATH)).sendKeys(Yaml_File_Path);		
	   		 Thread.sleep(8000);
	   		logger.info("Seached yaml file path");
	   		 
	   		// click on'Select a file from the dropdown or type in the path to your file' text.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.FRAME_CLICK_XPATH)).click();		
	   		 Thread.sleep(6000);
	   		logger.info("Selected yaml file path");
	   		 
	   		 // click on Continue button.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.CONTINUE_BUTTON_CLICK_XPATH)).click();
	   		 Thread.sleep(5000);
	   		logger.info("Clicked on Continue button");
	   		 
	   		 // click on save down arrow.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.RUN_BUTTON_ARROW_CLICK)).click();		
	   		 Thread.sleep(4000);
	   		logger.info("Clicked on save down array");
	   		 
	   		 // click on save button.
	   		 driver.findElement(By.xpath(AutoOps.DataOps.PipelineGenerator.Configurations.Constants.SAVE_BUTTON_CLICK)).click();		 
	   		 Thread.sleep(8000);	   		
	   		 logger.info("Pipeline Created Sucessfully");
	   		 
	   		 String Run_Pipeline = driver.findElement(By.xpath("//button[@role='button']//span[@class='bolt-button-text body-m'][normalize-space()='Run pipeline']")).getText();
	   		 String Actual_Result = "Run pipeline";
	   		 
	   		 Assert.assertEquals(Actual_Result, Run_Pipeline);
	   		 
	   		 driver.close();
	   		 driver.quit();
	   		 logger.info("browser is closed");   
	   		 
             statement.close();
            

            }   catch (SQLException ex) {
         ex.printStackTrace();
     }
 
 	 catch (Exception ex) {
	  	ex.printStackTrace();
	  	logger.error("error is", ex);
	 }
               
 }
   
	
	
	}	 

  		 

